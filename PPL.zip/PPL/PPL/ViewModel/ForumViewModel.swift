//
//  ForumViewModel.swift
//  PPL
//
//  Created by cdn68 on 22/06/18.
//  Copyright © 2018 cdn. All rights reserved.
//

import Foundation

struct ForumViewModel {
    var groupList: ChatGroupModel?
    var chatHistory: ChatHistoryModel?
    var groupId: String?
    var lastDateTime: String?
    var history_type: String?
}

extension ForumViewModel {
    func chatGroupList(completion: @escaping ((ChatGroupModel) -> Void)) {
        let apiManager = APIManager()
        var parameters = [String : Any]()
        
        apiManager.chatGroupList(parameters: parameters, completion: { (responseData) in
            if let jsonObject : [String : Any] = responseData.result.value as? [String : Any]{
                let statusCode = jsonObject["result_code"] as! Bool
                if statusCode {
                    do {
                        if let data = responseData.data {
                            let decoder = JSONDecoder()
                            let groupList = try decoder.decode(ChatGroupModel.self, from: data)
                            completion(groupList)
                        }
                    } catch  {
                        CommonUtility.showErrorCRNotifications(title: NSLocalizedString("title.error.occur", comment: "Error is shown when the json is unable to decode"), message: jsonObject["message"] as! String)
                    }
                }else {
                    CommonUtility.showErrorCRNotifications(title: appTitle(), message: jsonObject["message"] as! String)
                }
            }
        }) { (error) in
            
        }
    }
    
     func chatHistoryList(completion: @escaping (([String: Any]) -> Void)) {
        let apiManager = APIManager()
        var parameters = [String : Any]()
        parameters["group_id"] = self.groupId
        parameters["datetime"] = self.lastDateTime ?? "-1"
        parameters["history_type"] = self.history_type
        
        print("request -- \(parameters)")
        apiManager.chatHistoryList(parameters: parameters, completion: { (responseData) in
            if let jsonObject : [String : Any] = responseData.result.value as? [String : Any]{
                let statusCode = jsonObject["result_code"] as! Bool
                if statusCode {
                    completion(jsonObject)
                }else {
                    CommonUtility.showErrorCRNotifications(title: appTitle(), message: jsonObject["message"] as! String)
                }
            }
        }) { (error) in
            
        }
    }
}
