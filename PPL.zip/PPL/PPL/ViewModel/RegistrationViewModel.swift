//
//  RegistrationViewModel.swift
//  PPL
//
//  Created by cdn68 on 31/05/18.
//  Copyright © 2018 cdn. All rights reserved.
//

import UIKit

struct RegistrationViewModel {
    var firstname : String = ""
    var lastname : String = ""
    var username: String = ""
    var gender : String = ""
    var email: String = ""
    var pasword: String = ""
    var confirmPassword: String = ""
    var address : String = ""
}

extension RegistrationViewModel {
    init(firstname : String, lastname : String, username: String,gender : String, email: String, password: String, confirmPassword: String, address : String) {
        self.firstname = firstname
        self.lastname = lastname
        self.username = username
        self.gender = gender
        self.email = email
        self.pasword = password
        self.confirmPassword = confirmPassword
        self.address = address
    }
    
    func validate() -> Bool {
        if self.firstname.isEmpty {
            CommonUtility.showErrorCRNotifications(title: "Error!", message: NSLocalizedString("title.alert.firstname", comment: "Showing the alert when the firstname field is empty"))
            return false
        }
        else if self.lastname.isEmpty {
            CommonUtility.showErrorCRNotifications(title: "Error!", message: NSLocalizedString("title.alert.lastname", comment: "Showing the alert when the lastname field is empty"))
            return false
        }
        else if self.username.isEmpty {
            CommonUtility.showErrorCRNotifications(title: "Error!", message: NSLocalizedString("title.alert.username", comment: "Showing the alert when the username field is empty"))
            return false
        } else if self.gender == "" {
            CommonUtility.showErrorCRNotifications(title: "Error!", message: NSLocalizedString("title.alert.gender", comment: "Showing the alert when the gender field is empty"))
            return false
        }else if self.email.isEmpty {
            CommonUtility.showErrorCRNotifications(title: "Error!", message: NSLocalizedString("title.alert.email", comment: "Showing the alert when the email field is empty"))
            return false
        }else if !CommonUtility.checkValidEmail(self.email) {
            CommonUtility.showErrorCRNotifications(title: "Error!", message: NSLocalizedString("title.alert.valid.email", comment: "Showing the alert when the email field text is not valid"))
            return false
        }
        else if self.pasword.isEmpty {
            CommonUtility.showErrorCRNotifications(title: "Error!", message: NSLocalizedString("title.alert.password", comment: "Showing the alert when the password field is empty"))
            return false
        }else if !CommonUtility.checkValidPasswordField(self.pasword) {
            CommonUtility.showErrorCRNotifications(title: "Error!", message: NSLocalizedString("title.alert.password.characters.count", comment: "Showing the alert when the password field is having less than 8 characters"))
            return false
        }else if self.confirmPassword.isEmpty {
            CommonUtility.showErrorCRNotifications(title: "Error!", message: NSLocalizedString("title.alert.confirm.password", comment: "Showing the alert when the confirm password field is empty"))
            return false
        }else if !CommonUtility.checkValidPasswordField(self.confirmPassword) {
            CommonUtility.showErrorCRNotifications(title: "Error!", message: NSLocalizedString("title.alert.confirm.password.characters.count", comment: "Showing the alert when the confirm password field is having less than 8 characters"))
            return false
        }else if self.pasword != self.confirmPassword {
            CommonUtility.showErrorCRNotifications(title: "Error!", message: NSLocalizedString("title.alert.password.mismatch", comment: "Showing the alert when the confirm password and password is not same"))
            return false
        } else if self.address.isEmpty {
            CommonUtility.showErrorCRNotifications(title: "Error!", message: NSLocalizedString("title.alert.address", comment: "Showing the alert when the address field is empty"))
            return false
        }
        return true
    }
    
    func signup(completion: @escaping ((UserModel) -> Void)) {
        let apiManager = APIManager()
        
        var parameters = [String : Any]()
        parameters["email"] = self.email
        parameters["password"] = self.pasword
        parameters["username"] = self.username
        parameters["mobile"] = ""
        parameters["reference_code"] = ""
        parameters["firstname"] = self.firstname
        parameters["lastname"] = self.lastname
        parameters["address"] = self.address
        parameters["gender"] = self.gender

        apiManager.registration(methodName: (CommonUtility.isPilate() ? kMethodRegistration_Doctor: kMethodRegistration_Patient), parameters: parameters, completion: { (responseData) in
            if let jsonObject : [String : Any] = responseData.result.value as? [String : Any]{
                let statusCode = jsonObject["result_code"] as! Bool
                if statusCode {
                    do {
                        if let data = responseData.data {
                            let decoder = JSONDecoder()
                            let userModel = try decoder.decode(UserModel.self, from: data)
                            UserDefaults.standard.set(try? PropertyListEncoder().encode(userModel), forKey:UserdefaultsKey.userData.rawValue)
                           
                            UserDefaults.standard.set(userModel.result.push_notification == "1" ? true : false, forKey: UserdefaultsKey.isPushEnabled.rawValue)

                            UserDefaults.standard.set(userModel.result.access_token, forKey: UserdefaultsKey.accessToken.rawValue)
                            completion(userModel)
                        }
                    } catch  {
                        CommonUtility.showErrorCRNotifications(title: NSLocalizedString("title.error.occur", comment: "Error is shown when the json is unable to decode"), message: jsonObject["message"] as! String)
                    }
                }else {
                    CommonUtility.showErrorCRNotifications(title: appTitle(), message: jsonObject["message"] as! String)
                }
            }
        }) { (error) in
            CommonUtility.showErrorCRNotifications(title: appTitle(), message: (error?.localizedDescription)!)
        }
    }
}
