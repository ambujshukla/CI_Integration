//
//  PilateDetailViewModel.swift
//  PPL
//
//  Created by cdn68 on 07/06/18.
//  Copyright © 2018 cdn. All rights reserved.
//

import Foundation

//kMethodPatient_SendRequest
struct PilateDetailViewModel {
    var doctorId: String = ""
}

extension PilateDetailViewModel {
    
    func addPilateRequest(completion: @escaping (() -> Void), failure: @escaping ((NSError?) -> Void)) {
        var parameters = [String: Any]()
        parameters["doctor_id"] = self.doctorId
        let apiManager = APIManager()
        apiManager.addPilateSendRequest(parameters: parameters, completion: { (response) in
            completion()
        }) { (error) in
            CommonUtility.showErrorCRNotifications(title: appTitle(), message: (error?.localizedDescription)!)
        }
    }
}
