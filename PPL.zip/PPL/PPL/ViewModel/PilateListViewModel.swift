//
//  PilateListViewModel.swift
//  PPL
//
//  Created by cdn68 on 06/06/18.
//  Copyright © 2018 cdn. All rights reserved.
//

import Foundation

struct PilateListViewModel {
    var pilateList: PilateListModel?
}

extension PilateListViewModel {
    
    func doctorList(completion: @escaping ((PilateListModel) -> Void)) {
        let apiManager = APIManager()
        let parameters = [String : Any]()
        apiManager.doctorList(parameters: parameters, completion: { (responseData) in
            if let jsonObject : [String : Any] = responseData.result.value as? [String : Any]{
                let statusCode = jsonObject["result_code"] as! Bool
                if statusCode {
                    do {
                        if let data = responseData.data {
                            let decoder = JSONDecoder()
                            let pilateList = try decoder.decode(PilateListModel.self, from: data)
                            completion(pilateList)
                        }
                    } catch  {
                        CommonUtility.showErrorCRNotifications(title: NSLocalizedString("title.error.occur", comment: "Error is shown when the json is unable to decode"), message: jsonObject["message"] as! String)
                    }
                }else {
                    CommonUtility.showErrorCRNotifications(title: appTitle(), message: jsonObject["message"] as! String)
                }
            }
        }) { (error) in
            
        }
    }
}
