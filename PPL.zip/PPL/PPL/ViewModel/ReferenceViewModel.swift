//
//  ReferenceViewModel.swift
//  PPL
//
//  Created by cdn68 on 05/06/18.
//  Copyright © 2018 cdn. All rights reserved.
//

import UIKit

struct ReferenceViewModel {
    var referalCode: String = ""
    var phoneNumber: String = ""
    var username: String = ""
    var email: String = ""
    var password: String = ""
    var firstname: String = ""
    var lastname: String = ""
    var address: String = ""
    var gender: String = ""
}

private let kPhoneNumberLength = 10

extension ReferenceViewModel {
    
    func validate() -> Bool {
        if self.referalCode.isEmpty {
            CommonUtility.showErrorCRNotifications(title: "Error!", message: NSLocalizedString("title.alert.referalcode", comment: "Showing the alert when the referal code field is empty"))
            return false
        }else if self.phoneNumber.isEmpty {
            CommonUtility.showErrorCRNotifications(title: "Error!", message: NSLocalizedString("title.alert.mobilenumber", comment: "Showing the alert when the phone number field is empty"))
            return false
        }else if self.phoneNumber.count < kPhoneNumberLength {
            CommonUtility.showErrorCRNotifications(title: "Error!", message: NSLocalizedString("title.alert.mobilenumber.length", comment: "Showing the alert when the phone number is less than 10"))
            return false
        }
        return true
    }
    
    func signup(completion: @escaping ((UserModel) -> Void)) {
        let apiManager = APIManager()
        var parameters = [String : Any]()
        parameters["email"] = self.email
        parameters["password"] = self.password
        parameters["username"] = self.username
        parameters["mobile"] = self.phoneNumber
        parameters["reference_code"] = referalCode
        parameters["firstname"] = self.firstname
        parameters["lastname"] = self.lastname
        parameters["address"] = self.address
        parameters["gender"] = self.gender
        
        apiManager.registration(methodName: kMethodRegistration_Patient, parameters: parameters, completion: { (responseData) in
            if let jsonObject : [String : Any] = responseData.result.value as? [String : Any]{
                let statusCode = jsonObject["result_code"] as! Bool
                if statusCode {
                    do {
                        if let data = responseData.data {
                            let decoder = JSONDecoder()
                            let userModel = try decoder.decode(UserModel.self, from: data)
                            UserDefaults.standard.set(try? PropertyListEncoder().encode(userModel), forKey:UserdefaultsKey.userData.rawValue)
                            UserDefaults.standard.set(userModel.result.access_token, forKey: UserdefaultsKey.accessToken.rawValue)
                            completion(userModel)
                        }
                    } catch  {
                        CommonUtility.showErrorCRNotifications(title: NSLocalizedString("title.error.occur", comment: "Error is shown when the json is unable to decode"), message: jsonObject["message"] as! String)
                    }
                }else {
                    CommonUtility.showErrorCRNotifications(title: appTitle(), message: jsonObject["message"] as! String)
                }
            }
        }) { (error) in
            
        }
    }
}

