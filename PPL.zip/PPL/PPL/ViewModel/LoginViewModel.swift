//
//  LoginViewModel.swift
//  PPL
//
//  Created by cdn68 on 31/05/18.
//  Copyright © 2018 cdn. All rights reserved.
//

import UIKit

struct LoginViewModel {
    var username: String = ""
    var pasword: String = ""
}

extension LoginViewModel {
    init(username: String, password: String) {
        self.username = username
        self.pasword = password
    }
    
    //This function is used to validate the fields username and password.
    func validate() -> Bool {
        if self.username.isEmpty {
            CommonUtility.showErrorCRNotifications(title: "Error!", message: NSLocalizedString("title.alert.username", comment: "Showing the alert when the username field is empty"))
            return false
        }else if self.username.count < 3 {
            CommonUtility.showErrorCRNotifications(title: "Error!", message: NSLocalizedString("title.alert.username.characters.count", comment: "Showing the alert when the username field is having less than 3 characters"))
            return false
        }
        else if self.pasword.isEmpty {
            CommonUtility.showErrorCRNotifications(title: "Error!", message: NSLocalizedString("title.alert.password", comment: "Showing the alert when the password field is empty"))
            return false
        }else if self.pasword.count < 8 {
            CommonUtility.showErrorCRNotifications(title: "Error!", message: NSLocalizedString("title.alert.password.characters.count", comment: "Showing the alert when the password field is having less tha 8 characters"))
            return false
        }
        return true
    }
    
    func signupText() -> NSAttributedString {
        let attrs1 = [NSAttributedStringKey.font : UIFont.systemFont(ofSize: 16), NSAttributedStringKey.foregroundColor : UIColor.gray]
        let attrs2 = [NSAttributedStringKey.font : UIFont.boldSystemFont(ofSize: 16), NSAttributedStringKey.foregroundColor : UIColor.black]
        
        let attributedString1 = NSMutableAttributedString(string:"Don't have an Account? ", attributes:attrs1)
        let attributedString2 = NSMutableAttributedString(string:"Sign Up Now", attributes:attrs2)
        attributedString1.append(attributedString2)
        return attributedString1
    }
    
    func patientPilatesText() -> NSAttributedString {
        let attrs11 = [NSAttributedStringKey.font : UIFont.boldSystemFont(ofSize: 35), NSAttributedStringKey.foregroundColor : UIColor.black]
        let attrs22 = [NSAttributedStringKey.font : UIFont.systemFont(ofSize: 35), NSAttributedStringKey.foregroundColor : UIColor.black]
        
        let attributedString11 = NSMutableAttributedString(string:"Patient ", attributes:attrs11)
        let attributedString22 = NSMutableAttributedString(string:"Pilates", attributes:attrs22)
        
        attributedString11.append(attributedString22)
        return attributedString11
    }
    
    func login(completion: @escaping ((UserModel) -> Void)) {
        let apiManager = APIManager()
        var parameters = [String : Any]()
        parameters["username"] = self.username
        parameters["password"] = self.pasword
        
        apiManager.login(methodName:(CommonUtility.isPilate() ? kMethodLogin_Patient:kMethodLogin_Patient), parameters: parameters, completion: { (responseData) in
            if let jsonObject : [String : Any] = responseData.result.value as? [String : Any]{
                let statusCode = jsonObject["result_code"] as! Bool
                if statusCode {
                    do {
                        if let data = responseData.data {
                            let decoder = JSONDecoder()
                            let userModel = try decoder.decode(UserModel.self, from: data)
                            UserDefaults.standard.set(try? PropertyListEncoder().encode(userModel), forKey:UserdefaultsKey.userData.rawValue)
                            UserDefaults.standard.set(userModel.result.push_notification == "1" ? true : false, forKey: UserdefaultsKey.isPushEnabled.rawValue)

                            UserDefaults.standard.set(userModel.result.access_token, forKey: UserdefaultsKey.accessToken.rawValue)
                            completion(userModel)
                        }
                    } catch  {
                        CommonUtility.showErrorCRNotifications(title: NSLocalizedString("title.error.occur", comment: "Error is shown when the json is unable to decode"), message: jsonObject["message"] as! String)
                    }
                }else {
                    CommonUtility.showErrorCRNotifications(title: appTitle(), message: jsonObject["message"] as! String)
                }
            }
        }) { (error) in
        }
    }
}
