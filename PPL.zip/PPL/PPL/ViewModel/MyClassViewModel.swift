//
//  PilateListViewModel.swift
//  PPL
//
//  Created by cdn68 on 06/06/18.
//  Copyright © 2018 cdn. All rights reserved.
//

import Foundation

struct MyClassViewModel {
    var schedule_id: String = ""
    var myClassModel: MyClassModel?
}

extension MyClassViewModel {
    func getMyClass(completion: @escaping ((MyClassModel) -> Void)) {
        let apiManager = APIManager()
        var parameters = [String : Any]()
        parameters["schedule_id"] = self.schedule_id
        apiManager.getMyClass(parameters: parameters, completion: { (responseData) in
            if let jsonObject : [String : Any] = responseData.result.value as? [String : Any]{
                let statusCode = jsonObject["result_code"] as! Bool
                if statusCode {
                    do {
                        if let data = responseData.data {
                            let decoder = JSONDecoder()
                            let pilateList = try decoder.decode(MyClassModel.self, from: data)
                            completion(pilateList)
                        }
                    } catch  {
                        CommonUtility.showErrorCRNotifications(title: NSLocalizedString("title.error.occur", comment: "Error is shown when the json is unable to decode"), message: jsonObject["message"] as! String)
                    }
                }else {
                    CommonUtility.showErrorCRNotifications(title: appTitle(), message: jsonObject["message"] as! String)
                }
            }
        }) { (error) in
        }
    }
}
