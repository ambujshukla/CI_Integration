//
//  SettingsViewModel.swift
//  PPL
//
//  Created by cdn68 on 14/06/18.
//  Copyright © 2018 cdn. All rights reserved.
//

import Foundation

struct SettingsViewModel {
    var pushNotificationValue: Bool?
}

extension SettingsViewModel {
    
    func enableDisablePush(completion: @escaping (() -> Void), failure: @escaping (NSError?) -> Void) {
        let apiManager = APIManager()
        var parameters = [String : Any]()
        parameters["status"] = "2"
        if self.pushNotificationValue == true {
            parameters["status"] = "1"
        }
        
        
        apiManager.setPushNotification(parameters: parameters, completion: { (response) in
            let resultCode = response["result_code"] as! Bool
            if resultCode {
                CommonUtility.showSuccessCRNotifications(title: "Success!!", message: NSLocalizedString("title.success.updated.pushnotifications", comment: "This message shown after the password change successfully."))
                completion()
            }else {
                CommonUtility.showErrorCRNotifications(title: appTitle(), message: response["message"] as! String)
            }
        }) { (error) in
            CommonUtility.showErrorCRNotifications(title: "Error!", message: (error?.localizedDescription)!)
        }
    }
}
