//
//  AppointmentsViewModel.swift
//  PPL
//
//  Created by cdn68 on 13/06/18.
//  Copyright © 2018 cdn. All rights reserved.
//

import Foundation

struct AppointmentsViewModel {
    var appointmentsListArray: AppointmenstModel?
    var scheduleId: String?
    var doctorId: String?
}

extension AppointmentsViewModel {
    
    func schedules_AppointmentsList(completion: @escaping ((AppointmenstModel) -> Void)) {
        let apiManager = APIManager()
        let parameters = [String : Any]()
        
        apiManager.schedules_AppointmentsList(parameters: parameters, completion: { (responseData) in
            if let jsonObject : [String : Any] = responseData.result.value as? [String : Any]{
                let statusCode = jsonObject["result_code"] as! Bool
                if statusCode {
                    do {
                        if let data = responseData.data {
                            let decoder = JSONDecoder()
                            let appointmentsList = try decoder.decode(AppointmenstModel.self, from: data)
                            completion(appointmentsList)
                        }
                    } catch  {
                        CommonUtility.showErrorCRNotifications(title: NSLocalizedString("title.error.occur", comment: "Error is shown when the json is unable to decode"), message: jsonObject["message"] as! String)
                    }
                }else {
                    CommonUtility.showErrorCRNotifications(title: appTitle(), message: jsonObject["message"] as! String)
                }
            }
        }) { (error) in
            
        }
    }
    
    func addAppointments(completion: @escaping (() -> Void)) {
        let apiManager = APIManager()
        var params = [String : Any]()
        params["schedule_id"] = self.scheduleId
        params["doctor_id"] = self.doctorId
        
        apiManager.addAppointments(parameters: params, completion: { (response) in
            let resultCode = response["result_code"] as! Bool
            if resultCode {
                CommonUtility.showSuccessCRNotifications(title: "Success!!", message: NSLocalizedString("title.success.appointments.added", comment: "This message shown after the password change successfully."))
                completion()
            }else {
                CommonUtility.showErrorCRNotifications(title: appTitle(), message: response["message"] as! String)
            }
        }) { (error) in
            CommonUtility.showErrorCRNotifications(title: "Error!", message: (error?.localizedDescription)!)
            
        }
    }
}

