//
//  ChangePasswordViewModel.swift
//  PPL
//
//  Created by cdn68 on 07/06/18.
//  Copyright © 2018 cdn. All rights reserved.
//

import Foundation

struct  ChangePasswordViewModel {
    var currentPassword: String = ""
    var newPassword: String = ""
    var confirmPassword: String = ""
}

extension ChangePasswordViewModel {
    func validate() -> Bool {
        if self.currentPassword.isEmpty {
            CommonUtility.showErrorCRNotifications(title: "Error!", message: NSLocalizedString("title.alert.password", comment: "Showing the alert when the password field is having less than 8 characters"))
            return false
        }else if self.newPassword.isEmpty {
            CommonUtility.showErrorCRNotifications(title: "Error!", message: NSLocalizedString("title.alert.new.password", comment: "Showing the alert when the password is empty"))
            return false
        }
        else if !CommonUtility.checkValidPasswordField(self.newPassword) {
            CommonUtility.showErrorCRNotifications(title: "Error!", message: NSLocalizedString("title.alert.password.characters.count", comment: "Showing the alert when the password field is having less than 8 characters"))
            return false
        }else if self.newPassword != self.confirmPassword {
            CommonUtility.showErrorCRNotifications(title: "Error!", message: NSLocalizedString("title.alert.password.mismatch", comment: "Showing the alert when the password field is having less than 8 characters"))
            return false
        }
        return true
    }
    
    func changePassword(completion: @escaping (() -> Void), failure: @escaping (NSError?) -> Void) {
        let apiManager = APIManager()
        var parameters = [String : Any]()
        parameters["current_password"] = self.currentPassword
        parameters["new_password"] = self.newPassword
        parameters["verify_password"] = self.confirmPassword
        
        apiManager.changePassword(parameters: parameters, completion: { (response) in
            let resultCode = response["result_code"] as! Bool
            if resultCode {
                CommonUtility.showSuccessCRNotifications(title: "Success!!", message: NSLocalizedString("title.success.password.update", comment: "This message shown after the password change successfully."))
                completion()
            }else {
                CommonUtility.showErrorCRNotifications(title: appTitle(), message: response["message"] as! String)
            }
        }) { (error) in
            CommonUtility.showErrorCRNotifications(title: "Error!", message: (error?.localizedDescription)!)
        }
    }
}
