//
//  AddScheduleViewModel.swift
//  PPL
//
//  Created by cdn68 on 08/06/18.
//  Copyright © 2018 cdn. All rights reserved.
//

import Foundation

struct ScheduleViewModel {
    var scheduleTitle = ""
    var date: String = ""
    var start_time: String = ""
    var end_time: String = ""
    var number_of_patient: String = ""
    var scheduleList: ScheduleListModel?
}

extension ScheduleViewModel {
    
    func validated() -> Bool {
        if(self.scheduleTitle.isEmpty)
        {
            CommonUtility.showErrorCRNotifications(title: "Error!", message: NSLocalizedString("Please enter Schedule Title", comment: "Showing the alert when the Schedule Title is empty"))
            
            return false
        }
        else if(self.start_time.isEmpty)
        {
            CommonUtility.showErrorCRNotifications(title: "Error!", message: NSLocalizedString("Please enter Start Time", comment: "Showing the alert when the start time is empty"))
            return false
        }
        else if(self.end_time.isEmpty)
        {
            CommonUtility.showErrorCRNotifications(title: "Error!", message: NSLocalizedString("Please enter End Time", comment: "Showing the alert when the end time is empty"))
            return false
        }
        else if(self.date.isEmpty)
        {
            CommonUtility.showErrorCRNotifications(title: "Error!", message: NSLocalizedString("Please enter Date", comment: "Showing the alert when the dob is empty"))
            return false
        }
        else if(self.number_of_patient.isEmpty)
        {
            CommonUtility.showErrorCRNotifications(title: "Error!", message: NSLocalizedString("Please enter No. of Patients", comment: "Showing the alert when the no. of patients is empty"))
            return false
        }
        return true
    }
    
    func addSchedule(completion: @escaping (() -> Void), failure: @escaping (NSError?) -> Void) {
        let apiManager = APIManager()
        var parameters = [String : Any]()
        parameters["date"] = self.date
        parameters["start_time"] = self.start_time
        parameters["end_time"] = self.end_time
        parameters["number_of_patient"] = self.number_of_patient
        parameters["title"] = self.scheduleTitle
        
        apiManager.createSchedule(parameters: parameters, completion: { (response) in
            let resultCode = response["result_code"] as! Bool
            if resultCode {
                CommonUtility.showSuccessCRNotifications(title: "Success!!", message: NSLocalizedString("title.success.schedule.created", comment: "This message shown after the successful creation of schedule."))
                completion()
            }else {
                CommonUtility.showErrorCRNotifications(title: appTitle(), message: response["message"] as! String)
            }
        }) { (error) in
            CommonUtility.showErrorCRNotifications(title: "Error!", message: (error?.localizedDescription)!)
        }
    }
  
    func getScheduleList(completion: @escaping ((ScheduleListModel) -> Void), failure: @escaping ((NSError?) -> Void)) {
        let apiManager = APIManager()
        let parameters = [String: Any]()
        apiManager.myClients(methodName: kMethodGet_Schedule, parameters: parameters, completion: { (responseData) in
            if let jsonObject : [String : Any] = responseData.result.value as? [String : Any]{
                let statusCode = jsonObject["result_code"] as! Bool
                if statusCode {
                    do {
                        if let data = responseData.data {
                            let decoder = JSONDecoder()
                            let scheduleListModel = try decoder.decode(ScheduleListModel.self, from: data)
                            completion(scheduleListModel)
                        }
                    } catch  {
                        CommonUtility.showErrorCRNotifications(title: NSLocalizedString("title.error.occur", comment: "Error is shown when the json is unable to decode"), message: jsonObject["message"] as! String)
                    }
                }else {
                    CommonUtility.showErrorCRNotifications(title: appTitle(), message: jsonObject["message"] as! String)
                }
            }
        }) { (error) in
            CommonUtility.showErrorCRNotifications(title: appTitle(), message: (error?.localizedDescription)!)
        }
    }
}
