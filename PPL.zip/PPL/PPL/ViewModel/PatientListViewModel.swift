//
//  PatientListViewModel.swift
//  PPL
//
//  Created by cdn68 on 07/06/18.
//  Copyright © 2018 cdn. All rights reserved.
//

import Foundation

struct PatientListViewModel {
    var patientList: PatientListModel?
}

extension PatientListViewModel {
    
    func clientsList(completion: @escaping ((PatientListModel) -> Void), failure: @escaping ((NSError?) -> Void)) {
        let apiManager = APIManager()
        let parameters = [String: Any]()
        apiManager.myClients(methodName: kMethodPatient_MyClients, parameters: parameters, completion: { (responseData) in
            if let jsonObject : [String : Any] = responseData.result.value as? [String : Any]{
                let statusCode = jsonObject["result_code"] as! Bool
                if statusCode {
                    do {
                        if let data = responseData.data {
                            let decoder = JSONDecoder()
                            let patientListModel = try decoder.decode(PatientListModel.self, from: data)
                            completion(patientListModel)
                        }
                    } catch  {
                        CommonUtility.showErrorCRNotifications(title: NSLocalizedString("title.error.occur", comment: "Error is shown when the json is unable to decode"), message: jsonObject["message"] as! String)
                    }
                }else {
                    CommonUtility.showErrorCRNotifications(title: appTitle(), message: jsonObject["message"] as! String)
                }
            }
        }) { (error) in
            CommonUtility.showErrorCRNotifications(title: appTitle(), message: (error?.localizedDescription)!)
        }
    }
    
    func changePatientRequest(patientId: String, status: String, completion: @escaping (() -> Void), failure: @escaping(() -> Void)) {
        let apiManager = APIManager()
        var parameters = [String: Any]()
        parameters["patient_id"] = patientId
        parameters["status"] = status
        apiManager.changePatientRequest(parameters: parameters, completion: { (response) in
            completion()
        }) { (error) in
            CommonUtility.showErrorCRNotifications(title: appTitle(), message: (error?.localizedDescription)!)
        }
    }
}
