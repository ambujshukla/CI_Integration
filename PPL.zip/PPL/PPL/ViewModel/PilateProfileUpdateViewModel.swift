//
//  PilateProfileUpdateViewModel.swift
//  PPL
//
//  Created by cdn68 on 08/06/18.
//  Copyright © 2018 cdn. All rights reserved.
//

import UIKit

struct PilateProfileUpdateViewModel {
    var expertise: String?
    var experience: String?
    var achievements: String?
    var qualification: String?
    var profileImage: UIImage?
    var firstName: String?
    var lastName: String?
    var address: String?
}

extension PilateProfileUpdateViewModel {
    
    
    func validated() -> Bool {
        if (self.qualification == "") {
            CommonUtility.showErrorCRNotifications(title: "Error!", message: NSLocalizedString("title.alert.qualification", comment: "Showing the alert when the qualification is empty"))
            return false
        }else if (self.experience == "") {
            CommonUtility.showErrorCRNotifications(title: "Error!", message: NSLocalizedString("title.alert.experience", comment: "Showing the alert when the experience is empty"))
            return false
        }else if (self.expertise == "") {
            CommonUtility.showErrorCRNotifications(title: "Error!", message: NSLocalizedString("title.alert.expertise", comment: "Showing the alert when the expertise is empty"))
            return false
        }
        return true
    }
    
    func updateProfile(completion : @escaping (()  -> Void) , failure : @escaping ((NSError?) -> Void ))
    {
        let apiManager = APIManager()
        var parameters = [String : Any]()
        parameters["expertise"] = self.expertise
        parameters["experience"] = self.experience
        parameters["qualification"] = self.qualification
        parameters["achievements"] = self.achievements
        parameters["firstname"] = self.firstName
        parameters["lastname"] = self.lastName
        parameters["address"] = self.address
       
        
        let image = self.profileImage
 
        apiManager.uploadImageWithParameters(url: "\(kBaseUrl)\(kMethodProfileUpdate_Pilate)", parameters: parameters, image: image!, completion: { (responseData) in
            if let jsonObject : [String : Any] = responseData.result.value as? [String : Any]{
                let statusCode = jsonObject["result_code"] as! Bool
                if statusCode {
                    do {
                        if let data = responseData.data {
                            let decoder = JSONDecoder()
                            let userModel = try decoder.decode(UserModel.self, from: data)
                            UserDefaults.standard.set(try? PropertyListEncoder().encode(userModel), forKey:UserdefaultsKey.userData.rawValue)
                            CommonUtility.showSuccessCRNotifications(title: appTitle(), message: NSLocalizedString("title.success.profile.update", comment: "This message will be shown once the profile being updated successfully."))
                            completion()
                            
                        }
                    } catch  {
                        CommonUtility.showErrorCRNotifications(title: NSLocalizedString("title.error.occur", comment: "Error is shown when the json is unable to decode"), message: jsonObject["message"] as! String)
                    }
                }else {
                   // CommonUtility.showErrorCRNotifications(title: appTitle(), message: jsonObject["message"] as! String)
                     CommonUtility.showErrorCRNotifications(title: appTitle(), message: "Tanjeet" )
                }
            }
        }) { (error) in
            CommonUtility.showErrorCRNotifications(title: appTitle(), message: (error?.localizedDescription)!)
        }
        }
}
