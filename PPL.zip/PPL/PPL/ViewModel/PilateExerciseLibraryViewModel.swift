//
//  PilateExerciseLibraryViewModel.swift
//  PPL
//
//  Created by cdn68 on 15/06/18.
//  Copyright © 2018 cdn. All rights reserved.
//

import Foundation

struct PilateExerciseLibraryViewModel {
    var filesData = [Data]()
    var title: String?
    var imagesUploadData: ExerciseLibraryModel?
}

extension PilateExerciseLibraryViewModel {
    func uploadImages(completion: @escaping ((ExerciseLibraryModel) -> Void),failure: @escaping ((NSError?)) -> Void) {
        let apiManager = APIManager()
        var params = [String : Any]()
        params["title"] = self.title
        apiManager.uploadImages(parameters: params, imageFiles: self.filesData, completion: { (responseData) in
            if let jsonObject : [String : Any] = responseData.result.value as? [String : Any]{
                let statusCode = jsonObject["result_code"] as! Bool
                if statusCode {
                    CommonUtility.showSuccessCRNotifications(title: "Success!!", message: NSLocalizedString("title.success.image.uploaded.successfully", comment: "This message shown after the password change successfully."))
                    do {
                        if let data = responseData.data {
                            let decoder = JSONDecoder()
                            let imageList = try decoder.decode(ExerciseLibraryModel.self, from: data)
                            completion(imageList)
                        }
                    } catch  {
                        CommonUtility.showErrorCRNotifications(title: NSLocalizedString("title.error.occur", comment: "Error is shown when the json is unable to decode"), message: jsonObject["message"] as! String)
                    }
                }else {
                    CommonUtility.showErrorCRNotifications(title: appTitle(), message: jsonObject["message"] as! String)
                }
            }
        }) { (error) in
            CommonUtility.showErrorCRNotifications(title: "Error!", message: (error?.localizedDescription)!)
        }
    }
    
    func uploadVideos(completion: @escaping ((ExerciseVideoModel) -> Void),failure: @escaping ((NSError?)) -> Void) {
        let apiManager = APIManager()
        var params = [String : Any]()
        params["title"] = self.title
        apiManager.uploadVideos(parameters: params, imageFiles: self.filesData, completion: { (responseData) in
            if let jsonObject : [String : Any] = responseData.result.value as? [String : Any]{
                let statusCode = jsonObject["result_code"] as! Bool
                if statusCode {
                    CommonUtility.showSuccessCRNotifications(title: "Success!!", message: NSLocalizedString("title.success.video.uploaded.successfully", comment: "This message shown after the password change successfully."))
                    do {
                        if let data = responseData.data {
                            let decoder = JSONDecoder()
                            let videoList = try decoder.decode(ExerciseVideoModel.self, from: data)
                            completion(videoList)
                        }
                    } catch  {
                        CommonUtility.showErrorCRNotifications(title: NSLocalizedString("title.error.occur", comment: "Error is shown when the json is unable to decode"), message: jsonObject["message"] as! String)
                    }
                }else {
                    CommonUtility.showErrorCRNotifications(title: appTitle(), message: jsonObject["message"] as! String)
                }
            }
        }) { (error) in
            CommonUtility.showErrorCRNotifications(title: "Error!", message: (error?.localizedDescription)!)
        }
    }
    
    func getImageList(completion: @escaping ((ExerciseLibraryModel) -> Void)) {
        let apiManager = APIManager()
        let parameters = [String : Any]()
        apiManager.getImages(parameters: parameters, completion: { (responseData) in
            if let jsonObject : [String : Any] = responseData.result.value as? [String : Any]{
                let statusCode = jsonObject["result_code"] as! Bool
                if statusCode {
                    if jsonObject["result"] is NSNull {
                        let exerciseModel = ExerciseLibraryModel(result: [])
                        completion(exerciseModel)
                        return
                    }
                    do {
                        if let data = responseData.data {
                            let decoder = JSONDecoder()
                            let imageList = try decoder.decode(ExerciseLibraryModel.self, from: data)
                            completion(imageList)
                        }
                    } catch  {
                        CommonUtility.showErrorCRNotifications(title: NSLocalizedString("title.error.occur", comment: "Error is shown when the json is unable to decode"), message: jsonObject["message"] as! String)
                    }
                }else {
                    CommonUtility.showErrorCRNotifications(title: appTitle(), message: jsonObject["message"] as! String)
                }
            }
        }) { (error) in
            
        }
    }
}

struct PilateExerciseVideoViewModel {
    var filesData = [Data]()
    var title: String?
    var videoModel: ExerciseVideoModel?
    
    func getVideoList(completion: @escaping ((ExerciseVideoModel?) -> Void)) {
        let apiManager = APIManager()
        let parameters = [String : Any]()
        apiManager.getVideos(parameters: parameters, completion: { (responseData) in
            if let jsonObject : [String : Any] = responseData.result.value as? [String : Any]{
                let statusCode = jsonObject["result_code"] as! Bool
                if statusCode {
                    if jsonObject["result"] is NSNull {
                        let exerciseModel = ExerciseVideoModel(result: [])
                        completion(exerciseModel)
                        return
                    }
                    do {
                        if let data = responseData.data {
                            let decoder = JSONDecoder()
                            let videoList = try decoder.decode(ExerciseVideoModel.self, from: data)
                            completion(videoList)
                        }
                    } catch  {
                        CommonUtility.showErrorCRNotifications(title: NSLocalizedString("title.error.occur", comment: "Error is shown when the json is unable to decode"), message: jsonObject["message"] as! String)
                    }
                }else {
                    CommonUtility.showErrorCRNotifications(title: appTitle(), message: jsonObject["message"] as! String)
                }
            }
        }) { (error) in
        }
    }
}
