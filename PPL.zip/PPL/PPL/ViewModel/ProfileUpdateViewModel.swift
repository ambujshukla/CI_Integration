//
//  ProfileUpdateViewModel.swift
//  PPL
//
//  Created by cdn68 on 05/06/18.
//  Copyright © 2018 cdn. All rights reserved.
//

import UIKit

struct ProfileUpdateViewModel {
    var dob: String?
    var age: String?
    var goal1: String?
    var goal2: String?
    var weight: String?
    var height: String?
    var medicalCondition: String?
    var profileImage: UIImage?
    var firstName: String?
    var lastName: String?
    var address: String?
}

extension ProfileUpdateViewModel {
    
    func validated() -> Bool {
        if (self.dob?.isEmpty)! {
            CommonUtility.showErrorCRNotifications(title: "Error!", message: NSLocalizedString("title.alert.dob", comment: "Showing the alert when the dob is empty"))
            return false
        }else if (self.weight?.isEmpty)! {
            CommonUtility.showErrorCRNotifications(title: "Error!", message: NSLocalizedString("title.alert.weight", comment: "Showing the alert when the weight is empty"))
            return false
        }else if (self.height?.isEmpty)! {
            CommonUtility.showErrorCRNotifications(title: "Error!", message: NSLocalizedString("title.alert.height", comment: "Showing the alert when the height is empty"))
            return false
        }
        return true
    }
    
    func updateProfile() {
        let apiManager = APIManager()
        var parameters = [String : Any]()
        parameters["dob"] = self.dob
        parameters["weight"] = self.weight
        parameters["height"] = self.height
        parameters["goals"] = "\(self.goal1 ?? ""),\(self.goal2 ?? "")"
        parameters["medical_history"] = self.medicalCondition
        parameters["firstname"] = self.firstName
        parameters["lastname"] = self.lastName
        parameters["address"] = self.address
        
        let image = self.profileImage
        
        apiManager.uploadImageWithParameters(url: "\(kBaseUrl)\(kMethodProfile_Patient)", parameters: parameters, image: image!, completion: { (responseData) in
            if let jsonObject : [String : Any] = responseData.result.value as? [String : Any]{
                let statusCode = jsonObject["result_code"] as! Bool
                if statusCode {
                    do {
                        if let data = responseData.data {
                            let decoder = JSONDecoder()
                            let userModel = try decoder.decode(UserModel.self, from: data)
                            UserDefaults.standard.set(try? PropertyListEncoder().encode(userModel), forKey:UserdefaultsKey.userData.rawValue)
                            CommonUtility.showSuccessCRNotifications(title: appTitle(), message: NSLocalizedString("title.success.profile.update", comment: "This message will be shown once the profile being updated successfully."))
                        }
                    } catch  {
                        CommonUtility.showErrorCRNotifications(title: NSLocalizedString("title.error.occur", comment: "Error is shown when the json is unable to decode"), message: jsonObject["message"] as! String)
                    }
                }else {
                    CommonUtility.showErrorCRNotifications(title: appTitle(), message: jsonObject["message"] as! String)
                }
            }
        }) { (error) in
            CommonUtility.showErrorCRNotifications(title: appTitle(), message: (error?.localizedDescription)!)
        }
    }
}

