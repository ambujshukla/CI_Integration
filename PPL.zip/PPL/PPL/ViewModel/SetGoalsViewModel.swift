//
//  SetGoalsViewModel.swift
//  PPL
//
//  Created by TanjeetAjmani on 06/06/18.
//  Copyright © 2018 cdn. All rights reserved.
//

import UIKit

class SetGoalsViewModel {
    
    var dob : String = ""
    var height : String = ""
    var weight : String = ""
    var goal1 : String = ""
    var goal2 : String = ""
    var medicalConditn : String = ""
    var firstname : String = ""
    var lastname : String = ""
    var address : String = ""
}

extension SetGoalsViewModel {
    
    func validate() -> Bool {
        if self.weight.isEmpty {
            CommonUtility.showErrorCRNotifications(title: "Error!", message: NSLocalizedString("title.alert.weight", comment: "Showing the alert when the weight field is empty"))
            return false
        }
        else if self.height.isEmpty {
            CommonUtility.showErrorCRNotifications(title: "Error!", message: NSLocalizedString("title.alert.height", comment: "Showing the alert when the height field is empty"))
            return false
        }
        return true
    }
}

