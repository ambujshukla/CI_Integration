//
//  SessionsViewModel.swift
//  PPL
//
//  Created by cdn68 on 11/06/18.
//  Copyright © 2018 cdn. All rights reserved.
//

import Foundation

struct SessionsViewModel {
    var sessionListArray: SessionsListModel?
    var patientId: String?
}

extension SessionsViewModel {
 
    func sessionsList(completion: @escaping ((SessionsListModel) -> Void)) {
        let apiManager = APIManager()
        var parameters = [String : Any]()
        parameters["patient_id"] = self.patientId
        
        apiManager.sessionList(parameters: parameters, completion: { (responseData) in
            if let jsonObject : [String : Any] = responseData.result.value as? [String : Any]{
                let statusCode = jsonObject["result_code"] as! Bool
                if statusCode {
                    do {
                        if let data = responseData.data {
                            let decoder = JSONDecoder()
                            let sessionList = try decoder.decode(SessionsListModel.self, from: data)
                            completion(sessionList)
                        }
                    } catch  {
                        CommonUtility.showErrorCRNotifications(title: NSLocalizedString("title.error.occur", comment: "Error is shown when the json is unable to decode"), message: jsonObject["message"] as! String)
                    }
                }else {
                    CommonUtility.showErrorCRNotifications(title: appTitle(), message: jsonObject["message"] as! String)
                }
            }
        }) { (error) in
            
        }
    }
}
