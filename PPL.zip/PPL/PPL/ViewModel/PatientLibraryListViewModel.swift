//
//  PatientLibraryListViewModel.swift
//  PPL
//
//  Created by cdn68 on 28/06/18.
//  Copyright © 2018 cdn. All rights reserved.
//

import Foundation

struct PatientLibraryListViewModel {
    var exerciseData: PatientExerciseModel?
}

extension PatientLibraryListViewModel {
    func getExerciseList(completion: @escaping ((PatientExerciseModel) -> Void)) {
        let apiManager = APIManager()
        let parameters = [String : Any]()
        apiManager.getPatientLibraryList(methodName: kMethodGet_PatientLibrary, parameters: parameters, completion: { (responseData) in
            if let jsonObject : [String : Any] = responseData.result.value as? [String : Any]{
                let statusCode = jsonObject["result_code"] as! Bool
                if statusCode {
//                    if jsonObject["result"] is NSNull {
//                        let exerciseModel = PatientExerciseModel(result: PatientExerciseModel)
//                        completion(exerciseModel)
//                        return
//                    }
                    do {
                        if let data = responseData.data {
                            let decoder = JSONDecoder()
                            let exerciseList = try decoder.decode(PatientExerciseModel.self, from: data)
                            completion(exerciseList)
                        }
                    } catch  {
                        CommonUtility.showErrorCRNotifications(title: NSLocalizedString("title.error.occur", comment: "Error is shown when the json is unable to decode"), message: jsonObject["message"] as! String)
                    }
                }else {
                    CommonUtility.showErrorCRNotifications(title: appTitle(), message: jsonObject["message"] as! String)
                }
            }
        }) { (error) in
            
        }
    }
}
