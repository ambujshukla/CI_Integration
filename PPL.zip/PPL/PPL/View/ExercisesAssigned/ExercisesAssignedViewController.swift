//
//  ExercisesAssignedViewController.swift
//  PPL
//
//  Created by cdn68 on 04/05/18.
//  Copyright © 2018 cdn. All rights reserved.
//

import UIKit

class ExercisesAssignedViewController: UIViewController {
    
    //MARK: - Private Controls
    @IBOutlet fileprivate weak var tblView : UITableView!
    @IBOutlet fileprivate weak var btnBack : UIButton!
    
    //MARK: - life cycle
    
    override func viewDidLoad() {
        super.viewDidLoad()
        self.styleUI()
        self.styleNavigationBar()
        self.automaticallyAdjustsScrollViewInsets = false
        NotificationCenter.default.addObserver(self, selector: #selector(selectItem), name: NSNotification.Name(rawValue: "notificationName"), object: nil)
    }
    
    override func viewWillAppear(_ animated: Bool) {
        super.viewWillAppear(true)
        self.navigationController?.isNavigationBarHidden = false
    }
    
    private func styleUI()
    {
        self.view.backgroundColor = color(red: 245, green: 245, blue: 245)
    
    }
    
    @objc func selectItem(){
        self.navigationController?.pushViewController((self.storyboard?.instantiateViewController(withIdentifier: "ExerciseVideoViewController"))!, animated: true)
        
    }
    private func styleNavigationBar()
    {
        CommonUtility.createCustomBackButton(self, navBarItem: self.navigationItem, strImage: "back_icon _white", select: #selector(openPopView))
       
        
        CommonUtility.setNavBarTitle(self.navigationItem, title: NSLocalizedString("title.exercises.assigned", comment: "The title of the exercised assigned navigation bar"))
        
      //  CommonUtility.createRightBarButtons(target: self, navigationItem: self.navigationItem, select1: #selector(openProfileView), select2: #selector(openNotificationsView), select3: #selector(openSettingsView))
        
        CommonUtility.createRightBarHomeButtons(target: self, navigationItem: self.navigationItem, select1: #selector(openProfileView), select2: #selector(openDashBoardView))
        
    }
    @objc func openProfileView()
    {
        self.navigationController?.pushViewController((self.storyboard?.instantiateViewController(withIdentifier: "ProfileViewController"))!, animated: true)
    }
    
    @objc func openNotificationsView()
    {
        self.navigationController?.pushViewController((self.storyboard?.instantiateViewController(withIdentifier: "NotificationsViewController"))!, animated: true)
    }
    
    @objc func openSettingsView()
    {
        self.navigationController?.pushViewController((self.storyboard?.instantiateViewController(withIdentifier: "SettingsViewController"))!, animated: true)
    }
    
    @objc func openPopView()
    {
        self.navigationController?.popViewController(animated: true)
    }
    
    @objc func openDashBoardView()
    {
        CommonUtility.setMenuSelectedOption(menuOptionIndex: 0)
        let centerVC : UIViewController
        let storyboard =  UIStoryboard(name: "Pilates", bundle: nil)
        centerVC = storyboard.instantiateViewController(withIdentifier: "PilatesDashboardViewController")
        let centerNavVC = UINavigationController(rootViewController: centerVC)
        self.panel?.configs.centerPanelTransitionType = .moveLeft
        self.panel?.configs.centerPanelTransitionDuration = 1.0
        _ = panel?.center(centerNavVC)
   
        
    }
    
    //MARK: - Navigation Bar Methods
    @objc func doClickSideMenu()
    {
        panel?.openLeft(animated: true)
    }
    
    @IBAction func doClickBack(sender : UIButton){
        self.navigationController?.popViewController(animated: true)
    }
    
    private func configureExerciseCell(atSection section: Int) -> UITableViewCell {
        let cell = self.tblView.dequeueReusableCell(withIdentifier: "cell") as! ExercisesAssignedTableViewCell
        cell.layer.borderColor = UIColor.lightGray.cgColor
        cell.layer.borderWidth = 0.5
        cell.selectionStyle = .none
        return cell
    }
}

// MARK: - UITableViewDataSource
extension ExercisesAssignedViewController: UITableViewDataSource {
    func tableView(_ tableView: UITableView, numberOfRowsInSection section: Int) -> Int {
        return 1
    }
    
    func numberOfSections(in tableView: UITableView) -> Int {
        return 3
    }
    
    func tableView(_ tableView: UITableView, cellForRowAt indexPath: IndexPath) -> UITableViewCell {
        return self.configureExerciseCell(atSection: indexPath.section)
    }
}

extension ExercisesAssignedViewController: UITableViewDelegate
{
    func tableView(_ tableView: UITableView, heightForHeaderInSection section: Int) -> CGFloat {
        return 15
    }
    
    //func tableView(_ tableView: UITableView, didSelectRowAt indexPath: IndexPath) {
    //    if indexPath.section % 2 == 0 {
           // self.navigationController?.pushViewController((self.storyboard?.instantiateViewController(withIdentifier: "ExerciseInfoViewController"))!, animated: true)
    //
        //}else
        //{
           // self.navigationController?.pushViewController((self.storyboard?.instantiateViewController(withIdentifier: "ExerciseVideoViewController"))!, animated: true)
            
      //  }
   // }
}

