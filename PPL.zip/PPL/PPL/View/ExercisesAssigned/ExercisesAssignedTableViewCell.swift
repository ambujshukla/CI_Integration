//
//  ExercisesAssignedTableViewCell.swift
//  PPL
//
//  Created by cdn68 on 04/05/18.
//  Copyright © 2018 cdn. All rights reserved.
//

import UIKit

class ExercisesAssignedTableViewCell: UITableViewCell, UICollectionViewDataSource, UICollectionViewDelegate, UICollectionViewDelegateFlowLayout {
    
    @IBOutlet weak var collectionView: UICollectionView!
    @IBOutlet weak var viewHeader: UIView!
    @IBOutlet weak var lblHeader: UILabel!
   
    
    override func awakeFromNib() {
        super.awakeFromNib()
        self.viewHeader.backgroundColor = appColor()
//        DecorateControls.putTitle(button: btnStart, text: "Start", font: UIFont.boldSystemFont(ofSize: FONT_SIZE_22), textColor: whiteColor(), backGroundColor: appColor())
        DecorateControls.styleLabel(label: lblHeader, text: "Two Minutes Lower | Body Exercise | 3 Exercised | Regina Phallange", font:  UIFont.systemFont(ofSize: FONT_SIZE_17), textColor: whiteColor())
        self.lblHeader.isHidden = true
        self.collectionView.delegate = self
        self.collectionView.dataSource = self
    }
    
    private func configureExerciseCell(atIndexPath indexPath: NSIndexPath) -> UICollectionViewCell {
        let cell = self.collectionView.dequeueReusableCell(withReuseIdentifier: "cell", for: indexPath as IndexPath)
        return cell
    }
    
    // MARK: - UICollectionViewDataSource
    func collectionView(_ collectionView: UICollectionView, numberOfItemsInSection section: Int) -> Int {
        return 30
    }
    
    func collectionView(_ collectionView: UICollectionView, cellForItemAt indexPath: IndexPath) -> UICollectionViewCell {
        return self.configureExerciseCell(atIndexPath: indexPath as NSIndexPath)
    }
    
    func collectionView(_ collectionView: UICollectionView, layout collectionViewLayout: UICollectionViewLayout, sizeForItemAt indexPath: IndexPath) -> CGSize {
        return CGSize(width: self.collectionView.frame.size.width/3 , height: self.collectionView.frame.size.height)
    }
    
    func collectionView(_ collectionView: UICollectionView, layout collectionViewLayout: UICollectionViewLayout, minimumLineSpacingForSectionAt section: Int) -> CGFloat {
        return 30
    }
    
    func collectionView(_ collectionView: UICollectionView, layout collectionViewLayout: UICollectionViewLayout, minimumInteritemSpacingForSectionAt section: Int) -> CGFloat {
        return 0
    }
    func collectionView(_ collectionView: UICollectionView, didSelectItemAt indexPath: IndexPath) {
        print("workinggggggggg")
      NotificationCenter.default.post(name: NSNotification.Name(rawValue: "notificationName"), object: nil)
      }
}
