//
//  ExercisesAssignedCollectionViewCell.swift
//  PPL
//
//  Created by cdn68 on 04/05/18.
//  Copyright © 2018 cdn. All rights reserved.
//

import UIKit

class ExercisesAssignedCollectionViewCell: UICollectionViewCell {
    
    @IBOutlet weak var imgExercise: UIImageView!
    
    override func awakeFromNib() {
        super.awakeFromNib()
        self.imgExercise.image = #imageLiteral(resourceName: "exercise_image1")
        self.imgExercise.layer.borderColor = UIColor.lightGray.cgColor
        self.imgExercise.layer.borderWidth = 0.5
    }
}
