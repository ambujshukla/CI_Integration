
//
//  LoginViewController.swift
//  PPL
//
//  Created by cdn68 on 26/04/18.
//  Copyright © 2018 cdn. All rights reserved.
//

import UIKit
import CRNotifications
import FAPanels

enum LoginTextFieldTag: Int {
    case usernameTextFieldTag = 100
    case passwordTextFieldTag
}

class LoginViewController: UIViewController {
    
    @IBOutlet weak var tfPassword : UITextField!
    @IBOutlet weak var tfUsername : UITextField!
    @IBOutlet fileprivate weak var btnLogin : UIButton!
    
    @IBOutlet fileprivate weak var btnForgot : UIButton!
    @IBOutlet fileprivate weak var lblTitle : UILabel!
    @IBOutlet fileprivate weak var lblSignUp : UILabel!
    @IBOutlet fileprivate weak var imgPasswordIcon : UIImageView!
    @IBOutlet fileprivate weak var imgUserIcon : UIImageView!
    @IBOutlet fileprivate weak var imgLoginIcon : UIImageView!
    @IBOutlet fileprivate weak var imgBg : UIImageView!
    
    @IBOutlet fileprivate weak var btnBack : UIButton!
    
    var loginViewModel = LoginViewModel()
    
    override func viewDidLoad() {
        super.viewDidLoad()
        self.styleUI()
    }
    
    private func styleUI()
    {
        self.imgBg.image = #imageLiteral(resourceName: "background_img")
        self.imgLoginIcon.image = #imageLiteral(resourceName: "logo_newUser")
        self.imgUserIcon.image = #imageLiteral(resourceName: "user_icon")
        self.imgPasswordIcon.image = #imageLiteral(resourceName: "password_icon")
        self.btnLogin.layer.cornerRadius = 5
        self.btnForgot.contentHorizontalAlignment = .right
        self.btnBack.setImage(#imageLiteral(resourceName: "back_icon"), for: .normal)
        self.navigationController?.isNavigationBarHidden = true
        
        self.lblSignUp.attributedText = self.loginViewModel.signupText()
        self.lblTitle.attributedText = self.loginViewModel.patientPilatesText()
        
        let tapG = UITapGestureRecognizer.init(target: self, action: #selector(self.doClickSignup(sender:)))
        tapG.numberOfTapsRequired = 1
        self.lblSignUp.isUserInteractionEnabled = true
        self.lblSignUp.addGestureRecognizer(tapG)
        
        DecorateControls.putTitle(button: btnLogin, text: "Login", font: UIFont.boldSystemFont(ofSize: 28), textColor:whiteColor(), backGroundColor: appColor())
        DecorateControls.putTitle(button: btnForgot, text: "Forgot Password?", font: UIFont.boldSystemFont(ofSize: FONT_SIZE_18), textColor: color(red: 116, green: 116, blue: 116), backGroundColor: UIColor.clear)
        DecorateControls.putText(textField: tfUsername, text: "", placehoder: "User Name", font: UIFont.boldSystemFont(ofSize: FONT_SIZE_18), textColor: UIColor.darkGray)
        DecorateControls.putText(textField: tfPassword, text: "", placehoder: "Password", font: UIFont.boldSystemFont(ofSize: FONT_SIZE_18), textColor: UIColor.darkGray)
        
        self.tfPassword.isSecureTextEntry = true
        self.tfUsername.delegate = self
        self.tfPassword.delegate = self
        self.tfUsername.tag = LoginTextFieldTag.usernameTextFieldTag.rawValue
        self.tfPassword.tag = LoginTextFieldTag.passwordTextFieldTag.rawValue
        
//        //#if targetEnvironment(simulator)
//        if CommonUtility.isPilate() {
//            self.tfUsername.text = "cdn_pilate"
//            self.tfPassword.text = "Cdn@123456"
//            self.loginViewModel.username = "cdn_pilate"
//            self.loginViewModel.pasword = "Cdn@12345"
//        }else {
//            self.tfUsername.text = "cdn_patient"
//            self.tfPassword.text = "Cdn@12345"
//            self.loginViewModel.username = "cdn_patient"
//            self.loginViewModel.pasword = "Cdn@12345"
//        }
//        //#endif
        
        tfUsername.attributedPlaceholder = NSAttributedString(string: "User Name",attributes: [NSAttributedStringKey.foregroundColor: UIColor.darkGray])
        tfPassword.attributedPlaceholder = NSAttributedString(string: "Password",attributes: [NSAttributedStringKey.foregroundColor: UIColor.darkGray])
    }
    
    @IBAction func doClickBack(sender : UIButton){
        self.navigationController?.popViewController(animated: true)
    }
    
    @IBAction func doClickLogin(sender : UIButton){
        if self.loginViewModel.validate() {
            self.loginViewModel.login { (usermodel) in
                CommonUtility.showSuccessCRNotifications(title: appTitle(), message: NSLocalizedString("title.success.login", comment: "This message shown after successful login"))
                if usermodel.result.profile_status == "1" {
                    if CommonUtility.isPilate() {
                        self.navigateToDashboard()
                    }else {
                        DispatchQueue.main.asyncAfter(deadline: .now() + 1.0) {
                            self.navigateToDashboard()
                        }
                    }
                }else {
                    if CommonUtility.isPilate() {
                        let mainStoryboard: UIStoryboard = UIStoryboard(name: "Pilates", bundle: nil)
                        let pushVc = mainStoryboard.instantiateViewController(withIdentifier: "DoctorProfileUpdationViewController") as! DoctorProfileUpdationViewController
                        self.navigationController?.pushViewController(pushVc, animated: true)
                    }else {
                        let userModel: UserModel = CommonUtility.userProfile()!
                        let vc = self.storyboard?.instantiateViewController(withIdentifier: "SetGoalsViewController") as! SetGoalsViewController
                        vc.setGoalsViewModel.firstname = userModel.result.firstname!
                        vc.setGoalsViewModel.lastname = userModel.result.lastname!
                        vc.setGoalsViewModel.address = userModel.result.address!
                        self.navigationController?.pushViewController(vc, animated: true)
                    }
                }
            }
        }
    }
    
    func navigateToDashboard()
    {
        let mainStoryboard: UIStoryboard = UIStoryboard(name: "Main", bundle: nil)
        let leftMenuVC: MenuViewController = mainStoryboard.instantiateViewController(withIdentifier: "MenuViewController") as! MenuViewController
        let centerVC : UIViewController
        if CommonUtility.isPilate() {
            let storyboard =  UIStoryboard(name: "Pilates", bundle: nil)
            centerVC = storyboard.instantiateViewController(withIdentifier: "PilatesDashboardViewController")
        }else{
            centerVC = mainStoryboard.instantiateViewController(withIdentifier: "DashboardViewController")
        }
        let centerNavVC = UINavigationController(rootViewController: centerVC)
        //  Set the Panel controllers with just two lines of code
        let panelVC = FAPanelController()
        panelVC.configs.leftPanelWidth = kLeftPanelWidth
        panelVC.leftPanelPosition = .front
        
        _ = panelVC.center(centerNavVC).left(leftMenuVC)
        
        UIView.transition(from: self.view, to: centerVC.view, duration: 0.0, options: UIViewAnimationOptions.transitionCrossDissolve) { (finished) in
            _ = panelVC.center(centerNavVC).left(leftMenuVC); UIApplication.shared.keyWindow?.rootViewController = panelVC
        }
    }
    
    @IBAction func doClickForgot(sender : UIButton){
        self.navigationController?.pushViewController((self.storyboard?.instantiateViewController(withIdentifier: "ForgotPasswordViewController"))!, animated: true)
    }
    
    @objc func doClickSignup(sender: UITapGestureRecognizer? = nil)
    {
        self.navigationController?.pushViewController((self.storyboard?.instantiateViewController(withIdentifier: "RegistrationViewController"))!, animated: true)
    }
    
    override func touchesBegan(_ touches: Set<UITouch>, with event: UIEvent?) {
        self.view.endEditing(true)
    }
}

extension LoginViewController:  UITextFieldDelegate {
    func textField(_ textField: UITextField, shouldChangeCharactersIn range: NSRange, replacementString string: String) -> Bool {
        if let text = textField.text as NSString? {
            let txtAfterUpdate = text.replacingCharacters(in: range, with: string)
            if textField.tag == LoginTextFieldTag.usernameTextFieldTag.rawValue {
                self.loginViewModel.username = txtAfterUpdate
            }else {
                self.loginViewModel.pasword = txtAfterUpdate
            }
        }
        return true
    }
}
