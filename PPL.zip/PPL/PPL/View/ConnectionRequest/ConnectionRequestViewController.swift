//
//  ViewController.swift
//  NewRqstPopUp
//
//  Created by PujaDwivedi on 10/05/18.
//  Copyright © 2018 PujaDwivedi. All rights reserved.
//

import UIKit

class ConnectionRequestViewController: UIViewController {
    
    @IBOutlet weak var vwUploadRoundBox : UIView!
    @IBOutlet weak var headerDetailLbl: UILabel!
    @IBOutlet weak var btnOK: UIButton!
    @IBOutlet weak var lblHeader: UILabel!
    @IBOutlet weak var imgHeader: UIImageView!
    
    override func viewDidLoad() {
        super.viewDidLoad()
        decorateUI()
        lblHeader.text = "Connection Request"
        lblHeader.font = UIFont.systemFont(ofSize: 22)
        lblHeader.textAlignment = .center
        imgHeader.backgroundColor = UIColor.init(red: 230/255.0 , green: 230/255.0 , blue: 230/255.0 , alpha: 1)
        btnOK.setTitle("OK", for: .normal)
        btnOK.titleLabel?.font = UIFont.boldSystemFont(ofSize: 24)
        btnOK.setTitleColor(whiteColor(), for: .normal)
        btnOK.layer.cornerRadius = 5.0
        btnOK.backgroundColor = UIColor.init(red: 232/255.0, green: 188/255.0, blue: 81/255.0, alpha: 1)
        headerDetailLbl.text = "Request has been sent to the pilate. You will get notified if they accept it."
        headerDetailLbl.textAlignment = .center
        headerDetailLbl.textColor = UIColor.init(red: 45/255.0 , green: 46/255.0 , blue: 44/255.0 , alpha: 0.8)
        headerDetailLbl.font = UIFont.systemFont(ofSize: 19)
        
    }
    
    override func touchesBegan(_ touches: Set<UITouch>, with event: UIEvent?) {
        if let touch = touches.first {
            if touch.view == self.view {
                self.hideViewWithAnimation()
            }
        }
    }
    
    func decorateUI(){
        self.view.backgroundColor = UIColor.black.withAlphaComponent(0.6)
        self.vwUploadRoundBox.layer.cornerRadius = 7
        self.vwUploadRoundBox.layer.shadowOpacity = 0.8
        self.vwUploadRoundBox.layer.borderWidth = 1.0
        self.vwUploadRoundBox.layer.borderColor = UIColor.black.cgColor
        self.vwUploadRoundBox.clipsToBounds = true
        self.showAnimation()
    }
    
    func showAnimation(){
        self.view.alpha = 0
        self.vwUploadRoundBox.transform = CGAffineTransform(scaleX: 0.1, y: 0.1)
        UIView.animate(withDuration: 0.3) {
            self.vwUploadRoundBox.transform = CGAffineTransform(scaleX: 1.0, y: 1.0)
            self.view.alpha = 1
        }
    }
    
    func hideViewWithAnimation() {
        UIView.animate(withDuration: 0.3, animations: {
            self.vwUploadRoundBox.transform = CGAffineTransform(scaleX: 0.1, y: 0.1)
            self.view.alpha = 0
        }, completion: {
            (value: Bool) in
            self.removeFromParentViewController()
            self.view.removeFromSuperview()
        })
    }
    @IBAction func btnOkactn(_ sender: UIButton) {
        self.hideViewWithAnimation()
    }
}


