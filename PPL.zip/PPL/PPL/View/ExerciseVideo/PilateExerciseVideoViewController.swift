//
//  PilateExerciseVideoViewController.swift
//  PPL
//
//  Created by TanjeetAjmani on 31/05/18.
//  Copyright © 2018 cdn. All rights reserved.
//

import UIKit
import AVKit

class PilateExerciseVideoViewController: UIViewController ,AVPlayerViewControllerDelegate {
    
    @IBOutlet weak var btnPlay: UIButton!
    var exerciseVideoViewMopdel = PilateExerciseVideoViewModel()
    var playerViewController = AVPlayerViewController()
    var playerView :AVPlayer?
    
    @IBOutlet weak var viewVideo: UIView!
    
    @IBOutlet weak var lblChannel: UILabel!
    @IBOutlet weak var lblExerciseAssigned: UILabel!
    @IBOutlet weak var imgExercise: UIImageView!
    @IBOutlet weak var viewLabels: UIView!
    
    var selectURL = ""
    var thumbnailImg : UIImage?
    @IBOutlet fileprivate weak var btnBack : UIButton!
    
    override func viewDidLoad() {
        super.viewDidLoad()
        self.styleUI()
        self.styleNavigationBar()
    }
    
    override func viewWillAppear(_ animated: Bool) {
        super.viewWillAppear(true)
        self.navigationController?.isNavigationBarHidden = false
    }
    
    
    private func styleUI() {
      //  imgExercise.image = #imageLiteral(resourceName: "bear")
          imgExercise.image = thumbnailImg
        DecorateControls.styleLabel(label: lblExerciseAssigned, text: " Exercises Assigned", font: UIFont.systemFont(ofSize: FONT_SIZE_34), textColor: color(red: 63, green: 169, blue: 237))
        
        let attrs1 = [NSAttributedStringKey.font : UIFont.systemFont(ofSize: 20), NSAttributedStringKey.foregroundColor : UIColor.white]
        
        let attrs2 = [NSAttributedStringKey.font : UIFont.systemFont(ofSize: 20), NSAttributedStringKey.foregroundColor : UIColor.init(red: 63/255.0, green: 169/255.0, blue: 237/255.0, alpha: 1)]
        
        let attributedString1 = NSMutableAttributedString(string:" from", attributes:attrs1)
        
        let attributedString2 = NSMutableAttributedString(string:" Your Channel", attributes:attrs2)
        
        attributedString1.append(attributedString2)
        self.lblChannel.attributedText = attributedString1
    }
    
    private func styleNavigationBar()
    {
        CommonUtility.createCustomBackButton(self, navBarItem: self.navigationItem, strImage: "back_icon _white", select: #selector(openPopView))
        
        CommonUtility.setNavBarTitle(self.navigationItem, title: NSLocalizedString("title.exercises.assigned", comment: "The title of the exercised assigned navigation bar"))
        
        // CommonUtility.createRightBarButtons(target: self, navigationItem: self.navigationItem, select1: #selector(openProfileView), select2: #selector(openNotificationsView), select3: #selector(openSettingsView))
        
        CommonUtility.createRightBarHomeButtons(target: self, navigationItem: self.navigationItem, select1: #selector(openProfileView), select2: #selector(openDashBoardView))
    }
    @objc func openProfileView()
    {
       self.navigationController?.pushViewController((self.storyboard?.instantiateViewController(withIdentifier: "DoctorProfileViewController"))!, animated: true)
       
    }
    
    @objc func openDashBoardView()
    {
        CommonUtility.setMenuSelectedOption(menuOptionIndex: 0)
        let centerVC : UIViewController
        let storyboard =  UIStoryboard(name: "Pilates", bundle: nil)
        centerVC = storyboard.instantiateViewController(withIdentifier: "PilatesDashboardViewController")
        let centerNavVC = UINavigationController(rootViewController: centerVC)
        self.panel?.configs.centerPanelTransitionType = .moveLeft
        self.panel?.configs.centerPanelTransitionDuration = 1.0
        _ = panel?.center(centerNavVC)
    }
    
    @objc func openPopView()
    {
        self.navigationController?.popViewController(animated: true)
    }
    
    
    @objc func openSettingsView()
    {
        self.navigationController?.pushViewController((self.storyboard?.instantiateViewController(withIdentifier: "SettingsViewController"))!, animated: true)
    }
    
    //MARK: - Navigation Bar Methods
    @objc func doClickSideMenu()
    {
        panel?.openLeft(animated: true)
    }
    
    
    override func viewDidAppear(_ animated: Bool) {
        
//        guard let path = Bundle.main.path(forResource: "https://s3-ap-southeast-2.amazonaws.com/pilateslogic/FreeVideo/1529274582.mp4", ofType:"mp4") else {
//            return
//        }
//       let videoURL = URL(string :"https://s3-ap-southeast-2.amazonaws.com/pilateslogic/FreeVideo/1529274582.mp4")
        let videoURL = URL(string: selectURL)
        self.playerView = AVPlayer(url: (videoURL)!)
        
        self.playerViewController = AVPlayerViewController()
        self.playerViewController.player = self.playerView
        playerViewController.view.frame = self.viewVideo.bounds
        
        self.viewVideo.addSubview(playerViewController.view)
        self.viewVideo.bringSubview(toFront: self.viewLabels)
        
        NotificationCenter.default.addObserver(self, selector:#selector(self.playerDidFinishPlaying(note:)),name: NSNotification.Name.AVPlayerItemDidPlayToEndTime, object: playerView?.currentItem)
    }
    
    @objc func playerDidFinishPlaying(note: NSNotification){
        print("Video Finished")
        if CommonUtility.isPilate(){
            
        }
        else
        {
            let pushVc = self.storyboard?.instantiateViewController(withIdentifier: "PersonalDetailsViewController") as! PersonalDetailsViewController
            self.navigationController?.pushViewController(pushVc, animated: true)
        }
        
    }
    @IBAction func doClickBack(sender : UIButton){
        self.navigationController?.popViewController(animated: true)
    }
}
