//
//  ViewController.swift
//  PilateDetail
//
//  Created by TanjeetAjmani on 27/04/18.
//  Copyright © 2018 TanjeetAjmani. All rights reserved.
//

import UIKit

class PilateDetailViewController: UIViewController {
    
    
    @IBOutlet weak var CosmosView: UIView!
    @IBOutlet var viewProfile: UIView!
    @IBOutlet weak var imageThirdSeperator: UIImageView!
    @IBOutlet weak var imageFirstSepertor: UIImageView!
    @IBOutlet weak var imageSecondSepertor: UIImageView!
    @IBOutlet weak var imagePerson: UIImageView!
    @IBOutlet weak var btnAppointment: UIButton!
    @IBOutlet weak var btnAddPilate: UIButton!
    @IBOutlet weak var btnReview: UIButton!
    @IBOutlet weak var lblRatings: UILabel!
    
    @IBOutlet weak var viewImageUser: UIView!
    @IBOutlet weak var textViewOtherDetails: UITextView!
    @IBOutlet weak var lblOtherDetails: UILabel!
    @IBOutlet weak var lblExperienceDetail: UILabel!
    @IBOutlet weak var lblExpertiseDetail: UILabel!
    @IBOutlet weak var lblQualificatnDetail: UILabel!
    @IBOutlet weak var lblExperience: UILabel!
    @IBOutlet weak var lblExpertise: UILabel!
    @IBOutlet weak var lblQualification: UILabel!
    @IBOutlet weak var lblName: UILabel!
    @IBOutlet fileprivate weak var btnBack : UIButton!
    
    @IBOutlet weak var viewRating: UIView!
    var isBackBtnSelected : Bool?
    var pilateDetailModel = PilateDetailViewModel()
    var pilateModel: PilateList?
    var alreadyAddedaPilate: Bool = false
    var pilateViewModel = PilateListViewModel()

    override func viewDidLoad() {
        super.viewDidLoad()
        self.styleNavigationBar()
        if self.pilateModel == nil {
            self.getPilateList()
        }else {
            self.styleUI()
        }
    }
    
    override func viewWillAppear(_ animated: Bool) {
        super.viewWillAppear(animated)
        self.navigationController?.isNavigationBarHidden = false
        if self.isBackBtnSelected == true {
            
        }else {
            CommonUtility.createCustomBackButton(self, navBarItem: self.navigationItem, strImage: "menu_slide", select: #selector(doClickSideMenu))
        }
    }
    
    private func styleUI()
    {
        self.btnAddPilate.layer.cornerRadius = 5
        self.btnAddPilate.clipsToBounds = true
        self.btnReview.layer.cornerRadius = 5
        self.btnReview.clipsToBounds = true
        self.btnReview.backgroundColor = UIColor.init(red: 227/255.0, green: 193/255.0, blue: 68/255.0, alpha: 1)
        self.btnAppointment.layer.cornerRadius = 5
        self.btnAppointment.clipsToBounds = true
        self.btnAddPilate.isEnabled = false
        self.btnAddPilate.alpha = 0.5
        
        DecorateControls.styleLabel(label: lblName, text: "Regina Phallange", font: UIFont.boldSystemFont(ofSize: FONT_SIZE_25), textColor: blackColor())
        DecorateControls.styleLabel(label: lblQualification, text: "Qualification :", font: UIFont.boldSystemFont(ofSize: FONT_SIZE_18), textColor: color(red: 116, green: 116, blue: 116))
        DecorateControls.styleLabel(label: lblQualificatnDetail, text: ":\("\t")Ph. D,BPT", font: UIFont.boldSystemFont(ofSize: FONT_SIZE_18), textColor: color(red: 116, green: 116, blue: 116))
        DecorateControls.styleLabel(label: lblExpertise, text: "Expertise", font: UIFont.boldSystemFont(ofSize: FONT_SIZE_18), textColor: color(red: 116, green: 116, blue: 116))
        DecorateControls.styleLabel(label: lblExpertiseDetail, text: ":\("\t")Ankle,Shoulder Sprains", font: UIFont.boldSystemFont(ofSize: FONT_SIZE_18), textColor: color(red: 116, green: 116, blue: 116))
        DecorateControls.styleLabel(label: lblExperience, text: "Experience", font: UIFont.boldSystemFont(ofSize: FONT_SIZE_18), textColor: color(red: 116, green: 116, blue: 116))
        DecorateControls.styleLabel(label: lblExperienceDetail, text: ":\("\t")12 Years", font: UIFont.boldSystemFont(ofSize: FONT_SIZE_18), textColor: color(red: 116, green: 116, blue: 116))
        DecorateControls.styleLabel(label: lblOtherDetails, text: "Other Details :", font: UIFont.boldSystemFont(ofSize: FONT_SIZE_25), textColor: blackColor())
        DecorateControls.putTitle(button: btnReview, text: "Write a Review", font: UIFont.boldSystemFont(ofSize: FONT_SIZE_20), textColor: whiteColor(), backGroundColor: appColor())
        DecorateControls.putTitle(button: btnAddPilate, text: self.pilateStatus(), font: UIFont.boldSystemFont(ofSize: FONT_SIZE_20), textColor: whiteColor(), backGroundColor: appColor())
        DecorateControls.putTitle(button: btnAppointment, text: "Book an Appointment", font: UIFont.boldSystemFont(ofSize: FONT_SIZE_20), textColor: whiteColor(), backGroundColor: appColor())
        DecorateControls.styleLabel(label: lblRatings, text: "Ratings :", font: UIFont.boldSystemFont(ofSize: FONT_SIZE_28), textColor: blackColor())
        DecorateControls.putText(textView: textViewOtherDetails, text: "Lorem ipsum dolor sit er elit lamet, consectetaur cillium adipisicing pecu, sed do eiusmod tempor incididunt ut labore et dolore magna aliqua. Ut enim ad minim veniam, quis nostrud exercitation ullamco laboris nisi ut aliquip ex ea commodo consequat. Duis aute irure dolor in reprehenderit in voluptate velit esse cillum dolore eu fugiat nulla pariatur. Excepteur sint occaecat cupidatat non proident.", font: UIFont.boldSystemFont(ofSize: FONT_SIZE_16
        ), textColor: color(red: 116, green: 116, blue: 116))
        
        self.imagePerson.image = #imageLiteral(resourceName: "Image")
        self.textViewOtherDetails.isEditable = false
       
        if (self.pilateModel?.request_send == 1) {
            self.disableAddasPilateButton()
        }
        
        self.stylePilateDetails(pilateInfoModel: self.pilateModel!)
        self.CosmosView.isUserInteractionEnabled = false
    
    }
    
    func styleNavigationBar()
    {
        CommonUtility.createCustomBackButton(self, navBarItem: self.navigationItem, strImage: "back_icon _white", select: #selector(popViewContrller))
        
        CommonUtility.setNavBarTitle(self.navigationItem, title: NSLocalizedString("title.pilates", comment: "The title of the pilates detailview navigation bar"))
        
        
        CommonUtility.createRightBarHomeButtons(target: self, navigationItem: self.navigationItem, select1: #selector(openProfileView), select2: #selector(openDashBoardView))
    }
    
    func getPilateList() {
        self.pilateViewModel.doctorList { (pilateListArray) in
            if pilateListArray.result.count > 0 {
             self.pilateViewModel.pilateList = pilateListArray
                guard let arrPilateList = self.pilateViewModel.pilateList?.result.filter({$0.my_client == 1})  else {
                    return
                }
                if arrPilateList.count > 0 {
                self.pilateModel = arrPilateList[0]
                self.styleUI()
                } else {
                    self.viewProfile.isHidden = true
                    self.viewImageUser.isHidden = true
                    self.viewRating.isHidden = true
                    CommonUtility.loadNoDataFound(vc: self,message: NSLocalizedString("title.error.nodata", comment: "Showing no data found."))
                    return
                }
            }
        }
    }
    
    //MARK: - Navigation Bar Methods
    @objc func doClickSideMenu()
    {
        panel?.openLeft(animated: true)
    }
    
    @objc func openDashBoardView()
    {
        CommonUtility.setMenuSelectedOption(menuOptionIndex: 0)
        let centerVC : UIViewController
        let storyboard =  UIStoryboard(name: "Main", bundle: nil)
        centerVC = storyboard.instantiateViewController(withIdentifier: "DashboardViewController")
        let centerNavVC = UINavigationController(rootViewController: centerVC)
        self.panel?.configs.centerPanelTransitionType = .moveLeft
        self.panel?.configs.centerPanelTransitionDuration = 1.0
        _ = panel?.center(centerNavVC)
    }
    
    @objc func popViewContrller()
    {
        self.navigationController?.popViewController(animated: true)
    }
    
    @objc func openProfileView()
    {
    let storyboard = UIStoryboard(name: "Main", bundle: nil)
        self.navigationController?.pushViewController((storyboard.instantiateViewController(withIdentifier: "ProfileViewController")), animated: true)
    }
    
    @objc func openNotificationsView()
    {
        self.navigationController?.pushViewController((self.storyboard?.instantiateViewController(withIdentifier: "NotificationsViewController"))!, animated: true)
    }
    
    @objc func openSettingsView()
    {
        self.navigationController?.pushViewController((self.storyboard?.instantiateViewController(withIdentifier: "SettingsViewController"))!, animated: true)
    }
    
    override func viewWillLayoutSubviews() {
        super.viewWillLayoutSubviews()
        
        self.viewImageUser.layer.borderWidth = 1
        self.viewImageUser.layer.masksToBounds = true
        self.viewImageUser.layer.borderColor = UIColor.lightGray.cgColor
        self.viewImageUser.layer.cornerRadius = viewImageUser.frame.width/2
        viewImageUser.clipsToBounds = true
        
        self.imagePerson.layer.borderWidth = 1
        self.imagePerson.layer.masksToBounds = true
        self.imagePerson.layer.cornerRadius = imagePerson.frame.width/2
        imagePerson.clipsToBounds = true
    }
    
    @IBAction func doClickBack(sender : UIButton){
        self.navigationController?.popViewController(animated: true)
    }

    @IBAction func doAddPilate(_ sender: Any) {
        if self.alreadyAddedaPilate {
            CommonUtility.showInfoCRNotifications(title: appTitle(), message: NSLocalizedString("title.pilate.added.already", comment: "This message is shown when there is already a pilate been added."))
            return
        }
        self.pilateDetailModel.doctorId = (self.pilateModel?.user_id)!
        self.pilateDetailModel.addPilateRequest(completion: {
            let popupViewCtrl = self.storyboard?.instantiateViewController(withIdentifier: "ConnectionRequestViewController") as! ConnectionRequestViewController
            let window = UIApplication.shared.keyWindow
            window?.addSubview(popupViewCtrl.view)
            self.addChildViewController(popupViewCtrl)
            self.disableAddasPilateButton()
        }) { (error) in
            
        }
    }
    
    func disableAddasPilateButton() {
        self.btnAddPilate.setTitle(NSLocalizedString("title.pilate.request.sent", comment: "This shows when the patient already sent the request."), for: .normal)
        self.btnAddPilate.isEnabled = false
    }
    
    @IBAction func doAppointment(_ sender: Any) {
        let pushVc = self.storyboard?.instantiateViewController(withIdentifier: "AddAppointmentViewController") as! AddAppointmentViewController
        self.navigationController?.pushViewController(pushVc, animated: true)
    }
    
    func stylePilateDetails(pilateInfoModel: PilateList) {
        self.lblQualification.text = "Qualification :"
            self.lblExpertise.text = "Expertise       :"
           self.lblExperience.text = "Experience    :"
    self.lblName.text = pilateInfoModel.username
    self.lblQualificatnDetail.text = pilateInfoModel.qualification
    self.lblExpertiseDetail.text = pilateInfoModel.expertise
    self.lblExperienceDetail.text = pilateInfoModel.experience
    self.imagePerson.sd_setImage(with: URL(string: pilateInfoModel.profile_image), placeholderImage: #imageLiteral(resourceName: "no-inage"))
    
    }
    @IBAction func doReview(_ sender: UIButton) {
        let popupViewCtrl = self.storyboard?.instantiateViewController(withIdentifier: "ReviewViewController") as! ReviewViewController
        popupViewCtrl.strDoctorId = (self.pilateModel?.user_id)!
        let window = UIApplication.shared.keyWindow
        window?.addSubview(popupViewCtrl.view)
        self.addChildViewController(popupViewCtrl)
    }
    
    func pilateStatus() -> String {
        if self.pilateModel?.request_send == 1 {
            return NSLocalizedString("title.pilate.request.sent", comment: "This title shown when the request is sent but no activity has been performed.")
        }else if self.pilateModel?.request_send == 2 {
            return NSLocalizedString("title.pilate.request.declined", comment: "This title shown when the request is declined.")
        }else if self.pilateModel?.my_client == 1 {
            return NSLocalizedString("title.pilate.request.accepted", comment: "This title shown when the request is accepted.")
        }
        self.btnAddPilate.isEnabled = true
        self.btnAddPilate.alpha = 1.0
        return NSLocalizedString("title.pilate.add", comment: "This title shown when the request has not been sent yet.")
    }
}
