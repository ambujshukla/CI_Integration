//
//  CustomTableViewCell.swift
//  PilateImageDetail
//
//  Created by TanjeetAjmani on 02/05/18.
//  Copyright © 2018 TanjeetAjmani. All rights reserved.
//

import UIKit

class NotificationsTableViewCell : UITableViewCell {
    
    @IBOutlet weak var imgSeperator: UIImageView!
    @IBOutlet weak var lblTime: UILabel!
    @IBOutlet weak var lblNotificationMessage: UILabel!
    
    override func awakeFromNib() {
        super.awakeFromNib()
        DecorateControls.styleLabel(label: lblNotificationMessage, text: "", font: UIFont.boldSystemFont(ofSize: 18), textColor: blackColor())
        DecorateControls.styleLabel(label: lblTime, text: "", font: UIFont.boldSystemFont(ofSize: 16), textColor: blackColor())
    }
}
