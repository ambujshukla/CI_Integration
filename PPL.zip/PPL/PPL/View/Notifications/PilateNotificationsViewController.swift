//
//  PilateNotificationsViewController.swift
//  PPL
//
//  Created by TanjeetAjmani on 31/05/18.
//  Copyright © 2018 cdn. All rights reserved.
//

import UIKit
import EmptyDataSet_Swift

class PilateNotificationsViewController: UIViewController,UITableViewDelegate,UITableViewDataSource {
    
    @IBOutlet weak var tableViewNotificatn: UITableView!
    var arrNotifivatn = [["lblNotificatn" : "Regina Phallange has accepted your request to connect", "lblTime" :"2 min ago"],["lblNotificatn" : "Your request for appointment has been successfully", "lblTime" : "2 min ago"]]
    
    override func viewDidLoad() {
        super.viewDidLoad()
        self.styleUI()
        self.navigationBarStyle()
        self.tableViewNotificatn.tableFooterView = UIView()
        tableViewNotificatn.contentInset = UIEdgeInsets(top: -1, left: 0, bottom: 0, right: 0)
        
    }
    
    func styleUI()
    {
        self.tableViewNotificatn.tableFooterView = UIView()
        self.tableViewNotificatn.isScrollEnabled = false
        
    }
    
    func navigationBarStyle (){
        
        CommonUtility.createCustomBackButton(self, navBarItem: self.navigationItem, strImage: "menu_slide", select: #selector(doClickSideMenu))
        CommonUtility.setNavBarTitle(self.navigationItem, title: NSLocalizedString("Notifications", comment: "The title of the Profile navigation bar"))
        CommonUtility.createRightBarHomeButtons(target: self, navigationItem: self.navigationItem, select1: #selector(openProfileView), select2: #selector(openDashBoardView))
        
    }
    
    @objc func openProfileView()
    {
    self.navigationController?.pushViewController((self.storyboard?.instantiateViewController(withIdentifier: "DoctorProfileViewController"))!, animated: true)
       
    }
    
    @objc func openDashBoardView()
    {
        CommonUtility.setMenuSelectedOption(menuOptionIndex: 0)
        let centerVC : UIViewController
        let storyboard =  UIStoryboard(name: "Pilates", bundle: nil)
        centerVC = storyboard.instantiateViewController(withIdentifier: "PilatesDashboardViewController")
        let centerNavVC = UINavigationController(rootViewController: centerVC)
        self.panel?.configs.centerPanelTransitionType = .moveLeft
        self.panel?.configs.centerPanelTransitionDuration = 1.0
        _ = panel?.center(centerNavVC)
    }
    
    @objc func openNotificationsView()
    {
        self.navigationController?.pushViewController((self.storyboard?.instantiateViewController(withIdentifier: "NotificationsViewController"))!, animated: true)
    }
    
    @objc func openSettingsView()
    {
        self.navigationController?.pushViewController((self.storyboard?.instantiateViewController(withIdentifier: "SettingsViewController"))!, animated: true)
    }
    
    
    
    //MARK: - Navigation Bar Methods
    @objc func doClickSideMenu()
    {
        panel?.openLeft(animated: true)
    }
    
    func tableView(_ tableView: UITableView, numberOfRowsInSection section: Int) -> Int {
        return arrNotifivatn.count
    }
    
    func tableView(_ tableView: UITableView, cellForRowAt indexPath: IndexPath) -> UITableViewCell {
        let cell = tableView.dequeueReusableCell(withIdentifier: "cell") as! NotificationsTableViewCell
        cell.selectionStyle = .none
        cell.contentView.layer.borderWidth = 1
        cell.contentView.layer.borderColor = color(red: 242, green: 242, blue: 242).cgColor
        
        cell.lblNotificationMessage.text = arrNotifivatn[indexPath.row]["lblNotificatn"]
        cell.lblTime.text = arrNotifivatn[indexPath.row]["lblTime"]
        cell.selectionStyle = .none
        return cell
    }
    
    func tableView(_ tableView: UITableView, heightForHeaderInSection section: Int) -> CGFloat {
        return section == 0 ? 1.0 : 32
    }
    
    func tableView(_ tableView: UITableView, heightForRowAt indexPath: IndexPath) -> CGFloat {
        return 70
    }
    
}

extension PilateNotificationsViewController: EmptyDataSetSource, EmptyDataSetDelegate {
    func title(forEmptyDataSet scrollView: UIScrollView) -> NSAttributedString? {
        return CommonUtility.dzEmptySetTitle(title: NSLocalizedString("title.error.nodata", comment: "This string shows when there is no data found."))
    }
    
    func buttonTitle(forEmptyDataSet scrollView: UIScrollView, for state: UIControlState) -> NSAttributedString? {
        return CommonUtility.dzEmptySetButtonTitle(title: NSLocalizedString("title.retry", comment: "This gives the option for retry when there is no data."))
    }
    
    func emptyDataSet(_ scrollView: UIScrollView, didTapButton button: UIButton) {
      //  self.getClientsList()
    }
}
