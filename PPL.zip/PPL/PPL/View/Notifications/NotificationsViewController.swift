//
//  NotificationViewController.swift
//  PilateImageDetail
//
//  Created by TanjeetAjmani on 02/05/18.
//  Copyright © 2018 TanjeetAjmani. All rights reserved.
//Puja


import UIKit
import EmptyDataSet_Swift

class NotificationsViewController: UIViewController,UITableViewDelegate,UITableViewDataSource {
    
    @IBOutlet weak var tableViewNotificatn: UITableView!
    
    var arrNotificationList: NotificationsModel!
    
    override func viewDidLoad() {
        super.viewDidLoad()
        self.styleUI()
        self.styleNavigationBar()
        self.styleNavigationBar()
        self.tableViewNotificatn.tableFooterView = UIView()
        tableViewNotificatn.contentInset = UIEdgeInsets(top: -1, left: 0, bottom: 0, right: 0)
        self.getNotifications()
    }
    
    func styleUI()
    {
        self.tableViewNotificatn.tableFooterView = UIView()
        self.tableViewNotificatn.isScrollEnabled = true
        
    }
    
    func styleNavigationBar()
    {
        CommonUtility.createCustomBackButton(self, navBarItem: self.navigationItem, strImage: "menu_slide", select: #selector(doClickSideMenu))
        
        CommonUtility.setNavBarTitle(self.navigationItem, title: NSLocalizedString("title.notifications", comment: "The title of the notifications navigation bar"))
        
        CommonUtility.createRightBarHomeButtons(target: self, navigationItem: self.navigationItem, select1: #selector(openProfileView), select2: #selector(openDashBoardView))
    }
    
    func getNotifications() {
        let apiManager = APIManager()
        let params = [String : Any]()
        apiManager.notificationsList(parameters: params, completion: { (responseData) in
            if let jsonObject : [String : Any] = responseData.result.value as? [String : Any]{
                let statusCode = jsonObject["result_code"] as! Bool
                if statusCode {
                    do {
                        if let data = responseData.data {
                            let decoder = JSONDecoder()
                            let notificationList = try decoder.decode(NotificationsModel.self, from: data)
                            self.arrNotificationList = notificationList
                            if self.arrNotificationList.result.count > 0 {
                                self.tableViewNotificatn.reloadData()
                            }
                        }
                    } catch  {
                        CommonUtility.showErrorCRNotifications(title: NSLocalizedString("title.error.occur", comment: "Error is shown when the json is unable to decode"), message: jsonObject["message"] as! String)
                    }
                }else {
                    CommonUtility.showErrorCRNotifications(title: appTitle(), message: jsonObject["message"] as! String)
                }
            }
        }) { (error) in
            
        }
    }
    
    @objc func openProfileView()
    {
    self.navigationController?.pushViewController((self.storyboard?.instantiateViewController(withIdentifier: "ProfileViewController"))!, animated: true)
    }
    
    @objc func openNotificationsView()
    {
        self.navigationController?.pushViewController((self.storyboard?.instantiateViewController(withIdentifier: "NotificationsViewController"))!, animated: true)
    }
    
    @objc func openSettingsView()
    {
        self.navigationController?.pushViewController((self.storyboard?.instantiateViewController(withIdentifier: "SettingsViewController"))!, animated: true)
    }
    
    @objc func openDashBoardView()
    {
        CommonUtility.setMenuSelectedOption(menuOptionIndex: 0)
        let centerVC : UIViewController
        let storyboard =  UIStoryboard(name: "Main", bundle: nil)
        centerVC = storyboard.instantiateViewController(withIdentifier: "DashboardViewController")
        let centerNavVC = UINavigationController(rootViewController: centerVC)
        self.panel?.configs.centerPanelTransitionType = .moveLeft
        self.panel?.configs.centerPanelTransitionDuration = 1.0
        _ = panel?.center(centerNavVC)
    }
    
    //MARK: - Navigation Bar Methods
    @objc func doClickSideMenu()
    {
        panel?.openLeft(animated: true)
    }
    
    func tableView(_ tableView: UITableView, numberOfRowsInSection section: Int) -> Int {
        if self.arrNotificationList == nil {
            return 0
        }
        return self.arrNotificationList.result.count
    }
    
    func tableView(_ tableView: UITableView, cellForRowAt indexPath: IndexPath) -> UITableViewCell {
        let cell = tableView.dequeueReusableCell(withIdentifier: "cell") as! NotificationsTableViewCell
        cell.selectionStyle = .none
        cell.contentView.layer.borderWidth = 1
        cell.contentView.layer.borderColor = color(red: 242, green: 242, blue: 242).cgColor
//        let notification = self.arrNotificationList[indexPath.row]
        cell.lblNotificationMessage.text = self.arrNotificationList.result[indexPath.row].msg
        cell.lblTime.text = CommonUtility.changeDateFormateOfDate(obj: self.arrNotificationList.result[indexPath.row].created_at!, oldFormate: "yyyy-MM-dd HH:mm:ss", newFormate: "yyyy-MM-dd hh:mm")
        cell.selectionStyle = .none
        return cell
    }
    
    func tableView(_ tableView: UITableView, heightForHeaderInSection section: Int) -> CGFloat {
        return section == 0 ? 1.0 : 32
    }
    
    func tableView(_ tableView: UITableView, heightForRowAt indexPath: IndexPath) -> CGFloat {
        return 70
    }
    
}

extension NotificationsViewController: EmptyDataSetSource, EmptyDataSetDelegate {
    func title(forEmptyDataSet scrollView: UIScrollView) -> NSAttributedString? {
        return CommonUtility.dzEmptySetTitle(title: NSLocalizedString("title.error.nodata", comment: "This string shows when there is no data found."))
    }
    
    func buttonTitle(forEmptyDataSet scrollView: UIScrollView, for state: UIControlState) -> NSAttributedString? {
        return CommonUtility.dzEmptySetButtonTitle(title: NSLocalizedString("title.retry", comment: "This gives the option for retry when there is no data."))
    }
    
    func emptyDataSet(_ scrollView: UIScrollView, didTapButton button: UIButton) {
//        self.getClientsList()
    }
}
