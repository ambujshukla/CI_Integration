
//
//  ForgotPasswordViewController.swift
//  PPL
//
//  Created by cdn68 on 26/04/18.
//  Copyright © 2018 cdn. All rights reserved.
//

import UIKit

class ForgotPasswordViewController: UIViewController {
    
    //MARK: Private Variables
    @IBOutlet  weak var tfEmail : UITextField!
    @IBOutlet  weak var tfUsername : UITextField!
    @IBOutlet fileprivate weak var imgBg : UIImageView!
    @IBOutlet fileprivate weak var imgKey : UIImageView!
    @IBOutlet fileprivate weak var imgUserIcon : UIImageView!
    @IBOutlet fileprivate weak var imgEmailIcon : UIImageView!
    @IBOutlet fileprivate weak var btnSend : UIButton!
    @IBOutlet fileprivate weak var lblHeader : UILabel!
    @IBOutlet fileprivate weak var btnBack : UIButton!
    
    //MARK: Life cycle
    override func viewDidLoad() {
        super.viewDidLoad()
        self.styleUI()
    }
    
    //MARK: Private Methods
    
    private func styleUI()
    {
        self.imgBg.image = #imageLiteral(resourceName: "background_img")
        self.imgKey.image = #imageLiteral(resourceName: "forgot_key")
        self.imgEmailIcon.image = #imageLiteral(resourceName: "email_icon")
        self.imgUserIcon.image = #imageLiteral(resourceName: "user_icon")
        self.btnSend.layer.cornerRadius = 5
        
        self.btnBack.setImage( #imageLiteral(resourceName: "back_icon"), for: .normal)
        DecorateControls.putText(textField: tfEmail, text: "", placehoder: "Email address", font: UIFont.boldSystemFont(ofSize: FONT_SIZE_18), textColor: UIColor.darkGray)
        DecorateControls.putText(textField: tfUsername, text: "", placehoder: "Username (optional)", font: UIFont.boldSystemFont(ofSize: FONT_SIZE_18), textColor: UIColor.darkGray)
        DecorateControls.putTitle(button: btnSend, text: "Send an Email", font: UIFont.boldSystemFont(ofSize: FONT_SIZE_28), textColor: whiteColor(), backGroundColor: appColor())
        DecorateControls.styleLabel(label: lblHeader, text: "Forgot Password?", font: UIFont.boldSystemFont(ofSize: FONT_SIZE_35), textColor: blackColor())
        
        self.tfEmail.keyboardType = UIKeyboardType.emailAddress
        
        tfEmail.attributedPlaceholder = NSAttributedString(string: "Email Address",attributes: [NSAttributedStringKey.foregroundColor: UIColor.darkGray])
        tfUsername.attributedPlaceholder = NSAttributedString(string: "Username (optional)",attributes: [NSAttributedStringKey.foregroundColor: UIColor.darkGray])
    }
    
    @IBAction func doClickSendEmail(sender : UIButton)
    {   
        let (isValid , message) = CommonUtility.doValidateForgotPassword(self)
        
        if isValid {
            let apiManager = APIManager()
            var parameters = [String : Any]()
            parameters["email"] = self.tfEmail.text
            parameters["username"] = self.tfUsername.text
            apiManager.forgotPassword(methodName: (CommonUtility.isPilate() ? kMethodForgotPassword_Doctor: kMethodForgotPassword_Patient), parameters: parameters, completion: { (response) in
                let resultCode = response["result_code"] as! Bool
                if resultCode {
                    CommonUtility.showSuccessCRNotifications(title: "Success!!", message: message)
                    self.navigationController?.popViewController(animated: true)
                }else {
                    CommonUtility.showErrorCRNotifications(title: appTitle(), message: response["message"] as! String)
                }
            }) { (error) in
                CommonUtility.showErrorCRNotifications(title: "Error!", message: (error?.localizedDescription)!)
            }
        }else{
            CommonUtility.showErrorCRNotifications(title: "Error!", message: message)
        }
    }
    
    @IBAction func doClickBack(sender : UIButton){
        self.navigationController?.popViewController(animated: true)
    }
    
    override func touchesBegan(_ touches: Set<UITouch>, with event: UIEvent?) {
        self.view.endEditing(true)
    }
}
