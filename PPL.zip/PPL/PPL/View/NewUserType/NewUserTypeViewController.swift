
//
//  NewUserTypeViewController.swift
//  PPL
//
//  Created by cdn68 on 25/04/18.
//  Copyright © 2018 cdn. All rights reserved.
//

import UIKit

class NewUserTypeViewController: UIViewController {
    
    @IBOutlet weak var imgBottomBg: UIImageView!
    @IBOutlet fileprivate var imgTopBg : UIImageView!
    @IBOutlet fileprivate var imgLogo : UIImageView!
    @IBOutlet fileprivate var imgClient : UIImageView!
    @IBOutlet fileprivate var imgInstructor : UIImageView!
    @IBOutlet fileprivate var imgCenter : UIImageView!
    
    @IBOutlet fileprivate var lblHeader : UILabel!
    @IBOutlet fileprivate var lblWelcome : UILabel!
    @IBOutlet fileprivate var lblClientTitle : UILabel!
    @IBOutlet fileprivate var lblInstructorTitle : UILabel!
    
    override func viewDidLoad() {
        super.viewDidLoad()
        styleUI()
    }
    
    override func touchesBegan(_ touches: Set<UITouch>, with event: UIEvent?) {
        if let touch = touches.first {
            if touch.view == self.imgBottomBg {
                let location = touch.location(in: imgBottomBg)
                if(imgBottomBg.image?.isYelloPixelColor(pos: location))!{
                    UserDefaults.standard.set(true, forKey: UserdefaultsKey.isUserPilate.rawValue)
                    self.navigationController?.pushViewController((self.storyboard?.instantiateViewController(withIdentifier: "LoginViewController"))!, animated: true)
                }else{
                    UserDefaults.standard.set(false, forKey: UserdefaultsKey.isUserPilate.rawValue)
                    self.navigationController?.pushViewController((self.storyboard?.instantiateViewController(withIdentifier: "LoginViewController"))!, animated: true)
                }
            }
        }
    }
    
    // MARK: Private Methods
    private func styleUI()
    {
        self.imgLogo.image = #imageLiteral(resourceName: "logo_newUser")
        self.imgClient.image = #imageLiteral(resourceName: "Clients")
        self.imgInstructor.image = #imageLiteral(resourceName: "Instructor")
        self.imgCenter.backgroundColor = UIColor(red: 41/255.0, green: 63/255.0, blue: 70/255.0, alpha: 1.0)
        self.imgTopBg.image = #imageLiteral(resourceName: "background_img")
        self.lblWelcome.text = "WELCOME TO PILATES HOME PROGRAM"
        self.lblWelcome.textColor = UIColor.white
        
        self.lblClientTitle.textColor = UIColor.white
        self.lblInstructorTitle.textColor = UIColor.white
        
        self.navigationController?.isNavigationBarHidden = true
        CommonUtility.setMenuSelectedOption(menuOptionIndex: 0)
        
        let attrs11 = [NSAttributedStringKey.font : UIFont.boldSystemFont(ofSize: 35), NSAttributedStringKey.foregroundColor : UIColor.black]
        let attrs22 = [NSAttributedStringKey.font : UIFont.systemFont(ofSize: 35), NSAttributedStringKey.foregroundColor : UIColor.black]
        
        let attributedString11 = NSMutableAttributedString(string:"Patient ", attributes:attrs11)
        let attributedString22 = NSMutableAttributedString(string:"Pilates", attributes:attrs22)
        
        attributedString11.append(attributedString22)
        self.lblHeader.attributedText = attributedString11
        
        DecorateControls.styleLabel(label: self.lblClientTitle, text: NSLocalizedString("Patient", comment: "This the text for the client option"), font: UIFont.boldSystemFont(ofSize: 32), textColor: whiteColor())
        
        DecorateControls.styleLabel(label: self.lblInstructorTitle, text: NSLocalizedString("Pilate", comment: "This the text for the instructor option"), font: UIFont.boldSystemFont(ofSize: 32), textColor: whiteColor())
        
        DecorateControls.styleLabel(label: self.lblWelcome, text: NSLocalizedString("WELCOME TO PILATES HOME PROGRAM", comment: "This the text for the user type selection").uppercased(), font: UIFont.boldSystemFont(ofSize: 32), textColor: whiteColor())
    }
    
    @IBAction func doClickClientOption(sender : UIButton){
        
        UserDefaults.standard.set(false, forKey: UserdefaultsKey.isUserPilate.rawValue)
        self.navigationController?.pushViewController((self.storyboard?.instantiateViewController(withIdentifier: "LoginViewController"))!, animated: true)
    }
    
    @IBAction func doClickInstructorOption(sender : UIButton){
        UserDefaults.standard.set(true, forKey: UserdefaultsKey.isUserPilate.rawValue)
        self.navigationController?.pushViewController((self.storyboard?.instantiateViewController(withIdentifier: "LoginViewController"))!, animated: true)
    }
}

extension UIImage {
    func isYelloPixelColor(pos: CGPoint) -> Bool {
        let pixelData:NSData = (self.cgImage?.dataProvider?.data)!
        let data: UnsafePointer<UInt8> = CFDataGetBytePtr(pixelData)
        
        let pixelInfo: Int = ((Int(self.size.width) * Int(pos.y)) + Int(pos.x)) * 4
        
        let r = CGFloat(data[pixelInfo]) / CGFloat(255.0)
        let g = CGFloat(data[pixelInfo+1]) / CGFloat(255.0)
        let b = CGFloat(data[pixelInfo+2]) / CGFloat(255.0)
        //let a = CGFloat(data[pixelInfo+3]) / CGFloat(255.0)
        //return UIColor(red: r, green: g, blue: b, alpha: a)
        return (r>b && g>b)
    }
}
