//
//  MyClassCollectionViewCell.swift
//  PPL
//
//  Created by TanjeetAjmani on 14/05/18.
//  Copyright © 2018 cdn. All rights reserved.
//

import UIKit

class MyClassCollectionViewCell: UICollectionViewCell {
    
    @IBOutlet weak var imgSeperator: UIImageView!
    @IBOutlet weak var btnMyExercise: UIButton!
    @IBOutlet weak var imgExercise: UIImageView!
 
    override func awakeFromNib() {
        DecorateControls.putTitle(button: btnMyExercise, text: "", font: UIFont.systemFont(ofSize: FONT_SIZE_16), textColor: blackColor(), backGroundColor: whiteColor())
       
    }
 
}

