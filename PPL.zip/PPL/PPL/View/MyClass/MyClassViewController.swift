//
//  MyClassViewController.swift
//  PPL
//
//  Created by TanjeetAjmani on 14/05/18.
//  Copyright © 2018 cdn. All rights reserved.
//

import UIKit
import AVKit
import EmptyDataSet_Swift
import SDWebImage

class MyClassViewController: UIViewController,UITableViewDelegate,UITableViewDataSource,UICollectionViewDelegate,UICollectionViewDataSource,UICollectionViewDelegateFlowLayout {
    
    
    @IBOutlet weak var viewLabl: UIView!
    
    @IBOutlet weak var collectionVideos: UICollectionView!
    @IBOutlet weak var lblFromYourChannel: UILabel!
    @IBOutlet weak var lblExerciseAssigned: UILabel!
    @IBOutlet weak var imgThumbExercise: UIImageView!
    @IBOutlet weak var collectionImages: UICollectionView!
    @IBOutlet weak var lblImages: UILabel!
    @IBOutlet weak var viewVideoPlayr: UIView!
    @IBOutlet weak var btnExercise3: UIButton!
    @IBOutlet weak var btnExercise2: UIButton!
    @IBOutlet weak var btnExercise1: UIButton!
    @IBOutlet weak var viewBtn: UIView!
    @IBOutlet weak var lblClient: UILabel!
    @IBOutlet weak var lblName: UILabel!
    @IBOutlet weak var imageColorClient: UIImageView!
    @IBOutlet weak var tableViewClient: UITableView!
   
   // var arrClientName = [["name": "Josh Iwata"],["name":"Max"]]
    //var arrImages = ["exer2","exer1","exer2","exer1","exer2","exer1","exer1","exer1"]
  //  var arrMyExercise = ["Exercise 1","Exercise 2","Exercise 3","Exercise 4","Exercise 5","Exercise 6"]
    var arrImages = [Images]()
    var arrVideos = [Videos]()
    
    var playerViewController = AVPlayerViewController()
    var playerView :AVPlayer?
    var rowSelectnIndex = 0
    var videoSelectionIndex = 0
    var videoSelectedURL = ""
    
    var myClassViewModel = MyClassViewModel()
    
    override func viewDidLoad() {
        super.viewDidLoad()
        self.styleUI()
        self.navigationBarStyle()
        self.getMyClass()
        self.automaticallyAdjustsScrollViewInsets = false
      //  self.collectionVideos.scrollToItem(at:NSIndexPath(item: 0 , section: 0) as IndexPath, at: .centeredHorizontally, animated: false)
        
    }
    
    func styleUI() {
        tableViewClient.emptyDataSetDelegate = self
        tableViewClient.emptyDataSetSource = self
        imgThumbExercise.image = #imageLiteral(resourceName: "no-inage")
        DecorateControls.styleLabel(label: lblName, text:"", font: UIFont.boldSystemFont(ofSize: FONT_SIZE_22), textColor: blackColor())
        DecorateControls.styleLabel(label: lblClient, text: "Clients", font: UIFont.boldSystemFont(ofSize: FONT_SIZE_22), textColor: whiteColor())
        DecorateControls.styleLabel(label: lblImages, text: "Images", font: UIFont.systemFont(ofSize: FONT_SIZE_22), textColor: blackColor())
        DecorateControls.putTitle(button: btnExercise1, text: "Exercise1", font: UIFont.systemFont(ofSize: FONT_SIZE_16), textColor: whiteColor(), backGroundColor: appColor())
        DecorateControls.putTitle(button: btnExercise2, text: "Exercise2", font: UIFont.systemFont(ofSize: FONT_SIZE_16), textColor: blackColor(), backGroundColor: clearColor())
        DecorateControls.putTitle(button: btnExercise3, text: "Exercise3", font: UIFont.systemFont(ofSize: FONT_SIZE_16), textColor: blackColor(), backGroundColor: clearColor())
        collectionVideos.layer.cornerRadius = 5
        collectionVideos.layer.borderWidth = 1
        collectionVideos.layer.borderColor = appColor().cgColor
        collectionVideos.clipsToBounds = true
      
        lblExerciseAssigned.text = " Exercises Assigned"
        lblExerciseAssigned.textColor = UIColor.init(red: 63/255.0, green: 169/255.0, blue: 237/255.0, alpha: 1)
        lblExerciseAssigned.backgroundColor = UIColor.init(red: 39/255.0, green: 39/255.0, blue: 39/255.0, alpha: 1)
        let attrs1 = [NSAttributedStringKey.font : UIFont.systemFont(ofSize: 10), NSAttributedStringKey.foregroundColor : UIColor.white]
        
        let attrs2 = [NSAttributedStringKey.font : UIFont.systemFont(ofSize: 10), NSAttributedStringKey.foregroundColor : UIColor.init(red: 63/255.0, green: 169/255.0, blue: 237/255.0, alpha: 1)]
        
        let attributedString1 = NSMutableAttributedString(string:" from", attributes:attrs1)
        
        let attributedString2 = NSMutableAttributedString(string:" Your Channel", attributes:attrs2)
        
        attributedString1.append(attributedString2)
        self.lblFromYourChannel.attributedText = attributedString1
        lblFromYourChannel.backgroundColor = UIColor.init(red: 39/255.0, green: 39/255.0, blue: 39/255.0, alpha: 1)
        imageColorClient.backgroundColor = UIColor.init(red: 226/255.0, green: 193/255.0, blue: 68/255.0, alpha: 1)
        
        tableViewClient.separatorStyle = .none
        tableViewClient.tableFooterView = UIView()
        tableViewClient.estimatedRowHeight = 87
        tableViewClient.rowHeight = UITableViewAutomaticDimension
    }
    
    func navigationBarStyle (){
        
        CommonUtility.setNavBarTitle(self.navigationItem, title: NSLocalizedString("My Class", comment: "The title of the My Class navigation bar"))
        CommonUtility.createRightBarHomeButtons(target: self, navigationItem: self.navigationItem, select1: #selector(openProfileView), select2: #selector(openDashBoardView))
        CommonUtility.createCustomBackButton(self, navBarItem: self.navigationItem, strImage: "back_icon _white", select: #selector(openPopView))
    }
    @objc func openProfileView()
    {
       let pushVc = self.storyboard?.instantiateViewController(withIdentifier: "DoctorProfileViewController") as! DoctorProfileViewController
        self.navigationController?.pushViewController(pushVc, animated: true)
    }
    
    @objc func openDashBoardView()
    {
        CommonUtility.setMenuSelectedOption(menuOptionIndex: 0)
        let centerVC : UIViewController
        let storyboard =  UIStoryboard(name: "Pilates", bundle: nil)
        centerVC = storyboard.instantiateViewController(withIdentifier: "PilatesDashboardViewController")
        let centerNavVC = UINavigationController(rootViewController: centerVC)
        self.panel?.configs.centerPanelTransitionType = .moveLeft
        self.panel?.configs.centerPanelTransitionDuration = 1.0
        _ = panel?.center(centerNavVC)
    }
    @objc func openPopView()
    {
        self.navigationController?.popViewController(animated: true)
    }
    
    func tableView(_ tableView: UITableView, numberOfRowsInSection section: Int) -> Int {
        if let mModel = self.myClassViewModel.myClassModel {
            return (mModel.result.count)
        }
        return 0;
    }
    
    func tableView(_ tableView: UITableView, cellForRowAt indexPath: IndexPath) -> UITableViewCell {
        let cell = tableView.dequeueReusableCell(withIdentifier: "cellTV") as! MyClassTableViewCell
        cell.selectionStyle = .none
        let strFirstName = (self.myClassViewModel.myClassModel?.result[indexPath.row].firstname)!
        let strLastName = (self.myClassViewModel.myClassModel?.result[indexPath.row].lastname)!
        cell.lblClientName.text = "\(strFirstName) \(strLastName)"
         self.arrVideos = (self.myClassViewModel.myClassModel?.result[indexPath.row].video)!
        cell.imgIcon.sd_setImage(with: URL(string: (self.myClassViewModel.myClassModel?.result[indexPath.row].profile_image)!), placeholderImage: #imageLiteral(resourceName: "no-inage"))

        cell.backgroundColor  = UIColor.white
        if rowSelectnIndex == indexPath.row {
            cell.backgroundColor = colorWithAlpha(red: 172, green: 172, blue: 172, alpha: 0.25)
        }
        self.arrVideos = (self.myClassViewModel.myClassModel?.result[indexPath.row].video)!
        return cell
    }
    
    func tableView(_ tableView: UITableView, didSelectRowAt indexPath: IndexPath) {
      //  DecorateControls.styleLabel(label: lblName, text: , font: UIFont.boldSystemFont(ofSize: FONT_SIZE_22), textColor: blackColor())
        self.lblName.text = "\((self.myClassViewModel.myClassModel?.result[indexPath.row].firstname)!) \((self.myClassViewModel.myClassModel?.result[indexPath.row].lastname)!)"

        rowSelectnIndex = indexPath.row
        self.arrImages = (self.myClassViewModel.myClassModel?.result[indexPath.row].images)!
        self.collectionImages.reloadData()
        self.arrVideos = (self.myClassViewModel.myClassModel?.result[indexPath.row].video)!
        self.collectionVideos.reloadData()
        self.tableViewClient.reloadData()

    }
    
    func tableView(_ tableView: UITableView, heightForRowAt indexPath: IndexPath) -> CGFloat {
        // return UITableViewAutomaticDimension
        return 87
    }
    
    func collectionView(_ collectionView: UICollectionView, numberOfItemsInSection section: Int) -> Int {
        if collectionView == collectionVideos {
        print(arrVideos.count)
          //  let indexPath = IndexPath(item: 0, section: 0)
        //   self.arrVideos = (self.myClassViewModel.myClassModel?.result[indexPath.row].video)!
        return arrVideos.count
        }
        print(arrImages.count)
        return arrImages.count
    }
    
    func collectionView(_ collectionView: UICollectionView, cellForItemAt indexPath: IndexPath) -> UICollectionViewCell {
        if collectionView == collectionVideos {
            let cell = collectionView.dequeueReusableCell(withReuseIdentifier: "cellCV1", for: indexPath) as! MyClassCollectionViewCell
            cell.backgroundColor = blackColor()
            cell.btnMyExercise.isEnabled = false
            if videoSelectionIndex == indexPath.item {
                DecorateControls.putTitle(button: cell.btnMyExercise, text: "", font: UIFont.systemFont(ofSize: FONT_SIZE_16), textColor: whiteColor(), backGroundColor: appColor())
            } else {
                DecorateControls.putTitle(button: cell.btnMyExercise, text: "", font: UIFont.systemFont(ofSize: FONT_SIZE_16), textColor: blackColor(), backGroundColor: whiteColor())
            }
            cell.btnMyExercise.setTitle("Video \(indexPath.row + 1)", for: .normal)
           
            if videoSelectedURL == "" {
                let videoURL = URL(string: (self.arrVideos[indexPath.row].video_file)!)
                self.imgThumbExercise.image = getThumbnailImage(forUrl: videoURL!)
                self.playerView = AVPlayer(url: (videoURL)!)
                }
            else {
                let videoURL = URL(string: (videoSelectedURL))
                self.imgThumbExercise.image = getThumbnailImage(forUrl: videoURL!)
                self.playerView = AVPlayer(url: (videoURL)!)
            }
           
            self.playerViewController = AVPlayerViewController()
            self.playerViewController.player = self.playerView
            playerViewController.view.frame = self.viewVideoPlayr.bounds
            self.viewVideoPlayr.addSubview(playerViewController.view)
            self.viewVideoPlayr.bringSubview(toFront: self.viewLabl)

           
            return cell
        }
        else {
        let cell = collectionView.dequeueReusableCell(withReuseIdentifier: "cellCV", for: indexPath) as! MyClassCollectionViewCell
        cell.imgExercise.sd_setImage(with: URL(string: arrImages[indexPath.row].image_file!), placeholderImage: #imageLiteral(resourceName: "no-inage"))
        return cell
        }
        
    }
    
    func collectionView(_ collectionView: UICollectionView, didSelectItemAt indexPath: IndexPath) {
        if collectionView == collectionVideos {
            videoSelectionIndex = indexPath.item
            //self.arrVideos = (self.myClassViewModel.myClassModel?.result[indexPath.row].video)!
        let videoURL = URL(string: (self.arrVideos[indexPath.row].video_file)!)
        videoSelectedURL = (self.arrVideos[indexPath.row].video_file)!
        self.playerView = AVPlayer(url: (videoURL)!)
       self.collectionVideos.reloadData()
        }
    }
    override func viewDidAppear(_ animated: Bool) {
        
//        guard let path = Bundle.main.path(forResource: "SampleVideo_1280x720_1mb", ofType:"mp4") else {
//            return
//        }
//        let fileURL = NSURL(fileURLWithPath: path )
//        self.playerView = AVPlayer(url: fileURL as URL)
 
//        self.playerViewController = AVPlayerViewController()
//        self.playerViewController.player = self.playerView
//        playerViewController.view.frame = self.viewVideoPlayr.bounds
//        self.viewVideoPlayr.addSubview(playerViewController.view)
//        self.viewVideoPlayr.bringSubview(toFront: self.viewLabl)

    }
    
    
    func collectionView(_ collectionView: UICollectionView, layout collectionViewLayout: UICollectionViewLayout, minimumInteritemSpacingForSectionAt section: Int) -> CGFloat {
        return 0
    }
    func collectionView(_ collectionView: UICollectionView, layout collectionViewLayout: UICollectionViewLayout, minimumLineSpacingForSectionAt section: Int) -> CGFloat {
        return 0
    }
    func collectionView(_ collectionView: UICollectionView, layout collectionViewLayout: UICollectionViewLayout, insetForSectionAt section: Int) -> UIEdgeInsets {
        return UIEdgeInsetsMake(0, 0, 0, 0)
    }
    
    func collectionView(_ collectionView: UICollectionView, layout collectionViewLayout: UICollectionViewLayout, sizeForItemAt indexPath: IndexPath) -> CGSize {
        if collectionView == collectionImages {
        let cellWidth = (collectionView.frame.size.width)/6.0 - 5
        let cellHeight = (collectionView.frame.size.height)
        return CGSize(width : cellWidth , height : cellHeight)
        }
        let cellWidth = (collectionView.frame.size.width)/4.0
        let cellHeight = (collectionView.frame.size.height)
        return CGSize(width : cellWidth , height : cellHeight)
        }
    
    @IBAction func btnExer1Actn(_ sender: UIButton) {
        self.btnExercise1.isSelected = false
        self.btnExercise2.isSelected = false
        self.btnExercise3.isSelected = false
        sender.isSelected = true
        self.colorBtn()
        
        
    }
    
    func colorBtn() {
        self.btnExercise1.backgroundColor = UIColor.clear
        self.btnExercise2.backgroundColor = UIColor.clear
        self.btnExercise3.backgroundColor = UIColor.clear
        self.btnExercise1.setTitleColor(whiteColor(), for: .selected)
        self.btnExercise1.setTitleColor(blackColor(), for: .normal)
        self.btnExercise2.setTitleColor(whiteColor(), for: .selected)
        self.btnExercise2.setTitleColor(blackColor(), for: .normal)
        self.btnExercise3.setTitleColor(whiteColor(), for: .selected)
        self.btnExercise3.setTitleColor(blackColor(), for: .normal)
        
        if btnExercise1.isSelected == true {
            self.btnExercise1.backgroundColor = appColor()
            self.btnExercise2.backgroundColor = UIColor.clear
            self.btnExercise3.backgroundColor = UIColor.clear
            
        } else if btnExercise2.isSelected == true {
            self.btnExercise1.backgroundColor = UIColor.clear
            self.btnExercise2.backgroundColor = appColor()
            self.btnExercise3.backgroundColor = UIColor.clear
        }else{
            self.btnExercise1.backgroundColor = UIColor.clear
            self.btnExercise2.backgroundColor = UIColor.clear
            self.btnExercise3.backgroundColor = appColor()
        }
    }
    
    func getMyClass() {
        self.myClassViewModel.getMyClass { (myClass) in
            self.myClassViewModel.myClassModel = myClass
            
            if (self.myClassViewModel.myClassModel?.result.count)! > 0 {
                self.lblName.text =  "\((self.myClassViewModel.myClassModel?.result[0].firstname)!) \((self.myClassViewModel.myClassModel?.result[0].lastname)!)"
                
                self.tableViewClient.reloadData()
                self.arrImages = (self.myClassViewModel.myClassModel?.result[0].images)!
                self.arrVideos = (self.myClassViewModel.myClassModel?.result[0].video)!
                self.collectionImages.reloadData()
                self.collectionVideos.reloadData()
            }
        }
    }
    func getThumbnailImage(forUrl url: URL) -> UIImage? {
        let asset: AVAsset = AVAsset(url: url)
        let imageGenerator = AVAssetImageGenerator(asset: asset)
        
        do {
            let thumbnailImage = try imageGenerator.copyCGImage(at: CMTimeMake(1, 60) , actualTime: nil)
            return UIImage(cgImage: thumbnailImage)
        } catch let error {
            print(error)
        }
        return nil
    }
}

extension MyClassViewController: EmptyDataSetSource, EmptyDataSetDelegate {
    func title(forEmptyDataSet scrollView: UIScrollView) -> NSAttributedString? {
        return CommonUtility.dzEmptySetTitle(title: NSLocalizedString("title.error.nodata", comment: "This string shows when there is no data found."))
    }
    
//    func buttonTitle(forEmptyDataSet scrollView: UIScrollView, for state: UIControlState) -> NSAttributedString? {
//        return CommonUtility.dzEmptySetButtonTitle(title: NSLocalizedString("title.retry", comment: "This gives the option for retry when there is no data."))
//    }
//    
//    func emptyDataSet(_ scrollView: UIScrollView, didTapButton button: UIButton) {
//      self.getMyClass()
//    }
    
    func emptyDataSetShouldDisplay(_ scrollView: UIScrollView) -> Bool {
//        if self.arrImages.count != 0 {
//            return true
//        }
//        return false
//    }
        
        return true
}
}
