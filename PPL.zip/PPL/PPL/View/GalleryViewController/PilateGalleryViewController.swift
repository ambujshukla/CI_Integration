//
//  GalleryViewController.swift
//  TwoDimentionScroll
//
//  Created by PankajPurohit on 28/05/18.
//  Copyright © 2018 PankajPurohit. All rights reserved.
//

import UIKit
import SDWebImage

class GalleryCollectionCell: UICollectionViewCell {
    @IBOutlet weak var imgView: UIImageView!
    
    override func awakeFromNib() {
        super.awakeFromNib()
        let pinch = UIPinchGestureRecognizer(target: self, action: #selector(self.pinch(sender:)))
        imgView.isUserInteractionEnabled = true
        imgView.addGestureRecognizer(pinch)
    }
    
    @objc func pinch(sender:UIPinchGestureRecognizer) {
        if sender.state == .changed {
            let currentScale = self.imgView.frame.size.width / self.imgView.bounds.size.width
            var newScale = currentScale * sender.scale
            if newScale < 1 {
                newScale = 1
            }
            if newScale > 9 {
                newScale = 9
            }
            let transform = CGAffineTransform(scaleX: newScale, y: newScale)
            self.imgView.transform = transform
            sender.scale = 1
            
        } else if sender.state == .ended {
            
            UIView.animate(withDuration: 0.3, animations: {
                
                self.imgView.transform = CGAffineTransform.identity
                
            })
        }
    }
}

class PilateGalleryViewController: UIViewController,UICollectionViewDelegate,UICollectionViewDataSource,UICollectionViewDelegateFlowLayout {

    @IBOutlet weak var collectionPager: UICollectionView!
    @IBOutlet weak var collectionGallery: UICollectionView!
    var currentIndex : Int = 0
    var imagegallery : [ExerciseImages] = []
    var indexGallery : Int = 0
    var arrImages : [String] = ["http://static0.passel.co/wp-content/uploads/2016/08/05110349/20160731-igor-trepeshchenok-barnimages-08-768x509.jpg",
        "http://static0.passel.co/wp-content/uploads/2016/08/05095154/tumblr_oawfisUmZo1u7ns0go1_500.jpg",
                               "http://static0.passel.co/wp-content/uploads/2016/08/05095153/tumblr_obbkeo3lZW1ted1sho1_500.jpg",
        "http://static0.passel.co/wp-content/uploads/2016/08/05095153/tumblr_obaxpnJbKg1sfie3io1_500.jpg",
        "http://static0.passel.co/wp-content/uploads/2016/08/05095153/tumblr_obdehwWneK1slhhf0o1_500.jpg",
        "http://static0.passel.co/wp-content/uploads/2016/08/05095152/2016-08-01-roman-drits-barnimages-005-768x512.jpg",
        "http://static0.passel.co/wp-content/uploads/2016/08/05095151/2016-08-01-roman-drits-barnimages-003-768x512.jpg",
        "http://static0.passel.co/wp-content/uploads/2016/08/05095149/tumblr_obbjwp1bDz1ted1sho1_500.jpg",
        "http://static0.passel.co/wp-content/uploads/2016/08/05095151/tumblr_oawfhnxNjL1u7ns0go1_500.jpg",
        "http://static0.passel.co/wp-content/uploads/2016/08/05095150/tumblr_ob6xvqXLoB1tlwzgvo1_500.jpg",
        "http://static0.passel.co/wp-content/uploads/2016/08/05095148/20160731-igor-trepeshchenok-barnimages-10-768x512.jpg",
        "http://static0.passel.co/wp-content/uploads/2016/08/03092421/tumblr_oawfgd2G941u7ns0go1_500.jpg",
        "http://static0.passel.co/wp-content/uploads/2016/08/03092423/tumblr_ob6xutS8N21tlwzgvo1_500.jpg",
        "http://static0.passel.co/wp-content/uploads/2016/08/03092421/tumblr_o86sgm6F7a1ted1sho1_500.jpg",
        "http://static0.passel.co/wp-content/uploads/2016/08/03092420/tumblr_ob6xudqW4U1tlwzgvo1_500.jpg",
        "http://static0.passel.co/wp-content/uploads/2016/08/03092420/2016-08-01-roman-drits-barnimages-002-768x512.jpg",
        "http://static0.passel.co/wp-content/uploads/2016/08/03092418/tumblr_o97fatuGnd1ted1sho1_500.jpg",
        "http://static0.passel.co/wp-content/uploads/2016/08/03092420/tumblr_oawff12j9L1u7ns0go1_500.jpg",
        "http://static0.passel.co/wp-content/uploads/2016/08/03092420/2016-08-01-roman-drits-barnimages-001-768x512.jpg",
        "http://static0.passel.co/wp-content/uploads/2016/08/03092423/tumblr_ob6xutS8N21tlwzgvo1_500.jpg",
        "http://static0.passel.co/wp-content/uploads/2016/08/03092417/tumblr_o97gyqSK3k1ted1sho1_500.jpg",
        "http://static0.passel.co/wp-content/uploads/2016/07/03092417/20160731-igor-trepeshchenok-barnimages-07-768x512.jpg",
        "http://static0.passel.co/wp-content/uploads/2016/07/03092605/tumblr_ob6wjiCBUh1tlwzgvo1_500.jpg",
        "http://static0.passel.co/wp-content/uploads/2016/07/03092604/tumblr_ob6wkn58cJ1tlwzgvo1_500.jpg",
        "http://static0.passel.co/wp-content/uploads/2016/07/03092416/tumblr_ob6wk7mns81tlwzgvo1_500.jpg",
        "http://static0.passel.co/wp-content/uploads/2016/07/03092413/tumblr_ob6vv04yIP1tlwzgvo1_500.jpg",
        "http://static0.passel.co/wp-content/uploads/2016/07/03092414/tumblr_ob6vk1bBPa1tlwzgvo1_500.jpg",
        "http://static0.passel.co/wp-content/uploads/2016/07/03092404/tumblr_o97ipvkger1ted1sho1_500.jpg"]
    var exerciseImageModel = PilateExerciseLibraryViewModel()
    override func viewDidLoad() {
        super.viewDidLoad()
        self.collectionPager.scrollToItem(at:NSIndexPath(item: indexGallery , section: 0) as IndexPath, at: .centeredHorizontally, animated: false)
        self.navigationBarStyle()
        
    }
    
    func navigationBarStyle() {
        CommonUtility.setNavBarTitle(self.navigationItem, title: NSLocalizedString("Gallery", comment: "The title of the Profile navigation bar"))
        CommonUtility.createCustomBackButton(self, navBarItem: self.navigationItem, strImage: "back_icon _white", select: #selector(openPopView))
    }
    
    @objc func openPopView()
    {
        self.navigationController?.popViewController(animated: true)
    }
    //MARK: - UICollectionViewDatasource Methods
    func collectionView(_ collectionView: UICollectionView, numberOfItemsInSection section: Int) -> Int {
        return self.imagegallery.count
    }
    
    func collectionView(_ collectionView: UICollectionView, cellForItemAt indexPath: IndexPath) -> UICollectionViewCell {
        if collectionView == collectionPager  {
            let cell = collectionView.dequeueReusableCell(withReuseIdentifier: "CellPager", for: indexPath) as! GalleryCollectionCell
            cell.imgView.sd_addActivityIndicator()
            cell.imgView.sd_showActivityIndicatorView()
            cell.imgView.sd_setImage(with: URL(string: imagegallery[indexPath.row].image_file!), placeholderImage: #imageLiteral(resourceName: "no-inage"))
            return cell
        }else{
            let cell = collectionView.dequeueReusableCell(withReuseIdentifier: "CellGallery", for: indexPath) as! GalleryCollectionCell
            cell.imgView.sd_addActivityIndicator()
            cell.imgView.sd_showActivityIndicatorView()
            cell.imgView.sd_setImage(with: URL(string: imagegallery[indexPath.row].image_file!), placeholderImage: #imageLiteral(resourceName: "no-inage"))
            return cell
        }
    }
    
    //MARK: - UICollectionViewDelegateFlowLayout Methods
    func collectionView(_ collectionView: UICollectionView, layout collectionViewLayout: UICollectionViewLayout, sizeForItemAt indexPath: IndexPath) -> CGSize {
        if collectionView == collectionPager  {
            return CGSize(width: collectionView.frame.size.width, height: collectionView.frame.size.height)
        }else{
            return CGSize(width: 160, height: collectionView.frame.size.height)
        }
    }
    
    func collectionView(_ collectionView: UICollectionView, didSelectItemAt indexPath: IndexPath) {
        if collectionView == collectionGallery  {
            collectionPager.scrollToItem(at: indexPath, at: .centeredHorizontally, animated: true)
        }
    }
}
