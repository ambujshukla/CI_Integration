//
//  WebViewController.swift
//  PPL
//
//  Created by PujaDwivedi on 23/05/18.
//  Copyright © 2018 cdn. All rights reserved.
//

import UIKit
import WebKit


class WebViewController: UIViewController , WKUIDelegate,WKNavigationDelegate{
    
    @IBOutlet weak var myWebView: WKWebView!
    var webView: WKWebView!
    var isTitleText : Bool?
    
    @IBOutlet weak var activityIndicator: UIActivityIndicatorView!
    
    override func loadView() {
        super.loadView()
        let webConfiguration = WKWebViewConfiguration()
        webView = WKWebView(frame: view.frame, configuration: webConfiguration)
        webView.uiDelegate = self
    }
    
    override func viewDidLoad() {
        super.viewDidLoad()
        
        self.view.addSubview(webView)
        let myURL = URL(string: "https://www.apple.com")
        let myRequest = URLRequest(url: myURL!)
        webView.isUserInteractionEnabled = true
        webView.load(myRequest)
        self.webView.navigationDelegate = self
        self.activityIndicator.hidesWhenStopped = true
        self.activityIndicator.activityIndicatorViewStyle = UIActivityIndicatorViewStyle.gray
        self.activityIndicator.startAnimating()
        self.view.addSubview(activityIndicator)
        self.styleNavigationBar()
        self.styleUI()
        
    }
    
    //    func webView(_ webView: WKWebView, didReceive challenge: URLAuthenticationChallenge, completionHandler: @escaping (URLSession.AuthChallengeDisposition, URLCredential?) -> Void) {
    //        if let serverTrust = challenge.protectionSpace.serverTrust {
    //            completionHandler(.useCredential, URLCredential(trust: serverTrust))
    //        }
    //    }
    
    func styleUI() {
        if self.isTitleText == true {
            CommonUtility.setNavBarTitle(self.navigationItem, title: NSLocalizedString("About Us", comment: "The title of the navigation bar"))
        }
        else {
            CommonUtility.setNavBarTitle(self.navigationItem, title: NSLocalizedString("Terms & Conditions", comment: "The title of the navigation bar"))
        }
    }
    func styleNavigationBar()
    {
        
        CommonUtility.createRightBarHomeButtons(target: self, navigationItem: self.navigationItem, select1: #selector(openProfileView), select2: #selector(openDashBoardView))
        CommonUtility.createCustomBackButton(self, navBarItem: self.navigationItem, strImage: "back_icon _white", select: #selector(openPopView))
    }
    
    @objc func openProfileView(){
        if CommonUtility.isPilate() {
         let storyboard =  UIStoryboard(name: "Pilates", bundle: nil)
         self.navigationController?.pushViewController((storyboard.instantiateViewController(withIdentifier: "DoctorProfileViewController")), animated: true)
        }
        else {
            let storyboard =  UIStoryboard(name: "Main", bundle: nil)
       self.navigationController?.pushViewController((storyboard.instantiateViewController(withIdentifier: "ProfileViewController")), animated: true)
      
        }
    }
    
    @objc func openPopView()
    {
        self.navigationController?.popViewController(animated: true)
    }
    
    @objc func openDashBoardView(){
     
        CommonUtility.setMenuSelectedOption(menuOptionIndex: 0)
        if CommonUtility.isPilate() {
        
            let centerVC : UIViewController
            let storyboard = UIStoryboard(name: "Pilates", bundle: nil)
            centerVC = storyboard.instantiateViewController(withIdentifier: "PilatesDashboardViewController")
            let centerNavVC = UINavigationController(rootViewController: centerVC)
            self.panel?.configs.centerPanelTransitionType = .moveLeft
            self.panel?.configs.centerPanelTransitionDuration = 1.0
            _ = panel?.center(centerNavVC)
        }
        else {
            let centerVC : UIViewController
            let storyboard = UIStoryboard(name: "Main", bundle: nil)
            centerVC = storyboard.instantiateViewController(withIdentifier: "DashboardViewController")
            let centerNavVC = UINavigationController(rootViewController: centerVC)
            self.panel?.configs.centerPanelTransitionType = .moveLeft
            self.panel?.configs.centerPanelTransitionDuration = 1.0
            _ = panel?.center(centerNavVC)
    }
    }
    //    func showActivityIndicator(show: Bool) {
    //        if show {
    //            activityIndicator.startAnimating()
    //        } else {
    //            activityIndicator.stopAnimating()
    //        }
    //    }
    //
    func webView(_ webView: WKWebView, didFinish navigation: WKNavigation!) {
        activityIndicator.stopAnimating()
    }
    
    
    
}

