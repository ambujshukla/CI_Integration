//
//  ViewController.swift
//  TwoDimentionScroll
//
//  Created by PankajPurohit on 24/05/18.
//  Copyright © 2018 PankajPurohit. All rights reserved.
//

import UIKit
import MBCircularProgressBar
import ScrollableGraphView

class ProgressTableCell: UITableViewCell {
    @IBOutlet weak var collectionPercentage: UICollectionView!
    @IBOutlet weak var lblTitle: UILabel!
    
    override func awakeFromNib() {
        DecorateControls.styleLabel(label: lblTitle, text: "", font: UIFont.systemFont(ofSize: FONT_SIZE_22), textColor: blackColor())
    }
}

class ProgressCollectionCell: UICollectionViewCell {
    @IBOutlet weak var lblTitle: UILabel!
    @IBOutlet weak var lblTotal: UILabel!
    @IBOutlet weak var lblGoal: UILabel!
    
    override func awakeFromNib() {
        DecorateControls.styleLabel(label: lblTitle, text: "", font: UIFont.systemFont(ofSize: FONT_SIZE_22), textColor: whiteColor())
        DecorateControls.styleLabel(label: lblGoal, text: "Goal", font: UIFont.systemFont(ofSize: FONT_SIZE_18), textColor: blackColor())
        DecorateControls.styleLabel(label: lblTotal, text: "Total", font: UIFont.systemFont(ofSize: FONT_SIZE_18), textColor: blackColor())
    }
}

class MyProgressViewController: UIViewController,UITableViewDelegate,UITableViewDataSource,UICollectionViewDelegate,UICollectionViewDataSource,UICollectionViewDelegateFlowLayout,ScrollableGraphViewDataSource {
    @IBOutlet weak var topView: UIView!
    @IBOutlet weak var bottomView: UIView!
    @IBOutlet weak var barChart: ScrollableGraphView!
    @IBOutlet weak var progressView: MBCircularProgressBarView!
    @IBOutlet weak var collectionHeader: UICollectionView!
    @IBOutlet weak var tblProgress: UITableView!
    @IBOutlet weak var btnAddDetails: UIButton!
    
    private var x:CGFloat = 0.0
    private var y:CGFloat = 0.0
    var arrWeeks : [String] = ["Week 1","Week 2","Week 3","Week 4","Week 5","Week 6","Week 7","Week 8","Week 9","Week 10","Week 11","Week 12","Week 13","Week 14","Week 15","Week 16","Week 17","Week 18","Week 19","Week 20","Week 21","Week 22","Week 23","Week 24","Week 25","Week 26","Week 27","Week 28","Week 29","Week 30","Week 31","Week 32","Week 33","Week 34","Week 35","Week 36","Week 37","Week 38","Week 39","Week 40","Week 41","Week 42","Week 43","Week 44","Week 45","Week 46","Week 47","Week 48","Week 49","Week 50","Week 51","Week 52"]
    var arrTitle : [String] = ["Weight Loss","Calories Burnt","Nutrition","Weight Loss","Calories Burnt","Nutrition"]
    lazy var barPlotData : [Double] = self.generateRandomData(self.arrWeeks.count, max: 100, shouldIncludeOutliers: false)
    
    override func viewDidLoad() {
        super.viewDidLoad()
        decorateUI()
    }
    override func viewWillAppear(_ animated: Bool) {
        super.viewWillAppear(true)
        self.navigationController?.isNavigationBarHidden = false
    }
    //MARK: - ScrollableGraphViewDataSource Methods
    func value(forPlot plot: Plot, atIndex pointIndex: Int) -> Double {
        // Return the data for each plot.
        switch(plot.identifier) {
        case "bar":
            return barPlotData[pointIndex]
        default:
            return 0
        }
    }
    
    func label(atIndex pointIndex: Int) -> String {
        // Ensure that you have a label to return for the index
        return arrWeeks[pointIndex]
    }
    
    func numberOfPoints() -> Int {
        return arrWeeks.count
    }
    
    //MARK: - UICollectionViewDatasource Methods
    func collectionView(_ collectionView: UICollectionView, numberOfItemsInSection section: Int) -> Int {
        return arrWeeks.count
    }
    
    func collectionView(_ collectionView: UICollectionView, cellForItemAt indexPath: IndexPath) -> UICollectionViewCell {
        if collectionView.tag == 1000  {
            let cell = collectionView.dequeueReusableCell(withReuseIdentifier: "CellPercentage", for: indexPath) as! ProgressCollectionCell
            DecorateControls.styleLabel(label: cell.lblGoal, text: "60%", font: UIFont.systemFont(ofSize: FONT_SIZE_18), textColor: blackColor())
            DecorateControls.styleLabel(label: cell.lblTotal, text: "50%", font: UIFont.systemFont(ofSize: FONT_SIZE_18), textColor: blackColor())
            
            return cell
        }else{
            let cell = collectionView.dequeueReusableCell(withReuseIdentifier: "CellHeader", for: indexPath) as! ProgressCollectionCell
            cell.lblTitle.text = arrWeeks[indexPath.row]
            return cell
        }
    }
    
    //MARK: - UICollectionViewDelegateFlowLayout Methods
    func collectionView(_ collectionView: UICollectionView, layout collectionViewLayout: UICollectionViewLayout, sizeForItemAt indexPath: IndexPath) -> CGSize {
        return CGSize(width: 136, height: collectionView.frame.size.height)
    }
    
    //MARK: - UITableViewDataSource Methods
    func tableView(_ tableView: UITableView, numberOfRowsInSection section: Int) -> Int {
        return arrTitle.count;
    }
    
    func tableView(_ tableView: UITableView, cellForRowAt indexPath: IndexPath) -> UITableViewCell {
        let cell = tableView.dequeueReusableCell(withIdentifier: "CellProgress", for: indexPath) as! ProgressTableCell
        cell.collectionPercentage.contentOffset.x = x
        cell.collectionPercentage.layer.setValue(indexPath, forKey: "IndexPath")
        cell.lblTitle.text = arrTitle[indexPath.row]
        cell.selectionStyle = .none
        return cell
    }
    
    @IBAction func btnAddDetailActn(_ sender: UIButton) {
        let pushVc = self.storyboard?.instantiateViewController(withIdentifier: "ExercisesAssignedViewController") as! ExercisesAssignedViewController
        self.navigationController?.pushViewController(pushVc, animated: true)
    }
    
    //MARK: - UIScrollViewDelegate methods
    func scrollViewDidScroll(_ scrollView: UIScrollView) {
        if (y != scrollView.contentOffset.y) {
            y = scrollView.contentOffset.y;
            return
        }
        
        x = scrollView.contentOffset.x
        if scrollView is UICollectionView {
            if scrollView.tag == 1000  {
                self.collectionHeader.contentOffset.x = x
            }else if scrollView == self.collectionHeader {
                self.tblProgress.reloadData()
            }
        }
    }
    
    //MARK: - UIAction methods
    @IBAction func actionAddDetailButton(_ sender: UIButton) {}
    
    //MARK: - Custom methods implementation
    private func decorateUI() {
        self.styleNavigationBar()
        DecorateControls.putTitle(button: btnAddDetails, text: "Add Details", font: UIFont.systemFont(ofSize: FONT_SIZE_25), textColor: whiteColor(), backGroundColor: appColor())
        progressView.maxValue = CGFloat(100)
        UIView.animate(withDuration: 2.0, delay: 2.0, options:.curveLinear, animations: { () -> Void in
            self.progressView.value = 75
        }, completion: { (finished: Bool) -> Void in
        })
        self.btnAddDetails.layer.cornerRadius = 10.0
        self.btnAddDetails.clipsToBounds = true
        self.createBarGraph()
        topView.dropShadow(color: .lightGray, opacity: 1, offSet: CGSize(width: -1, height: 1), radius: 3, scale: true)
        bottomView.dropShadow(color: .lightGray, opacity: 1, offSet: CGSize(width: -1, height: 1), radius: 3, scale: true)
    }
    
    func styleNavigationBar(){
        CommonUtility.createCustomBackButton(self, navBarItem: self.navigationItem, strImage: "menu_slide", select: #selector(doClickSideMenu))
        
        CommonUtility.setNavBarTitle(self.navigationItem, title: NSLocalizedString("Progress Chart", comment: "The title of the Progress Chart navigation bar"))
        // CommonUtility.createRightBarButtons(target: self, navigationItem: self.navigationItem, select1: #selector(openProfileView), select2: #selector(openNotificationsView), select3: #selector(openSettingsView))
        
        CommonUtility.createRightBarHomeButtons(target: self, navigationItem: self.navigationItem, select1: #selector(openProfileView), select2: #selector(openDashBoardView))
    }
    
    @objc func openProfileView(){
        
    self.navigationController?.pushViewController((self.storyboard?.instantiateViewController(withIdentifier: "ProfileViewController"))!, animated: true)
    
    }
    
    @objc func openNotificationsView(){
        self.navigationController?.pushViewController((self.storyboard?.instantiateViewController(withIdentifier: "NotificationsViewController"))!, animated: true)
    }
    
    @objc func openSettingsView(){
        self.navigationController?.pushViewController((self.storyboard?.instantiateViewController(withIdentifier: "SettingsViewController"))!, animated: true)
    }
    
    @objc func openDashBoardView(){
      
        CommonUtility.setMenuSelectedOption(menuOptionIndex: 0)
        let centerVC : UIViewController
        let storyboard =  UIStoryboard(name: "Main", bundle: nil)
        centerVC = storyboard.instantiateViewController(withIdentifier: "DashboardViewController")
        let centerNavVC = UINavigationController(rootViewController: centerVC)
        self.panel?.configs.centerPanelTransitionType = .moveLeft
        self.panel?.configs.centerPanelTransitionDuration = 1.0
        _ = panel?.center(centerNavVC)

    }
    
    @objc func doClickSideMenu(){
        panel?.openLeft(animated: true)
    }
    
    // min: 0
    // max: 100
    // Will not adapt min and max reference lines to range of visible points
    private func createBarGraph(){
        // Setup the plot
        let barPlot = BarPlot(identifier: "bar")
        
        barPlot.barWidth = 30
        barPlot.barLineWidth = 1
        
        barPlot.barLineColor = UIColor(red:119/255,green:119/255,blue:119/255,alpha:1)
        barPlot.barColor = UIColor(red:85/255,green:85/255,blue:85/255,alpha:1)
        
        barPlot.adaptAnimationType = ScrollableGraphViewAnimationType.elastic
        barPlot.animationDuration = 1.5
        
        // Setup the reference lines
        let referenceLines = ReferenceLines()
        
        referenceLines.referenceLineLabelFont = UIFont.boldSystemFont(ofSize: 8)
        referenceLines.referenceLineColor = UIColor.white.withAlphaComponent(0.2)
        referenceLines.referenceLineLabelColor = UIColor.white
        
        referenceLines.dataPointLabelColor = UIColor.white.withAlphaComponent(0.5)
        referenceLines.dataPointLabelFont = UIFont.systemFont(ofSize: 7)
        
        // Setup the graph
        barChart.backgroundFillColor = UIColor(red:51/255,green:51/255,blue:51/255,alpha:1)
        
        barChart.shouldAnimateOnStartup = true
        
        barChart.rangeMax = 100
        barChart.rangeMin = 0
        
        // Add everything
        barChart.addPlot(plot: barPlot)
        barChart.addReferenceLines(referenceLines: referenceLines)
        
        barChart.dataSource = self
    }
    
    // Data Generation
    private func generateRandomData(_ numberOfItems: Int, max: Double, shouldIncludeOutliers: Bool = true) -> [Double] {
        var data = [Double]()
        for _ in 0 ..< numberOfItems {
            var randomNumber = Double(arc4random()).truncatingRemainder(dividingBy: max)
            
            if(shouldIncludeOutliers) {
                if(arc4random() % 100 < 10) {
                    randomNumber *= 3
                }
            }
            
            data.append(randomNumber)
        }
        return data
    }
}

extension UIView {
    func dropShadow(color: UIColor, opacity: Float = 0.5, offSet: CGSize, radius: CGFloat = 1, scale: Bool = true) {
        layer.masksToBounds = false
        layer.shadowColor = color.cgColor
        layer.shadowOpacity = opacity
        layer.shadowOffset = offSet
        layer.shadowRadius = radius
        
        layer.shadowPath = UIBezierPath(rect: self.bounds).cgPath
        layer.shouldRasterize = true
        layer.rasterizationScale = scale ? UIScreen.main.scale : 1
    }
}
