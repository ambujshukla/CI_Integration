//
//  ViewController.swift
//  PersonalDetails
//
//  Created by PujaDwivedi on 03/05/18.
//  Copyright © 2018 PujaDwivedi. All rights reserved.
//

import UIKit
import ActionSheetPicker_3_0

enum PersonalDetails: Int {
    case weight = 0
    case hoursExperience
    case caloriesBurnt
}

class PersonalDetailsViewController: UIViewController , UITableViewDelegate , UITableViewDataSource {
    
    var arrdata  = ["Enter Weight :" , "Enter Hours of Exercise :" , "Calories Burnt :"]
    var arrWeight = ["30 kgs","31 kgs","32 kgs","33 kgs","34 kgs","35 kgs" ,"36 kgs","37 kgs","38 kgs","39 kgs","40 kgs","41 kgs","42 kgs","43 kgs","44 kgs","45 kgs" ,"46 kgs","47 kgs","48 kgs","49 kgs","50 kgs","51 kgs","52 kgs","53 kgs","54 kgs","55 kgs" ,"56 kgs","57 kgs","58 kgs","59 kgs","60 kgs","61 kgs","62 kgs","63 kgs","64 kgs","65 kgs" ,"66 kgs","67 kgs","68 kgs","69 kgs","70 kgs","71 kgs","72 kgs","73 kgs","74 kgs","75 kgs" ,"76 kgs","77 kgs","78 kgs","79 kgs","80 kgs","81 kgs","82 kgs","83 kgs","84 kgs","85 kgs" ,"86 kgs","87 kgs","88 kgs","89 kgs","90 kgs","91 kgs","92 kgs","93 kgs","94 kgs","95 kgs" ,"96 kgs","97 kgs","98 kgs","99 kgs","100 kgs","101 kgs","102 kgs","103 kgs","104 kgs","105 kgs" ,"106 kgs","107 kgs","108 kgs","109 kgs","110 kgs","111 kgs","112 kgs","113 kgs","114 kgs","115 kgs" ,"116 kgs","117 kgs","118 kgs","119 kgs","120 kgs"]
    
    var dictPersonalDetails = [PersonalDetails.weight: "", PersonalDetails.hoursExperience: "", PersonalDetails.caloriesBurnt: ""] as [AnyHashable : String]
    
    @IBOutlet weak var myTableView: UITableView!
    @IBOutlet weak var saveButton: UIButton!
    @IBOutlet weak var updateButton: UIButton!
    @IBOutlet weak var saveDetailsLabel: UILabel!
    @IBOutlet weak var personalDetailsLabel: UILabel!
    @IBOutlet weak var backBtn: UIButton!
    @IBOutlet weak var backgrndImage: UIImageView!
    var weightSelectnIndex = 1
    
    override func viewDidLoad() {
        super.viewDidLoad()
        self.styleUI()
    }
    
    func styleUI() {
        backgrndImage.image =  #imageLiteral(resourceName: "background_img")
        backBtn.setImage( #imageLiteral(resourceName: "back_icon"), for: .normal)
        updateButton.layer.cornerRadius = 5
        saveButton.layer.cornerRadius = 5
        
        self.myTableView.tableFooterView = UIView()
        self.myTableView.separatorColor = UIColor.clear
        self.myTableView.backgroundColor = UIColor.clear
        self.myTableView.estimatedRowHeight = 75
        self.myTableView.rowHeight = UITableViewAutomaticDimension
        self.myTableView.backgroundColor = UIColor.clear
        
        
        self.navigationController?.isNavigationBarHidden = true
        
        DecorateControls.styleLabel(label: personalDetailsLabel, text: "Enter Personal Details", font: UIFont.boldSystemFont(ofSize: FONT_SIZE_34), textColor: blackColor())
        DecorateControls.styleLabel(label: saveDetailsLabel, text: "Save for Later", font: UIFont.boldSystemFont(ofSize: FONT_SIZE_34), textColor: blackColor())
        DecorateControls.putTitle(button: saveButton, text: "Save for Later", font: UIFont.boldSystemFont(ofSize: FONT_SIZE_28), textColor: whiteColor(), backGroundColor: appColor())
        DecorateControls.putTitle(button: updateButton, text: "Update Progress Chart", font: UIFont.boldSystemFont(ofSize: FONT_SIZE_28), textColor: whiteColor(), backGroundColor: appColor())
    }
    
    func tableView(_ tableView: UITableView, heightForRowAt indexPath: IndexPath) -> CGFloat {
        return UITableViewAutomaticDimension
    }
    
    func tableView(_ tableView: UITableView, numberOfRowsInSection section: Int) -> Int {
        return arrdata.count
    }
    
    func tableView(_ tableView: UITableView, cellForRowAt indexPath: IndexPath) -> UITableViewCell {
        let cell = myTableView.dequeueReusableCell(withIdentifier: "cell") as! PersonalDetailsTableViewCell
        cell.selectionStyle = .none
        cell.backgroundColor = UIColor.clear
        let data = arrdata[indexPath.row]
        cell.cellTextFld.isEnabled = false
        cell.cellTextFld.tag = indexPath.row
        let selectedRow : PersonalDetails = PersonalDetails(rawValue: indexPath.row)!
        switch selectedRow {
        case .weight:
            cell.cellTextFld.text = self.dictPersonalDetails[PersonalDetails.weight]
        case .hoursExperience:
            cell.cellTextFld.text = self.dictPersonalDetails[PersonalDetails.hoursExperience]
        case .caloriesBurnt:
            cell.cellTextFld.text = self.dictPersonalDetails[PersonalDetails.caloriesBurnt]
            // default: break
            
        }
        cell.cellTextFld.placeholder = data
        return cell
    }
    
    func tableView(_ tableView: UITableView, didSelectRowAt indexPath: IndexPath) {
        
        if indexPath.row == 0
        {
            ActionSheetStringPicker.show(withTitle: "Weight", rows: arrWeight, initialSelection: weightSelectnIndex, doneBlock: {
                picker, value, index in
                
                let indexx = "\(index ?? "")"
                self.weightSelectnIndex = value
                self.dictPersonalDetails[PersonalDetails.weight] = indexx
                self.myTableView.reloadData()
                return
            }, cancel: { ActionStringCancelBlock in return }, origin: myTableView)
            
        }
        else if indexPath.row == 1 {
            ActionSheetStringPicker.show(withTitle: "Hours Experience", rows: arrWeight, initialSelection: weightSelectnIndex, doneBlock: {
                picker, value, index in
                
                let indexx = "\(index ?? "")"
                self.dictPersonalDetails[PersonalDetails.hoursExperience] = indexx
                self.weightSelectnIndex = value
                self.myTableView.reloadData()
                return
            }, cancel: { ActionStringCancelBlock in return }, origin: myTableView)
        }
        else {
            ActionSheetStringPicker.show(withTitle: "Calories Burnt", rows: arrWeight, initialSelection: weightSelectnIndex, doneBlock: {
                picker, value, index in
                
                let indexx = "\(index ?? "")"
                self.dictPersonalDetails[PersonalDetails.caloriesBurnt] = indexx
                self.weightSelectnIndex = value
                self.myTableView.reloadData()
                return
            }, cancel: { ActionStringCancelBlock in return }, origin: myTableView)
        }
    }
    
    @IBAction func doSaveBtn(_ sender: UIButton) {
        let (isValid , message) = CommonUtility.doValidatePersonalDetails(self)
        
        if isValid {
            CommonUtility.showSuccessCRNotifications(title: "Success!!", message: message)
            
        }else{
            CommonUtility.showErrorCRNotifications(title: "Error!", message: message)
        }
    }
    @IBAction func doUpdateBtn(_ sender: UIButton) {
        let (isValid , message) = CommonUtility.doValidatePersonalDetails(self)
        
        if isValid {
            
            CommonUtility.showSuccessCRNotifications(title: "Success!!", message: message)
            
            DispatchQueue.main.asyncAfter(deadline: .now() + .seconds(1), execute: {
                
                let pushVc = self.storyboard?.instantiateViewController(withIdentifier: "MyProgressViewController") as! MyProgressViewController
                self.navigationController?.pushViewController(pushVc, animated: true)})
            
        }else{
            CommonUtility.showErrorCRNotifications(title: "Error!", message: message)
        }
        
    }
    @IBAction  func goBack(sender: UIButton){
        self.navigationController?.popViewController(animated: true)
    }
}
