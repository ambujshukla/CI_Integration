//
//  CustomTableViewCell.swift
//  PersonalDetails
//
//  Created by PujaDwivedi on 03/05/18.
//  Copyright © 2018 PujaDwivedi. All rights reserved.
//

import UIKit

class PersonalDetailsTableViewCell: UITableViewCell {
    
    @IBOutlet weak var cellTextFld: UITextField!
    
    override func awakeFromNib() {
        super.awakeFromNib()
        
        DecorateControls.putText(textField: cellTextFld, text: "", placehoder: "", font: UIFont.systemFont(ofSize: FONT_SIZE_18), textColor: color(red: 172, green: 172, blue: 172))
    }
    
    override func setSelected(_ selected: Bool, animated: Bool) {
        super.setSelected(selected, animated: animated)
        
        // Configure the view for the selected state
    }
    
}
