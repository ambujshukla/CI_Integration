
//
//  AddScheduleViewController.swift
//  PPL
//
//  Created by TanjeetAjmani on 10/05/18.
//  Copyright © 2018 cdn. All rights reserved.
//

import UIKit
import ActionSheetPicker_3_0

enum AddScheduleTextFieldTag: Int {
    case noOfPatientsTextFieldTag = 100
    case scheduleTitleTextFieldTag
}

class AddScheduleViewController: UIViewController,DataSentDelegate {
    
    @IBOutlet weak var tfScheduleTitle: UITextField!
    @IBOutlet weak var btnStartTime: UIButton!
    @IBOutlet weak var lblScheduleTitle: UILabel!
    @IBOutlet weak var lblStartTimeDetail: UILabel!
    @IBOutlet weak var lblStartTime: UILabel!
    @IBOutlet weak var textFieldNoPatient: UITextField!
    @IBOutlet weak var btnTime: UIButton!
    @IBOutlet weak var lblNoPatient: UILabel!
    @IBOutlet weak var lblTime: UILabel!
    @IBOutlet weak var lblDate: UILabel!
    @IBOutlet weak var lblDateDetail: UILabel!
    @IBOutlet weak var btnDate: UIButton!
    @IBOutlet weak var lblTimeDetail: UILabel!
    
    var maxTime1 = Date()
    var maxTime2 = Date()
    var scheduleViewModel = ScheduleViewModel()
    
    override func viewDidLoad() {
        super.viewDidLoad()
        self.styleUI()
        self.navigationBarStyle()
    }
    
    func styleUI() {
        textFieldNoPatient.layer.borderWidth = 1
        textFieldNoPatient.layer.borderColor = UIColor.lightGray.cgColor
        tfScheduleTitle.layer.borderWidth = 1
        tfScheduleTitle.layer.borderColor = UIColor.lightGray.cgColor
        btnTime.setImage(UIImage.init(named: "clock"), for: .normal)
        DecorateControls.styleLabel(label: lblTime, text: "End Time", font: UIFont.systemFont(ofSize: FONT_SIZE_18), textColor: blackColor())
        DecorateControls.styleLabel(label: lblStartTime, text: "Start Time", font: UIFont.systemFont(ofSize: FONT_SIZE_18), textColor: blackColor())
        DecorateControls.styleLabel(label: lblDate, text: "Date Schedule", font: UIFont.systemFont(ofSize: FONT_SIZE_18), textColor: blackColor())
        DecorateControls.styleLabel(label: lblNoPatient, text: "Number of Patients", font: UIFont.systemFont(ofSize: FONT_SIZE_18), textColor: blackColor())
        DecorateControls.styleLabel(label: lblScheduleTitle, text: "Schedule Title", font: UIFont.systemFont(ofSize: FONT_SIZE_18), textColor: blackColor())
        DecorateControls.putText(textField: tfScheduleTitle, text: "", placehoder: "Enter Schedule Title ", font: UIFont.systemFont(ofSize: FONT_SIZE_18), textColor: blackColor())
        textFieldNoPatient.setLeftPaddingPoints(10)
        tfScheduleTitle.setLeftPaddingPoints(10)
        textFieldNoPatient.keyboardType = UIKeyboardType.decimalPad
        self.textFieldNoPatient.delegate = self
        self.tfScheduleTitle.delegate = self
        
        self.textFieldNoPatient.tag = AddScheduleTextFieldTag.noOfPatientsTextFieldTag.rawValue
        self.tfScheduleTitle.tag = AddScheduleTextFieldTag.scheduleTitleTextFieldTag.rawValue
    }
    
    func navigationBarStyle (){
        CommonUtility.setNavBarTitle(self.navigationItem, title: NSLocalizedString("Add Schedule", comment: "The title of the Add Schedule navigation bar"))
        CommonUtility.createRightBarSaveButtons(target: self, navigationItem: self.navigationItem, select1: #selector(openDashBoardView), select2: #selector(openProfileView), select3: #selector(openSaveView))
        CommonUtility.createCustomBackButton(self, navBarItem: self.navigationItem, strImage: "back_icon _white", select: #selector(openPopView))
    }
    
    @objc func openProfileView()
    {
        let pushVc = self.storyboard?.instantiateViewController(withIdentifier: "DoctorProfileViewController") as! DoctorProfileViewController
       self.navigationController?.pushViewController(pushVc, animated: true)
        
    }
    
    @objc func openSaveView() {
        if self.scheduleViewModel.validated() {
            self.scheduleViewModel.addSchedule(completion: {
                self.navigationController?.popViewController(animated: true)
            }, failure: { (error) in
                
            })
        }
    }
    
    @objc func openDashBoardView()
    {
        CommonUtility.setMenuSelectedOption(menuOptionIndex: 0)
        let centerVC : UIViewController
        let storyboard =  UIStoryboard(name: "Pilates", bundle: nil)
        centerVC = storyboard.instantiateViewController(withIdentifier: "PilatesDashboardViewController")
        let centerNavVC = UINavigationController(rootViewController: centerVC)
        self.panel?.configs.centerPanelTransitionType = .moveLeft
        self.panel?.configs.centerPanelTransitionDuration = 1.0
        _ = panel?.center(centerNavVC)
        
    }
    @objc func openPopView()
    {
        self.navigationController?.popViewController(animated: true)
    }
    //MARK: - UIAction methods
    
    func dataPassed(data: String) {
        self.lblDateDetail.text = data
        self.scheduleViewModel.date = data
    }
    
    @IBAction func actionDateScheduleButton(_ sender: UIButton) {
        let popupViewCtrl = self.storyboard?.instantiateViewController(withIdentifier: "PopUpViewController") as! PopUpViewController
        popupViewCtrl.delegate = self
        let window = UIApplication.shared.keyWindow
        window?.addSubview(popupViewCtrl.view)
        self.addChildViewController(popupViewCtrl)
    }
    
    @IBAction func btnTimeAction(_ sender: UIButton) {
        
        if self.scheduleViewModel.start_time.isEmpty {
            CommonUtility.showErrorCRNotifications(title: appTitle(), message: NSLocalizedString("title.error.select.start", comment: "This message is shown when the start time is not selected and end tapped."))
            return
        }
        
        let datePicker = ActionSheetDatePicker(title: "Time:", datePickerMode: UIDatePickerMode.time, selectedDate: maxTime2, doneBlock: {
            picker, value, index in
            let timeFormatter = DateFormatter()
            timeFormatter.dateFormat = "hh:mm a"
            let selectedDate = timeFormatter.string(from: value as! Date)
            print(selectedDate)
            
            if !self.startTimeIsGreaterThanEndTime(startTime: CommonUtility.changeDateFormateOfDate(obj: self.scheduleViewModel.start_time, oldFormate: "hh:mm a", newFormate: "HH:mm"), endTime: CommonUtility.changeDateFormateOfDate(obj: selectedDate, oldFormate: "hh:mm a", newFormate: "HH:mm")) {
                self.lblTimeDetail.text = ""
                self.scheduleViewModel.end_time = ""
                return
            }
            
            self.maxTime2 = timeFormatter.date(from: selectedDate)!
            self.lblTimeDetail.text = selectedDate
            self.scheduleViewModel.end_time = selectedDate
            return
        }, cancel: { ActionStringCancelBlock in return }, origin: sender)
        datePicker?.show()
    }
    
    func startTimeIsGreaterThanEndTime(startTime: String, endTime: String) -> Bool {
        if (CommonUtility.timeDifferenceInMinutes(time1: startTime, time2: endTime)) <= 0 {
            CommonUtility.showErrorCRNotifications(title: appTitle(), message: NSLocalizedString("title.error.starttime.greater.endtime", comment: "This message is shown when the start time is not greater than end time."))
            return false
        }
        return true
    }
    
    @IBAction func btnStartTimeActn(_ sender: UIButton) {
        let datePicker = ActionSheetDatePicker(title: "Time:", datePickerMode: UIDatePickerMode.time, selectedDate: maxTime1, doneBlock: {
            picker, value, index in
            let timeFormatter = DateFormatter()
            timeFormatter.dateFormat = "hh:mm a"
            let selectedDate = timeFormatter.string(from: value as! Date)
            
            if !self.scheduleViewModel.end_time.isEmpty {
                if !self.startTimeIsGreaterThanEndTime(startTime: CommonUtility.changeDateFormateOfDate(obj: selectedDate, oldFormate: "hh:mm a", newFormate: "HH:mm"), endTime: CommonUtility.changeDateFormateOfDate(obj: self.scheduleViewModel.end_time, oldFormate: "hh:mm a", newFormate: "HH:mm")) {
                    self.lblStartTimeDetail.text = ""
                    self.scheduleViewModel.start_time = ""
                    return
                }
            }
            self.maxTime1 = timeFormatter.date(from: selectedDate)!
            self.lblStartTimeDetail.text = selectedDate
            self.scheduleViewModel.start_time = selectedDate
            return
        }, cancel: { ActionStringCancelBlock in return }, origin: sender)
        datePicker?.show()
    }
    override func touchesBegan(_ touches: Set<UITouch>, with event: UIEvent?) {
        self.view.endEditing(true)
    }
}


extension AddScheduleViewController:  UITextFieldDelegate {
    func textField(_ textField: UITextField, shouldChangeCharactersIn range: NSRange, replacementString string: String) -> Bool {
        if let text = textField.text as NSString? {
            let txtAfterUpdate = text.replacingCharacters(in: range, with: string)
            if textField.tag == AddScheduleTextFieldTag.noOfPatientsTextFieldTag.rawValue {
                self.scheduleViewModel.number_of_patient = txtAfterUpdate
            } else {
                self.scheduleViewModel.scheduleTitle = txtAfterUpdate
            }
            
        }
        return true
    }
}
