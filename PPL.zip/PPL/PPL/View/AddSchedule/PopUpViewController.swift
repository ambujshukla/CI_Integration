//
//  PopUpViewController.swift
//  PPL
//
//  Created by gopalsara on 05/02/18.
//  Copyright © 2018 CDN Software Solutions Indore. All rights reserved.
//

import UIKit
import CoreLocation
import FSCalendar
protocol DataSentDelegate {
    func dataPassed (data : String)
}

class PopUpViewController: UIViewController,FSCalendarDelegate,FSCalendarDataSource{
    @IBOutlet weak var vwUploadRoundBox : UIView!
    fileprivate weak var calendar: FSCalendar!
    
    @IBOutlet weak var btnRightSwipe: UIButton!
    
    @IBOutlet weak var btnOkay: UIButton!
    @IBOutlet weak var btnLeftSwipe: UIButton!
    @IBOutlet weak var lblDateSchedule: UILabel!
    var dataPassed = ""
    var dateIndex1 = ""
    var dateIndex2 = ""
    
    var delegate : DataSentDelegate? = nil
    
    fileprivate let formatter: DateFormatter = {
        let formatter = DateFormatter()
        formatter.dateFormat = "dd-MM-yyyy"
        return formatter
    }()
    override func viewDidLoad() {
        super.viewDidLoad()
        self.decorateUI()
        
        self.styleUI()
        
        
    }
    
    override func touchesBegan(_ touches: Set<UITouch>, with event: UIEvent?) {
        if let touch = touches.first {
            if touch.view == self.view {
                self.hideViewWithAnimation()
            }
        }
    }
    
    func styleUI() {
        
        let calendar = FSCalendar(frame: CGRect(x: 105, y: 100, width: 400 , height: 400))
        calendar.dataSource = self
        calendar.delegate = self
        self.calendar = calendar
        calendar.register(CalendarViewCell.self, forCellReuseIdentifier: "cell")
        vwUploadRoundBox.addSubview(calendar)
        
        calendar.appearance.headerTitleColor = UIColor.init(red: 232/255.0, green: 191/255.0, blue: 63/255.0, alpha: 1)
        calendar.appearance.selectionColor = UIColor.init(red: 255/255.0, green: 255/255.0, blue: 255/255.0, alpha: 0)
        calendar.appearance.titleDefaultColor = UIColor.init(red: 116/255.0, green: 116/255.0, blue: 116/255.0, alpha: 1)
        calendar.appearance.titleFont = UIFont.boldSystemFont(ofSize: 14)
        calendar.appearance.titleSelectionColor = UIColor.init(red: 148/255.0, green: 151/255.0, blue: 154/255.0, alpha: 1)
        calendar.appearance.borderSelectionColor = UIColor.init(red: 232/255.0, green: 191/255.0, blue: 63/255.0, alpha: 1)
        calendar.appearance.todayColor = UIColor.init(red: 255/255.0, green: 255/255.0, blue: 255/255.0, alpha: 0)
        
        calendar.appearance.titleTodayColor = UIColor.init(red: 116/255.0, green: 116/255.0, blue: 116/255.0, alpha: 1)
        
        calendar.appearance.weekdayTextColor = UIColor.init(red: 232/255.0, green: 191/255.0, blue: 63/255.0, alpha: 1)
        calendar.appearance.todayColor = appColor()
        
        
        calendar.appearance.caseOptions = [.headerUsesUpperCase,.weekdayUsesSingleUpperCase]
        calendar.appearance.headerMinimumDissolvedAlpha = 0.0
        calendar.scrollEnabled = true
        calendar.layer.borderColor = UIColor.clear.cgColor
        calendar.clipsToBounds = true
        calendar.scope = .month
        
        DecorateControls.styleLabel(label: lblDateSchedule, text: "Date Schedule", font: UIFont.systemFont(ofSize: FONT_SIZE_25), textColor: blackColor())
        DecorateControls.putTitle(button: btnOkay, text: "Okay", font: UIFont.systemFont(ofSize: FONT_SIZE_25), textColor: whiteColor(), backGroundColor: appColor())
        lblDateSchedule.backgroundColor = color(red: 230, green: 230, blue: 230)
        self.btnLeftSwipe.setImage(#imageLiteral(resourceName: "left-arrow"), for: .normal)
        self.btnRightSwipe.setImage(#imageLiteral(resourceName: "right-arrow"), for: .normal)
        self.vwUploadRoundBox.bringSubview(toFront: self.btnLeftSwipe)
        self.vwUploadRoundBox.bringSubview(toFront: self.btnRightSwipe)
        self.btnLeftSwipe.isEnabled = true
        self.btnRightSwipe.isEnabled = true
        dataPassed = "\(self.formatter.string(from: Date()))"
        
    }
    
    func decorateUI(){
        self.view.backgroundColor = UIColor.black.withAlphaComponent(0.6)
        self.vwUploadRoundBox.layer.cornerRadius = 7
        self.vwUploadRoundBox.layer.shadowOpacity = 0.8
        self.vwUploadRoundBox.layer.borderWidth = 1.0
        self.vwUploadRoundBox.layer.borderColor = UIColor.black.cgColor
        self.vwUploadRoundBox.clipsToBounds = true
        self.showAnimation()
    }
    
    func showAnimation(){
        self.view.alpha = 0
        self.vwUploadRoundBox.transform = CGAffineTransform(scaleX: 0.1, y: 0.1)
        UIView.animate(withDuration: 0.3) {
            self.vwUploadRoundBox.transform = CGAffineTransform(scaleX: 1.0, y: 1.0)
            self.view.alpha = 1
        }
    }
    
    func hideViewWithAnimation() {
        UIView.animate(withDuration: 0.3, animations: {
            self.vwUploadRoundBox.transform = CGAffineTransform(scaleX: 0.1, y: 0.1)
            self.view.alpha = 0
        }, completion: {
            (value: Bool) in
            self.removeFromParentViewController()
            self.view.removeFromSuperview()
        })
    }
    
    
    @IBAction func btnLeftSwipeActn(_ sender: UIButton) {
        let _calendar = Calendar.current
        var dateComponents = DateComponents()
        dateComponents.month = -1
        self.calendar.currentPage = _calendar.date(byAdding: dateComponents, to: self.calendar.currentPage)!
        self.calendar.setCurrentPage(self.calendar.currentPage, animated: true)
        
    }
    @IBAction func btnRightSwipeActn(_ sender: UIButton) {
        let _calendar = Calendar.current
        var dateComponents = DateComponents()
        dateComponents.month = 1
        self.calendar.currentPage = _calendar.date(byAdding: dateComponents, to: self.calendar.currentPage)!
        self.calendar.setCurrentPage(self.calendar.currentPage, animated: true)
        
    }
    func calendar(_ calendar: FSCalendar, cellFor date: Date, at position: FSCalendarMonthPosition) -> FSCalendarCell {
        let cell = calendar.dequeueReusableCell(withIdentifier: "cell", for: date, at: position)
        cell.backgroundColor = UIColor.init(red: 235/255.0, green: 235/255.0, blue: 235/255.0, alpha: 1)
        
        
        
        return cell
    }
    
    func calendar(_ calendar: FSCalendar, didSelect date: Date, at monthPosition: FSCalendarMonthPosition) {
        dateIndex2 = "\(self.formatter.string(from: date))"
        dataPassed = dateIndex2
    }
    
    func calendar(_ calendar: FSCalendar, shouldSelect date: Date, at monthPosition: FSCalendarMonthPosition) -> Bool {
        
        let datecurent = Date()
        if date < datecurent  {
            return false
        }
        return monthPosition == .current
    }
    
    private func configureVisibleCells() {
        calendar.visibleCells().forEach { (cell) in
            let date = calendar.date(for: cell)
            let position = calendar.monthPosition(for: cell)
            //self.configure(cell: cell, for: date!, at: position)
        }
    }
    
    
    @IBAction func btnOkayActn(_ sender: UIButton) {
        
        delegate?.dataPassed(data: dataPassed)
        self.hideViewWithAnimation()
    }
}

