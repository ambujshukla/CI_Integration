//
//  PatientListViewController.swift
//  PPL
//
//  Created by TanjeetAjmani on 08/05/18.
//  Copyright © 2018 cdn. All rights reserved.
//

import UIKit
import EmptyDataSet_Swift

enum StatusRequest: String {
    case accepted = "1"
    case decline  = "2"
}

class PatientListViewController: UIViewController,UITableViewDataSource,UITableViewDelegate {
    
    @IBOutlet weak var tVpatientList: UITableView!
    @IBOutlet weak var viewTableView: UIView!
    @IBOutlet weak var viewButton: UIView!
    @IBOutlet weak var btnMyClient: UIButton!
    @IBOutlet weak var btnPending: UIButton!
    
    private var arrPatientList = [["patientName" : "Josh Iwata", "patientDetail" : "Lorem Ipsum i simply dummy text of printing and typesetting industry "],["patientName" : "Aaron White", "patientDetail" : "Lorem Ipsum i simply dummy text of printing and typesetting industry"],["patientName" : "Max Smuel", "patientDetail" : "Lorem Ipsum i simply dummy text of printing and typesetting industry"],["patientName" : "Max Smuel ", "patientDetail" : "Lorem Ipsum i simply dummy text of printing and typesetting industry"],["patientName" : "Nascetur Ridiculus", "patientDetail" : "Lorem Ipsum i simply dummy text of printing and typesetting industry"],["patientName" : "Paul Samuelson", "patientDetail" : "Lorem Ipsum i simply dummy text of printing and typesetting industry Lorem Ipsum i simply dummy text of printing and typesetting industry"]]
    
    private var patientListViewModel :PatientListViewModel = PatientListViewModel()  {
        didSet {
            self.tVpatientList.reloadData()
        }
    }
    
    //MARK: life cycle
    override func viewDidLoad() {
        super.viewDidLoad()
        self.styleUI()
        self.navigationBarStyle()
        self.automaticallyAdjustsScrollViewInsets = false
        self.getClientsList()
    }
    
    override func viewWillAppear(_ animated: Bool) {
        super.viewWillAppear(true)
        self.navigationController?.isNavigationBarHidden = false
    }
    
    func styleUI() {
        btnPending.setTitle("Pending", for: .normal)
        
        btnPending.setTitleColor(UIColor.white, for: .normal)
        btnMyClient.setTitle("My Client", for: .normal)
        
        btnMyClient.setTitleColor(UIColor.black, for: .normal)
        btnPending.backgroundColor = UIColor.init(red: 227/255.0, green: 193/255.0, blue: 68/255.0, alpha: 1)
        DecorateControls.putTitle(button: btnPending, text: "Pending", font: UIFont.systemFont(ofSize: FONT_SIZE_16), textColor: whiteColor(), backGroundColor: appColor())
        DecorateControls.putTitle(button: btnMyClient, text: "My Clients", font: UIFont.systemFont(ofSize: FONT_SIZE_16), textColor: appColor(), backGroundColor: whiteColor())
        viewButton.layer.borderWidth = 1
        viewButton.layer.borderColor = UIColor.init(red: 227/255.0, green: 193/255.0, blue: 68/255.0, alpha: 1).cgColor
        viewButton.layer.cornerRadius = 5
        viewButton.clipsToBounds = true
        tVpatientList.separatorStyle = .none
        
        tVpatientList.estimatedRowHeight = 100
        tVpatientList.rowHeight = UITableViewAutomaticDimension
        
        tVpatientList.emptyDataSetSource = self
        tVpatientList.emptyDataSetDelegate = self
    }
    
    func navigationBarStyle (){
        
        if navigationController?.viewControllers.count == 1 {
            
            CommonUtility.createCustomBackButton(self, navBarItem: self.navigationItem, strImage: "menu_slide", select: #selector(doClickSideMenu))
        }
        else {
            CommonUtility.createCustomBackButton(self, navBarItem: self.navigationItem, strImage: "back_icon _white", select: #selector(openPopView))
        }
        
        
        CommonUtility.setNavBarTitle(self.navigationItem, title: NSLocalizedString("Pending Request", comment: "The title of the Profile navigation bar"))
        CommonUtility.createRightBarHomeButtons(target: self, navigationItem: self.navigationItem, select1: #selector(openProfileView), select2: #selector(openDashBoardView))
    }
    
    func getClientsList() {
        self.patientListViewModel.clientsList(completion: { (patientList) in
            self.patientListViewModel.patientList = patientList
        }) { (error) in
            
        }
    }
    
    @objc func openPopView()
    {
        self.navigationController?.popViewController(animated: true)
    }
    
    @objc func openProfileView()
    {
        let pushVc = self.storyboard?.instantiateViewController(withIdentifier: "DoctorProfileViewController") as! DoctorProfileViewController
        self.navigationController?.pushViewController(pushVc, animated: true)
      
    }
    @objc func openDashBoardView()
    {
        CommonUtility.setMenuSelectedOption(menuOptionIndex: 0)
        let centerVC : UIViewController
        let storyboard =  UIStoryboard(name: "Pilates", bundle: nil)
        centerVC = storyboard.instantiateViewController(withIdentifier: "PilatesDashboardViewController")
        let centerNavVC = UINavigationController(rootViewController: centerVC)
        self.panel?.configs.centerPanelTransitionType = .moveLeft
        self.panel?.configs.centerPanelTransitionDuration = 1.0
        _ = panel?.center(centerNavVC)
        
    }
    
    @objc func doClickSideMenu()
    {
        panel?.openLeft(animated: true)
    }
    
    func tableView(_ tableView: UITableView, numberOfRowsInSection section: Int) -> Int {
        return 1
    }
    
    func tableView(_ tableView: UITableView, cellForRowAt indexPath: IndexPath) -> UITableViewCell {
        let cell = tableView.dequeueReusableCell(withIdentifier: "cell") as! PatientListTableViewCell
        cell.selectionStyle = .none
        cell.lblDateTime.isHidden = true
        cell.btnAccept.isHidden = true
        cell.btnDecline.isHidden = true
        if self.btnMyClient.isSelected == true //my clients
        {
            cell.styleTableViewCellForClients(myClientModel: self.patientListViewModel.patientList!.result.my_client[indexPath.section])
        }
        else {
            cell.btnAccept.isHidden = false
            cell.btnDecline.isHidden = false
            cell.delegate = self
            cell.styleTableViewCellForPendingRequest(pendingRequestModel: self.patientListViewModel.patientList!.result.pendding_request[indexPath.section])
        }
        return cell
    }
    
    func numberOfSections(in tableView: UITableView) -> Int {
        if self.patientListViewModel.patientList == nil {
            return 0
        }
        if self.btnMyClient.isSelected == true //my clients
        {
            return (self.patientListViewModel.patientList?.result.my_client.count)!
        }
        return (self.patientListViewModel.patientList?.result.pendding_request.count)!
    }
    
    func tableView(_ tableView: UITableView, heightForRowAt indexPath: IndexPath) -> CGFloat {
        return UITableViewAutomaticDimension
    }
    func tableView(_ tableView: UITableView, didSelectRowAt indexPath: IndexPath) {
        if self.btnMyClient.isSelected == true //my clients
        {
            let vc = self.storyboard?.instantiateViewController(withIdentifier: "ClientDetailsViewController") as! ClientDetailsViewController
            vc.patientDetailModel = self.patientListViewModel.patientList!.result.my_client[indexPath.section]

            self.navigationController?.pushViewController(vc, animated: true)
        }
    }
    
    @IBAction func selectListOption(_ sender: UIButton) {
        self.btnMyClient.isSelected = false
        self.btnPending.isSelected = false
        if sender.tag == 100 {
            self.btnPending.isSelected = true
        }else {
            self.btnMyClient.isSelected = true
        }
        colorButton()
        self.tVpatientList.reloadData()
    }
    
    func colorButton() {
        self.btnMyClient.backgroundColor = UIColor.white
        self.btnPending.backgroundColor = UIColor.white
        self.btnMyClient.setTitleColor(appColor(), for: .normal)
        self.btnPending.setTitleColor(appColor(), for: .normal)
        self.btnMyClient.setTitleColor(whiteColor(), for: .selected)
        self.btnPending.setTitleColor(whiteColor(), for: .selected)
        if btnMyClient.isSelected == true {
            btnMyClient.backgroundColor = appColor()
        }
        else {
            btnPending.backgroundColor = appColor()
        }
    }
}

//MARK: EmptyDataSource and Delegates
extension PatientListViewController: EmptyDataSetSource, EmptyDataSetDelegate {
    func title(forEmptyDataSet scrollView: UIScrollView) -> NSAttributedString? {
        return CommonUtility.dzEmptySetTitle(title: NSLocalizedString("title.error.nodata", comment: "This string shows when there is no data found."))
    }
    
//    func buttonTitle(forEmptyDataSet scrollView: UIScrollView, for state: UIControlState) -> NSAttributedString? {
//        return CommonUtility.dzEmptySetButtonTitle(title: NSLocalizedString("title.retry", comment: "This gives the option for retry when there is no data."))
//    }
    
    func emptyDataSet(_ scrollView: UIScrollView, didTapButton button: UIButton) {
        self.getClientsList()
    }
    
    func emptyDataSetShouldDisplay(_ scrollView: UIScrollView) -> Bool {
        if self.patientListViewModel.patientList != nil {
            return true
        }
        return false
    }
}

extension PatientListViewController: PatientRquestDelegate{
    func selectOptionForUser(selectedOptionInList: Int, isRequestAccepted: Bool) {
        self.patientListViewModel.changePatientRequest(patientId: self.patientListViewModel.patientList!.result.pendding_request[selectedOptionInList].user_id!, status: (isRequestAccepted ? StatusRequest.accepted.rawValue : StatusRequest.decline.rawValue), completion: {
            
            if isRequestAccepted {
                self.patientListViewModel.patientList!.result.my_client.append(self.patientListViewModel.patientList!.result.pendding_request[selectedOptionInList])
            }
            self.patientListViewModel.patientList!.result.pendding_request.remove(at: selectedOptionInList)
        }) {
            
        }
    }
}
