//
//  PatientListTableViewCell.swift
//  PPL
//
//  Created by TanjeetAjmani on 08/05/18.
//  Copyright © 2018 cdn. All rights reserved.
//

import UIKit
import SDWebImage

protocol PatientRquestDelegate: class {
    func selectOptionForUser(selectedOptionInList: Int, isRequestAccepted: Bool)
}

class PatientListTableViewCell: UITableViewCell {

    var delegate: PatientRquestDelegate?
    
    @IBOutlet weak var lblDateTime: UILabel!
    @IBOutlet weak var viewUserImg: UIView!
    @IBOutlet weak var imgUser: UIImageView!
    @IBOutlet weak var lblDetail: UILabel!
    @IBOutlet weak var btnAccept: UIButton!
    @IBOutlet weak var lblName: UILabel!
    @IBOutlet weak var btnDecline: UIButton!
    
    override func awakeFromNib() {
        super.awakeFromNib()
        self.btnAccept.setTitle("Accept", for: .normal)
        self.btnAccept.backgroundColor = UIColor.init(red: 227/255.0, green: 193/255.0, blue: 68/255.0, alpha: 1)
        self.btnAccept.layer.cornerRadius = 5
        self.btnDecline.setTitle("Decline", for: .normal)
        self.btnDecline.backgroundColor = UIColor.init(red: 105/255.0, green: 84/255.0, blue: 10/255.0, alpha: 1)
        self.btnDecline.layer.cornerRadius = 5
        
        self.viewUserImg.layer.borderWidth = 2
        self.viewUserImg.layer.borderColor = UIColor.gray.cgColor
        self.imgUser.image = UIImage.init(named: "SidePose")
    }

    func styleTableViewCellForClients(myClientModel: PatientList) {
        self.lblDateTime.isHidden = false
        self.lblName.text = " \(myClientModel.firstname!) \(myClientModel.lastname!)"
        self.lblDetail.text = myClientModel.medical_history
        self.imgUser.sd_setImage(with: URL(string: myClientModel.profile_image!), placeholderImage: #imageLiteral(resourceName: "no-inage"))
        self.lblDateTime.text = CommonUtility.changeDateFormateOfDate(obj: myClientModel.date!, oldFormate: "YYYY-MM-dd HH:mm:ss", newFormate: "MMM dd hh:mm a")
    }
    
    func styleTableViewCellForPendingRequest(pendingRequestModel: PatientList) {
        self.lblName.text = " \(pendingRequestModel.username!) \(pendingRequestModel.lastname!)"
        self.lblDetail.text = pendingRequestModel.medical_history
        self.imgUser.sd_setImage(with: URL(string: pendingRequestModel.profile_image!), placeholderImage: #imageLiteral(resourceName: "no-inage"))
    }
    
    @IBAction func accept(sender: UIButton) {
        self.delegate?.selectOptionForUser(selectedOptionInList: sender.tag,isRequestAccepted: true)
    }
    
    @IBAction func decline(sender: UIButton) {
        self.delegate?.selectOptionForUser(selectedOptionInList: sender.tag,isRequestAccepted: false)
    }
}
