//
//  DoctorProfileUpdationViewController.swift
//  PPL
//
//  Created by TanjeetAjmani on 07/06/18.
//  Copyright © 2018 cdn. All rights reserved.
//

import UIKit
import FAPanels

enum DoctorProfileUpdateTextFieldTag: Int {
    case qualificationTextField = 101
    case expertiseTextField
    case experienceTextField
    case achievementsTextField
}

class DoctorProfileUpdationViewController: UIViewController,UIImagePickerControllerDelegate,UINavigationControllerDelegate {
    @IBOutlet weak var imgBg: UIImageView!
    @IBOutlet weak var imgSeparator3: UIImageView!
    @IBOutlet weak var imgSeperator4: UIImageView!
    @IBOutlet weak var imgSepaerator2: UIImageView!
    @IBOutlet weak var tfAcheivements: UITextField!
    @IBOutlet weak var imgSeperator1: UIImageView!
    @IBOutlet weak var tfExpertise: UITextField!
    @IBOutlet weak var tfExperience: UITextField!
    @IBOutlet weak var tfQualificatn: UITextField!
    @IBOutlet weak var btnContinue: UIButton!
    @IBOutlet weak var lblAchievements: UILabel!
    @IBOutlet weak var lblExpertise: UILabel!
    @IBOutlet weak var lblExperience: UILabel!
    @IBOutlet weak var lblQualifictn: UILabel!
    @IBOutlet weak var imgDoctor: UIImageView!
    @IBOutlet weak var lblWelcomePilate: UILabel!
    @IBOutlet weak var btnBack: UIButton!
    
    let imagePicker = UIImagePickerController()
    var profileUpdateViewModel = PilateProfileUpdateViewModel()
    
    override func viewDidLoad() {
        super.viewDidLoad()
        self.styleUI()
    }
    
    func styleUI() {
        self.imgBg.image = #imageLiteral(resourceName: "background_img")
        self.btnBack.setImage(#imageLiteral(resourceName: "back_icon"), for: .normal)
        self.imgDoctor.image = #imageLiteral(resourceName: "Image")
        DecorateControls.styleLabel(label: lblWelcomePilate, text: "Welcome to Pilate Patients!", font: UIFont.boldSystemFont(ofSize: FONT_SIZE_34), textColor: blackColor())
        DecorateControls.styleLabel(label: lblQualifictn, text: "Qualification", font: UIFont.systemFont(ofSize: FONT_SIZE_24), textColor: blackColor())
        DecorateControls.styleLabel(label: lblExpertise, text: "Expertise", font: UIFont.systemFont(ofSize: FONT_SIZE_24), textColor: blackColor())
        DecorateControls.styleLabel(label: lblExperience, text: "Experience", font: UIFont.systemFont(ofSize: FONT_SIZE_24), textColor: blackColor())
        DecorateControls.styleLabel(label: lblAchievements, text: "Achievements", font: UIFont.systemFont(ofSize: FONT_SIZE_24), textColor: blackColor())
        DecorateControls.putText(textField: tfQualificatn, text: "", placehoder: "Enter Qualification ", font: UIFont.boldSystemFont(ofSize: FONT_SIZE_20), textColor: UIColor.darkGray)
        DecorateControls.putText(textField: tfExpertise, text: "", placehoder: "Enter Expertise ", font: UIFont.boldSystemFont(ofSize: FONT_SIZE_20), textColor: UIColor.darkGray)
        DecorateControls.putText(textField: tfExperience, text: "", placehoder: "Enter Experience ", font: UIFont.boldSystemFont(ofSize: FONT_SIZE_20), textColor: UIColor.darkGray)
        DecorateControls.putText(textField: tfAcheivements, text: "", placehoder: "Enter Acheivements(if any)", font: UIFont.boldSystemFont(ofSize: FONT_SIZE_20), textColor: UIColor.darkGray)
        DecorateControls.putTitle(button: btnContinue, text: "Save & Continue", font: UIFont.boldSystemFont(ofSize: FONT_SIZE_28), textColor: whiteColor(), backGroundColor: appColor())
        
        self.btnContinue.layer.cornerRadius = 5
        let tapG = UITapGestureRecognizer.init(target: self, action: #selector(self.profileImageClicked(sender:)))
        tapG.numberOfTapsRequired = 1
        self.imgDoctor.isUserInteractionEnabled = true
        self.imgDoctor.addGestureRecognizer(tapG)
        self.imagePicker.delegate = self
        
        self.tfExpertise.delegate = self
        self.tfExperience.delegate = self
        self.tfQualificatn.delegate = self
        self.tfAcheivements.delegate = self
        self.profileUpdateViewModel.qualification = ""
         self.profileUpdateViewModel.expertise = ""
         self.profileUpdateViewModel.experience = ""
         self.profileUpdateViewModel.achievements = ""
        self.tfQualificatn.tag = DoctorProfileUpdateTextFieldTag.qualificationTextField.rawValue
        self.tfExpertise.tag = DoctorProfileUpdateTextFieldTag.expertiseTextField.rawValue
        self.tfExperience.tag = DoctorProfileUpdateTextFieldTag.experienceTextField.rawValue
        self.tfAcheivements.tag = DoctorProfileUpdateTextFieldTag.achievementsTextField.rawValue
        
        self.profileUpdateViewModel.profileImage = self.imgDoctor.image
    }
    
    @objc func profileImageClicked(sender: UITapGestureRecognizer? = nil){
        let alert : UIAlertController = UIAlertController(title: "Choose Image", message: nil, preferredStyle: UIAlertControllerStyle.actionSheet)
        let cameraAction = UIAlertAction(title: "Camera", style: UIAlertActionStyle.default)
        {
            UIAlertAction in
            self.openCamera()
            
        }
        let gallaryAction = UIAlertAction(title: "Gallery", style: UIAlertActionStyle.default)
        {
            UIAlertAction in
            self.openGallary()
        }
        let cancelAction = UIAlertAction(title: "Cancel", style: UIAlertActionStyle.cancel)
        {
            UIAlertAction in
            
        }
        self.imagePicker.modalPresentationStyle = .overCurrentContext
        alert.addAction(cameraAction)
        alert.addAction(gallaryAction)
        alert.addAction(cancelAction)
        if let popoverController = alert.popoverPresentationController {
            popoverController.sourceView = self.imgDoctor
            popoverController.sourceRect = self.imgDoctor.bounds
            
        }
        self.present(alert, animated: true, completion: nil)
    }
    func openCamera()
    {
        if(UIImagePickerController .isSourceTypeAvailable(UIImagePickerControllerSourceType.camera))
        {
            imagePicker.sourceType = .camera
            self .present(imagePicker, animated: true, completion: nil)
        }
        else
        {
            let alert = UIAlertController(title: "Warning", message: "You don't have camera", preferredStyle: UIAlertControllerStyle.alert)
            alert.addAction(UIAlertAction(title: "Ok", style: UIAlertActionStyle.default, handler: nil))
            self.present(alert, animated: true, completion: nil)
        }
    }
    
    func openGallary()
    {
        imagePicker.sourceType = .savedPhotosAlbum
        self.present(imagePicker, animated: true, completion: nil)
    }
    
    func imagePickerController(_ picker: UIImagePickerController, didFinishPickingMediaWithInfo info: [String : Any]) {
        let chosenImage = info[UIImagePickerControllerOriginalImage] as! UIImage //2
        let selectedImage : UIImage = chosenImage
        imgDoctor.image = selectedImage
        self.profileUpdateViewModel.profileImage = selectedImage
        self.dismiss(animated: true, completion: nil)
    }
    
    func imagePickerControllerDidCancel(_ picker: UIImagePickerController) {
        self.dismiss(animated: true, completion: nil)
    }
    
    override func viewDidLayoutSubviews() {
        super.viewDidLayoutSubviews()
        imgDoctor.layer.borderWidth = 1
        imgDoctor.layer.borderColor = UIColor.gray.cgColor
        imgDoctor.layer.cornerRadius = imgDoctor.frame.height/2
        imgDoctor.clipsToBounds = true
    }
    
    @IBAction func doContinueBtn(_ sender: UIButton) {
        if self.profileUpdateViewModel.validated(){
        self.profileUpdateViewModel.updateProfile(completion: {
            self.navigateToDashboard()
        }) { (error) in
            
        }
    }
    }
    @IBAction func doBackActnBtn(_ sender: UIButton) {
        self.navigationController?.popViewController(animated: true)
    }
    func navigateToDashboard()
    {
        let mainStoryboard: UIStoryboard = UIStoryboard(name: "Main", bundle: nil)
        let leftMenuVC: MenuViewController = mainStoryboard.instantiateViewController(withIdentifier: "MenuViewController") as! MenuViewController
        let centerVC : UIViewController
        if CommonUtility.isPilate() {
            let storyboard =  UIStoryboard(name: "Pilates", bundle: nil)
            centerVC = storyboard.instantiateViewController(withIdentifier: "PilatesDashboardViewController")
        }else{
            centerVC = mainStoryboard.instantiateViewController(withIdentifier: "DashboardViewController")
        }
        let centerNavVC = UINavigationController(rootViewController: centerVC)
        //  Set the Panel controllers with just two lines of code
        let panelVC = FAPanelController()
        panelVC.configs.leftPanelWidth = kLeftPanelWidth
        panelVC.leftPanelPosition = .front
        
        _ = panelVC.center(centerNavVC).left(leftMenuVC)
        
        UIView.transition(from: self.view, to: centerVC.view, duration: 0.0, options: UIViewAnimationOptions.transitionCrossDissolve) { (finished) in
            _ = panelVC.center(centerNavVC).left(leftMenuVC); UIApplication.shared.keyWindow?.rootViewController = panelVC
        }
    }
    
    override func touchesBegan(_ touches: Set<UITouch>, with event: UIEvent?) {
        self.view.endEditing(true)
    }
}

extension DoctorProfileUpdationViewController: UITextFieldDelegate {
    func textField(_ textField: UITextField, shouldChangeCharactersIn range: NSRange, replacementString string: String) -> Bool {
        if let text = textField.text as NSString? {
            let txtAfterUpdate = text.replacingCharacters(in: range, with: string)
            if textField.tag == DoctorProfileUpdateTextFieldTag.qualificationTextField.rawValue {
                self.profileUpdateViewModel.qualification = txtAfterUpdate
            }else if textField.tag == DoctorProfileUpdateTextFieldTag.expertiseTextField.rawValue {
                self.profileUpdateViewModel.expertise = txtAfterUpdate
            }else if textField.tag == DoctorProfileUpdateTextFieldTag.experienceTextField.rawValue {
                self.profileUpdateViewModel.experience = txtAfterUpdate
            }else {
                self.profileUpdateViewModel.achievements = txtAfterUpdate
            }
        }
        return true
    }
}
