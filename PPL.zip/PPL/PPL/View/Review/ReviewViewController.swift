//
//  ReviewViewController.swift
//  PPL
//
//  Created by TanjeetAjmani on 13/06/18.
//  Copyright © 2018 cdn. All rights reserved.
//

import UIKit

class ReviewViewController: UIViewController,UITextViewDelegate{

    @IBOutlet weak var textViewBottomConstraint: NSLayoutConstraint!
    @IBOutlet weak var viewPopBottomConstraint: NSLayoutConstraint!
    @IBOutlet weak var btnSubmit: UIButton!
    @IBOutlet weak var tvReview: UITextView!
    @IBOutlet weak var lblReview: UILabel!
    @IBOutlet weak var viewPop: UIView!
    public var strDoctorId : String = ""
    
    override func viewDidLoad() {
        super.viewDidLoad()
        tvReview.delegate = self
       decorateUI()
        styleUI()
        NotificationCenter.default.addObserver(self, selector: #selector(keyboardWillChangeFrame), name: NSNotification.Name.UIKeyboardWillChangeFrame, object: nil)
       
    }

    override func touchesBegan(_ touches: Set<UITouch>, with event: UIEvent?) {
        if let touch = touches.first {
            if touch.view == self.view {
                self.hideViewWithAnimation()
            }
        }
    }

    func styleUI() {
        DecorateControls.styleLabel(label: lblReview, text: "Write Review", font: UIFont.systemFont(ofSize: FONT_SIZE_28), textColor: blackColor())
        DecorateControls.putText(textView: tvReview, text: "Write a Review", font: UIFont.systemFont(ofSize: FONT_SIZE_18), textColor: UIColor.gray)
        DecorateControls.putTitle(button: btnSubmit, text: "Submit", font: UIFont.boldSystemFont(ofSize: FONT_SIZE_22), textColor: whiteColor(), backGroundColor: appColor())
        lblReview.backgroundColor = color(red: 204, green: 204, blue: 204)
        btnSubmit.layer.cornerRadius = 5
        tvReview.layer.borderWidth = 1
        tvReview.layer.borderColor = blackColor().cgColor
    }
    
    func decorateUI(){
        self.view.backgroundColor = UIColor.black.withAlphaComponent(0.6)
        self.viewPop.layer.cornerRadius = 7
        self.viewPop.layer.shadowOpacity = 0.8
        self.viewPop.layer.borderWidth = 1.0
        self.viewPop.layer.borderColor = UIColor.black.cgColor
        self.viewPop.clipsToBounds = true
        self.showAnimation()
    }
    
    func showAnimation(){
        self.view.alpha = 0
        self.viewPop.transform = CGAffineTransform(scaleX: 0.1, y: 0.1)
        UIView.animate(withDuration: 0.3) {
            self.viewPop.transform = CGAffineTransform(scaleX: 1.0, y: 1.0)
            self.view.alpha = 1
        }
    }
    
    func hideViewWithAnimation() {
        UIView.animate(withDuration: 0.3, animations: {
            self.viewPop.transform = CGAffineTransform(scaleX: 0.1, y: 0.1)
            self.view.alpha = 0
        }, completion: {
            (value: Bool) in
            self.removeFromParentViewController()
            self.view.removeFromSuperview()
        })
    }
    
    func textViewDidBeginEditing(_ textView: UITextView) {
        
        if tvReview.textColor == UIColor.gray {
            tvReview.text = nil
            tvReview.textColor = UIColor.black
        }
    }
   
    func textViewDidEndEditing(_ textView: UITextView) {
        viewPopBottomConstraint.constant = 167
        if tvReview.text.isEmpty {
            DecorateControls.putText(textView: tvReview, text: "Write a Review", font: UIFont.systemFont(ofSize: FONT_SIZE_18), textColor: UIColor.gray)
        }
    }
    @objc private func keyboardWillChangeFrame(_ notification: Notification) {
        if let endFrame = (notification.userInfo?[UIKeyboardFrameEndUserInfoKey] as? NSValue)?.cgRectValue {
            var keyboardHeight = UIScreen.main.bounds.height - endFrame.origin.y
            if #available(iOS 11, *) {
                if keyboardHeight > 0 {
                    keyboardHeight = keyboardHeight - view.safeAreaInsets.bottom
                }
            }
            if keyboardHeight == 0 {
                viewPopBottomConstraint.constant =  10
                view.layoutIfNeeded()
                
            }
            else {
                viewPopBottomConstraint.constant = keyboardHeight - 20
                view.layoutIfNeeded()
              
            }
        }
    }
    @IBAction func doSubmit(_ sender: UIButton) {
        let apiManager = APIManager()
        var params = [String : Any]()
        params["doctor_id"] = self.strDoctorId
        params["review"] = self.tvReview.text
        params["rating"] = 5
        
        apiManager.addReview(parameters: params, completion: { (response) in
            let resultCode = response["result_code"] as! Bool
            if resultCode {
                self.hideViewWithAnimation()
                CommonUtility.showSuccessCRNotifications(title: "Success!!", message: NSLocalizedString("title.success.review.added", comment: "This message shown after the review added successfully."))
            }else {
                CommonUtility.showErrorCRNotifications(title: appTitle(), message: response["message"] as! String)
            }
        }) { (error) in
            CommonUtility.showErrorCRNotifications(title: "Error!", message: (error?.localizedDescription)!)
        }
    }
}
