//
//  DoctorProfileViewController.swift
//  PPL
//
//  Created by TanjeetAjmani on 08/05/18.
//  Copyright © 2018 cdn. All rights reserved.
//

import UIKit
import SDWebImage

class DoctorProfileViewController: UIViewController,UINavigationControllerDelegate,UIImagePickerControllerDelegate {
    
    @IBOutlet weak var btnEdit: UIButton!
    @IBOutlet weak var btnChangePassword: UIButton!
    @IBOutlet weak var tfAddress: UITextField!
    @IBOutlet weak var tfAcheivements: UITextField!
    @IBOutlet weak var tfExperience: UITextField!
    @IBOutlet weak var tfExpertise: UITextField!
    @IBOutlet weak var tfQualification: UITextField!
    @IBOutlet weak var tfEmail: UITextField!
    @IBOutlet weak var tfUserName: UITextField!
    @IBOutlet weak var tfLastName: UITextField!
    @IBOutlet weak var tfFirstName: UITextField!
    @IBOutlet weak var lblAcheivements: UILabel!
    @IBOutlet weak var lblAddress: UILabel!
    @IBOutlet weak var lblEmail: UILabel!
    @IBOutlet weak var lblUserName: UILabel!
    @IBOutlet weak var lblLastName: UILabel!
    @IBOutlet weak var lblFirstName: UILabel!
    @IBOutlet weak var lblName: UILabel!
    @IBOutlet weak var btnUpdate: UIButton!
    @IBOutlet weak var btnCancel: UIButton!
    @IBOutlet weak var tVDoctrProfile: UITableView!
    @IBOutlet weak var imgSeptr3: UIImageView!
    @IBOutlet weak var imgSeptr1: UIImageView!
    @IBOutlet weak var imgSeprtr2: UIImageView!
    @IBOutlet weak var lblExperienceDetail: UILabel!
    @IBOutlet weak var lblExpertiseDetail: UILabel!
    @IBOutlet weak var lblQualificatnDetail: UILabel!
    @IBOutlet weak var lblExperience: UILabel!
    @IBOutlet weak var lblExpertise: UILabel!
    @IBOutlet weak var lblQualification: UILabel!
    @IBOutlet weak var viewLbl: UIView!
    @IBOutlet weak var imageDoc: UIImageView!
    @IBOutlet weak var viewImg: UIView!
    @IBOutlet weak var viewBG: UIView!
    @IBOutlet weak var viewProfile: UIView!
    let imagePicker = UIImagePickerController()
    
    var arrProfile  = [["lblType":"Expertise:","lblDetail" : "Ankle ,Shoulder ,Sprains"],["lblType":"Experience:","lblDetail" : "Ankle ,Shoulder ,Sprains"],["lblType":"Achievements:","lblDetail" : "Ankle ,Shoulder ,Sprains"]]
    
    var userModel: UserModel = CommonUtility.userProfile()!
    var profileUpdateViewModel = PilateProfileUpdateViewModel()
    
    override func viewDidLoad() {
        super.viewDidLoad()
        self.styleUI()
        self.navigationBarStyle()
        //  self.getProfileList()
    }
    
    override func viewWillAppear(_ animated: Bool) {
        super.viewWillAppear(true)
        self.navigationController?.isNavigationBarHidden = false
    }
    
    func styleUI () {
        btnEdit.layer.cornerRadius = 10
        btnChangePassword.layer.cornerRadius = 10
        viewLbl.layer.borderWidth = 1
        viewLbl.layer.borderColor = UIColor.lightGray.cgColor
        self.btnEdit.isSelected = false
        self.btnEdit.setImage(#imageLiteral(resourceName: "edit"), for: .normal)
        self.btnEdit.setImage(#imageLiteral(resourceName: "icon_update_s5"), for: .selected)
        self.viewProfile.dropShadow(color: .lightGray, opacity: 1, offSet: CGSize(width: -1, height: 1), radius: 3, scale: true)
        self.viewBG.bringSubview(toFront: btnEdit)
        self.viewBG.bringSubview(toFront: viewLbl)
        self.viewBG.bringSubview(toFront: viewImg)
        self.viewBG.bringSubview(toFront: btnChangePassword)
        
        DecorateControls.putTitle(button: btnChangePassword, text: "Change Password", font: UIFont.systemFont(ofSize: FONT_SIZE_25), textColor: whiteColor(), backGroundColor: appColor())
        DecorateControls.styleLabel(label: lblName, text: " \(userModel.result.firstname!) \(userModel.result.lastname!)", font: UIFont.systemFont(ofSize: FONT_SIZE_25), textColor: blackColor())
        DecorateControls.styleLabel(label: lblQualification, text: "Qualification :", font: UIFont.systemFont(ofSize: FONT_SIZE_17), textColor: UIColor.darkGray)
        DecorateControls.putText(textField: tfQualification, text: userModel.result.qualification, placehoder: "Enter Qualification", font: UIFont.systemFont(ofSize: FONT_SIZE_17), textColor: UIColor.darkGray)
        DecorateControls.styleLabel(label: lblExpertise, text: "Expertise       :", font: UIFont.systemFont(ofSize: FONT_SIZE_17), textColor: UIColor.darkGray)
        DecorateControls.putText(textField: tfExpertise, text: userModel.result.expertise, placehoder: "Enter Expertise", font: UIFont.systemFont(ofSize: FONT_SIZE_17), textColor: UIColor.darkGray)
        DecorateControls.styleLabel(label: lblExperience, text: "Experience    :", font: UIFont.systemFont(ofSize: FONT_SIZE_17), textColor: UIColor.darkGray)
        DecorateControls.putText(textField: tfExperience, text: userModel.result.experience, placehoder: "Enter Experience", font: UIFont.systemFont(ofSize: FONT_SIZE_17), textColor: UIColor.darkGray)
        DecorateControls.styleLabel(label: lblFirstName, text:"First Name    :" , font: UIFont.systemFont(ofSize: FONT_SIZE_17), textColor: UIColor.darkGray)
        DecorateControls.styleLabel(label: lblLastName, text: "Last Name     :", font: UIFont.systemFont(ofSize: FONT_SIZE_17), textColor: UIColor.darkGray)
        DecorateControls.styleLabel(label: lblUserName, text: "Username     :", font: UIFont.systemFont(ofSize: FONT_SIZE_17), textColor: UIColor.darkGray)
        DecorateControls.styleLabel(label: lblAcheivements, text: "Acheivments :", font: UIFont.systemFont(ofSize: FONT_SIZE_17), textColor: UIColor.darkGray)
        DecorateControls.styleLabel(label: lblAddress, text: "Address         :", font: UIFont.systemFont(ofSize: FONT_SIZE_17), textColor: UIColor.darkGray)
        DecorateControls.styleLabel(label: lblEmail, text: "Email              :", font: UIFont.systemFont(ofSize: FONT_SIZE_17), textColor: UIColor.darkGray)
        DecorateControls.putText(textField: tfFirstName, text: userModel.result.firstname, placehoder: "Enter First Name", font: UIFont.systemFont(ofSize: FONT_SIZE_17), textColor: UIColor.darkGray)
        DecorateControls.putText(textField: tfLastName, text: userModel.result.lastname, placehoder: "Enter Last Name", font: UIFont.systemFont(ofSize: FONT_SIZE_17), textColor: UIColor.darkGray)
        DecorateControls.putText(textField: tfUserName, text: userModel.result.username, placehoder: "Enter Username", font: UIFont.systemFont(ofSize: FONT_SIZE_17), textColor: UIColor.darkGray)
        DecorateControls.putText(textField: tfAcheivements, text: userModel.result.achievement, placehoder: "Enter Acheivments", font: UIFont.systemFont(ofSize: FONT_SIZE_17), textColor: UIColor.darkGray)
        DecorateControls.putText(textField: tfAddress, text: userModel.result.address, placehoder: "Enter Address", font: UIFont.systemFont(ofSize: FONT_SIZE_17), textColor: UIColor.darkGray)
        DecorateControls.putText(textField: tfEmail, text: userModel.result.email, placehoder: "Enter Email", font: UIFont.systemFont(ofSize: FONT_SIZE_17), textColor: UIColor.darkGray)
        
        tfUserName.isEnabled = false
        tfEmail.isEnabled = false
        tfAddress.isEnabled = false
        tfFirstName.isEnabled = false
        tfLastName.isEnabled = false
        tfQualification.isEnabled = false
        tfExpertise.isEnabled = false
        tfExperience.isEnabled = false
        tfAcheivements.isEnabled = false
        self.updateControlsState(shouldEnabled: false)
        
        let tapG = UITapGestureRecognizer.init(target: self, action: #selector(self.profileImageClicked(sender:)))
        tapG.numberOfTapsRequired = 1
        self.imageDoc.isUserInteractionEnabled = true
        self.imageDoc.addGestureRecognizer(tapG)
        self.imagePicker.delegate = self
        self.profileUpdateViewModel.profileImage = self.imageDoc.image
        self.profileUpdateViewModel.qualification = self.userModel.result.qualification
        
        self.imageDoc.sd_setImage(with: URL(string: self.userModel.result.profile_image!), placeholderImage: #imageLiteral(resourceName: "no-inage"))
        
        tfFirstName.attributedPlaceholder = NSAttributedString(string: "Enter First Name",attributes: [NSAttributedStringKey.foregroundColor: UIColor.darkGray])
        tfLastName.attributedPlaceholder = NSAttributedString(string: "Enter Last Name",attributes: [NSAttributedStringKey.foregroundColor: UIColor.darkGray])
        tfQualification.attributedPlaceholder = NSAttributedString(string: "Enter Qualification",attributes: [NSAttributedStringKey.foregroundColor: UIColor.darkGray])
        tfExpertise.attributedPlaceholder = NSAttributedString(string: "Enter Expertise",attributes: [NSAttributedStringKey.foregroundColor: UIColor.darkGray])
        tfExperience.attributedPlaceholder = NSAttributedString(string: "Enter Experience",attributes: [NSAttributedStringKey.foregroundColor: UIColor.darkGray])
        tfAcheivements.attributedPlaceholder = NSAttributedString(string: "Enter Acheivements",attributes: [NSAttributedStringKey.foregroundColor: UIColor.darkGray])
        tfAddress.attributedPlaceholder = NSAttributedString(string: "Enter Address",attributes: [NSAttributedStringKey.foregroundColor: UIColor.darkGray])
        
        
        profileUpdateViewModel.firstName = userModel.result.firstname
        profileUpdateViewModel.lastName = userModel.result.lastname
        profileUpdateViewModel.qualification = userModel.result.qualification
        profileUpdateViewModel.expertise = userModel.result.expertise
        profileUpdateViewModel.experience = userModel.result.experience
        profileUpdateViewModel.achievements = userModel.result.achievement
        profileUpdateViewModel.address = userModel.result.address
        profileUpdateViewModel.profileImage = self.imageDoc.image
        
    }
    
    func navigationBarStyle (){
        
        if navigationController?.viewControllers.count == 1 {
            CommonUtility.createCustomBackButton(self, navBarItem: self.navigationItem, strImage: "menu_slide", select: #selector(doClickSideMenu))
        }
        else {
            CommonUtility.createCustomBackButton(self, navBarItem: self.navigationItem, strImage: "back_icon _white", select: #selector(openPopView))
        }
        CommonUtility.setNavBarTitle(self.navigationItem, title: NSLocalizedString("Doctor Profile", comment: "The title of the Profile navigation bar"))
        CommonUtility.createRightBarOnlyHomeButtons(target: self, navigationItem: self.navigationItem, select1: #selector(openDashBoardView))
        
    }
    @objc func openPopView() {
        self.navigationController?.popViewController(animated: true)
    }
    
    @objc func openDashBoardView()
    {
        CommonUtility.setMenuSelectedOption(menuOptionIndex: 0)
        let centerVC : UIViewController
        let storyboard =  UIStoryboard(name: "Pilates", bundle: nil)
        centerVC = storyboard.instantiateViewController(withIdentifier: "PilatesDashboardViewController")
        let centerNavVC = UINavigationController(rootViewController: centerVC)
        self.panel?.configs.centerPanelTransitionType = .moveLeft
        self.panel?.configs.centerPanelTransitionDuration = 1.0
        _ = panel?.center(centerNavVC)
    }
    
    @objc func doClickSideMenu()
    {
        panel?.openLeft(animated: true)
    }
    
    
    
    @objc func profileImageClicked(sender: UITapGestureRecognizer? = nil){
        let alert : UIAlertController = UIAlertController(title: "Choose Image", message: nil, preferredStyle: UIAlertControllerStyle.actionSheet)
        
        let cameraAction = UIAlertAction(title: "Camera", style: UIAlertActionStyle.default)
        {
            UIAlertAction in
            self.openCamera()
        }
        let gallaryAction = UIAlertAction(title: "Gallery", style: UIAlertActionStyle.default)
        {
            UIAlertAction in
            self.openGallary()
        }
        let cancelAction = UIAlertAction(title: "Cancel", style: UIAlertActionStyle.cancel)
        {
            UIAlertAction in
            
        }
        
        self.imagePicker.modalPresentationStyle = .overCurrentContext
        alert.addAction(cameraAction)
        alert.addAction(gallaryAction)
        alert.addAction(cancelAction)
        if let popoverController = alert.popoverPresentationController {
            popoverController.sourceView = self.imageDoc
            popoverController.sourceRect = self.imageDoc.bounds
        }
        self.present(alert, animated: true, completion: nil)
    }
    
    func openCamera()
    {
        if(UIImagePickerController .isSourceTypeAvailable(UIImagePickerControllerSourceType.camera))
        {
            imagePicker.sourceType = .camera
            self .present(imagePicker, animated: true, completion: nil)
        }
        else
        {
            let alert = UIAlertController(title: "Warning", message: "You don't have camera", preferredStyle: UIAlertControllerStyle.alert)
            alert.addAction(UIAlertAction(title: "Ok", style: UIAlertActionStyle.default, handler: nil))
            self.present(alert, animated: true, completion: nil)
        }
    }
    func openGallary()
    {
        imagePicker.sourceType = .savedPhotosAlbum
        self.present(imagePicker, animated: true, completion: nil)
    }
    
    func imagePickerController(_ picker: UIImagePickerController, didFinishPickingMediaWithInfo info: [String : Any]) {
        let chosenImage = info[UIImagePickerControllerOriginalImage] as! UIImage //2
        let selectedImage : UIImage = chosenImage
        imageDoc.image = selectedImage
        self.profileUpdateViewModel.profileImage = selectedImage
        self.dismiss(animated: true, completion: nil)
    }
    func imagePickerControllerDidCancel(_ picker: UIImagePickerController) {
        self.dismiss(animated: true, completion: nil)
    }
    
    override func viewWillLayoutSubviews() {
        super.viewWillLayoutSubviews()
        self.viewImg.layer.borderWidth = 1
        self.viewImg.layer.masksToBounds = true
        self.viewImg.layer.borderColor = UIColor.lightGray.cgColor
        self.viewImg.layer.cornerRadius = viewImg.frame.width/2
        self.viewImg.clipsToBounds = true
        self.imageDoc.layer.borderWidth = 1
        self.imageDoc.layer.masksToBounds = true
        self.imageDoc.layer.borderColor = UIColor.lightGray.cgColor
        self.imageDoc.layer.cornerRadius = imageDoc.frame.width/2
        self.imageDoc.clipsToBounds = true
    }
    
    
    override func touchesBegan(_ touches: Set<UITouch>, with event: UIEvent?) {
        self.view.endEditing(true)
    }
    
    func updateControlsState(shouldEnabled: Bool) {
        self.tfQualification.isEnabled = shouldEnabled
        self.tfExpertise.isEnabled = shouldEnabled
        self.tfExperience.isEnabled = shouldEnabled
        self.tfAcheivements.isEnabled  = shouldEnabled
        self.tfAddress.isEnabled  = shouldEnabled
        
        self.tfFirstName.isEnabled     = shouldEnabled
        self.tfLastName.isEnabled      = shouldEnabled
        self.imageDoc.isUserInteractionEnabled = shouldEnabled
    }
    
    @IBAction func btnEditActn(_ sender: UIButton) {
        if self.btnEdit.isSelected {
            alertViewController()
        }else {
            self.btnEdit.isSelected = false
        }
        self.updateControlsState(shouldEnabled: btnEdit.isSelected)
        
    }
    
    func alertViewController() {
        let alert = UIAlertController(title: "Alert", message: "Do you want to update your Profile?", preferredStyle: UIAlertControllerStyle.alert)
        alert.addAction(UIAlertAction(title: "Yes", style: .default, handler: { action in
            switch action.style{
            case .default:
                self.btnEdit.isSelected = false
                self.profileUpdateViewModel.updateProfile(completion: {
                    
                }) { (error) in
                    
                }
            case .cancel:
                print("cancel")
            case .destructive:
                print("destructive")
            }}))
        alert.addAction(UIAlertAction(title: "No", style: .cancel, handler: { action in
            switch action.style{
            case .default:
                print("default")
                
            case .cancel:
                print("cancel")
                
            case .destructive:
                print("destructive")
            }}))
        self.present(alert, animated: true, completion: nil)
    }
    @IBAction func btnChangePasswordActn(_ sender: UIButton) {
        let pushVc = self.storyboard?.instantiateViewController(withIdentifier: "PilateChangePasswordViewController") as! PilateChangePasswordViewController
        self.navigationController?.pushViewController(pushVc, animated: true)
    }
    
    func getProfileList() {
        if profileUpdateViewModel.achievements == nil {
            CommonUtility.loadNoDataFound(vc: self,message: NSLocalizedString("title.error.nodata", comment: "Showing no data found."))
        }
    }
}

extension DoctorProfileViewController:  UITextFieldDelegate {
    func textField(_ textField: UITextField, shouldChangeCharactersIn range: NSRange, replacementString string: String) -> Bool {
        if let text = textField.text as NSString? {
            let txtAfterUpdate = text.replacingCharacters(in: range, with: string)
            
            if   textField == tfFirstName {
                self.profileUpdateViewModel.firstName = txtAfterUpdate
            }else if textField == tfLastName{
                self.profileUpdateViewModel.lastName = txtAfterUpdate
            }else if textField == tfQualification{
                self.profileUpdateViewModel.qualification = txtAfterUpdate
            } else if textField == tfExpertise{
                self.profileUpdateViewModel.expertise = txtAfterUpdate
            }  else if textField == tfExperience{
                self.profileUpdateViewModel.experience = txtAfterUpdate
            }  else if textField == tfAcheivements{
                self.profileUpdateViewModel.achievements = txtAfterUpdate
            } else {
                self.profileUpdateViewModel.address! = txtAfterUpdate
            }
        }
        return true
    }
}
