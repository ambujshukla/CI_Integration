//
//  DoctorProfileTableViewCell.swift
//  PPL
//
//  Created by TanjeetAjmani on 08/05/18.
//  Copyright © 2018 cdn. All rights reserved.
//

import UIKit

protocol DoctorProfileInputCellDelegate: class{
    func inputCell(_ cell: DoctorProfileTableViewCell, didChangeText text: String?)
}

class DoctorProfileTableViewCell: UITableViewCell {
    
    weak var delegate: DoctorProfileInputCellDelegate?
    @IBOutlet weak var imgSeptrLine: UIImageView!
    @IBOutlet weak var lblType: UILabel!
    @IBOutlet weak var tfDetail: UITextField!
    
    override func awakeFromNib() {
        DecorateControls.styleLabel(label: lblType, text: "", font: UIFont.systemFont(ofSize: FONT_SIZE_20), textColor: blackColor())
        DecorateControls.putText(textField: tfDetail, text: "", placehoder: "", font: UIFont.systemFont(ofSize: FONT_SIZE_20), textColor: color(red: 117, green: 117, blue: 117))
        self.tfDetail.delegate = self
    }
}

extension DoctorProfileTableViewCell:  UITextFieldDelegate {
    func textField(_ textField: UITextField, shouldChangeCharactersIn range: NSRange, replacementString string: String) -> Bool {
        if let text = textField.text as NSString? {
            let txtAfterUpdate = text.replacingCharacters(in: range, with: string)
            self.delegate?.inputCell(self, didChangeText: txtAfterUpdate)
        }
        return true
    }
}

