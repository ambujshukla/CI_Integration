//
//  SessionsViewController.swift
//  TwoDimentionScroll
//
//  Created by PankajPurohit on 29/05/18.
//  Copyright © 2018 PankajPurohit. All rights reserved.
//

import UIKit

class SessionTableCell: UITableViewCell {
    @IBOutlet weak var imgCircle: UIImageView!
    override func awakeFromNib() {
        super.awakeFromNib()
        imgCircle.layer.cornerRadius = imgCircle.frame.size.width/2;
        imgCircle.clipsToBounds = true
    }
}

class SessionCollectionCell: UICollectionViewCell {
    @IBOutlet weak var lblTitle: UILabel!
    @IBOutlet weak var imgBg: UIImageView!
    override func awakeFromNib() {
        super.awakeFromNib()
        imgBg.layer.cornerRadius = 5;
        imgBg.clipsToBounds = true
        imgBg.isHidden = true
        DecorateControls.styleLabel(label: lblTitle, text: "", font: UIFont.systemFont(ofSize: FONT_SIZE_15), textColor: blackColor())
    }
}

class SessionsViewController: UIViewController,UITableViewDelegate,UITableViewDataSource,UICollectionViewDelegate,UICollectionViewDataSource,UICollectionViewDelegateFlowLayout {
    @IBOutlet weak var containerView: UIView!
    @IBOutlet weak var subContainerView: UIView!
    @IBOutlet weak var collectionView: UICollectionView!
    @IBOutlet weak var tblView: UITableView!
    @IBOutlet weak var lblHeading: UILabel!
    @IBOutlet weak var txtViewAnswer: UITextView!
    var arrCount : Int?
    
    @IBOutlet weak var collecionViewWidth: NSLayoutConstraint!
    var selectedIndex:Int = 0
    var sessionsViewModel = SessionsViewModel()
    var patientDetailModel = PatientList()

    override func viewDidLoad() {
        super.viewDidLoad()
        decorateUI()
        self.navigationBarStyle()
        self.sessionsViewModel.patientId = self.patientDetailModel.user_id
        self.getSessionsList()
    }

    func navigationBarStyle (){
        CommonUtility.createCustomBackButton(self, navBarItem: self.navigationItem, strImage: "back_icon _white", select: #selector(openPopView))
        CommonUtility.setNavBarTitle(self.navigationItem, title: NSLocalizedString("Sessions", comment: "The title of the Sessions navigation bar"))
        CommonUtility.createRightBarHomeButtons(target: self, navigationItem: self.navigationItem, select1: #selector(openProfileView), select2: #selector(openDashBoardView))
    }
    
    @objc func openPopView()
    {
        self.navigationController?.popViewController(animated: true)
    }
    
    @objc func openDashBoardView()
    {
        CommonUtility.setMenuSelectedOption(menuOptionIndex: 0)
        let centerVC : UIViewController
        let storyboard =  UIStoryboard(name: "Pilates", bundle: nil)
        centerVC = storyboard.instantiateViewController(withIdentifier: "PilatesDashboardViewController")
        let centerNavVC = UINavigationController(rootViewController: centerVC)
        self.panel?.configs.centerPanelTransitionType = .moveLeft
        self.panel?.configs.centerPanelTransitionDuration = 1.0
        _ = panel?.center(centerNavVC)
    }
    
    @objc func openProfileView()
    {
     let pushVc = self.storyboard?.instantiateViewController(withIdentifier: "DoctorProfileViewController") as! DoctorProfileViewController
    self.navigationController?.pushViewController(pushVc, animated: true)
          
    }
    
    override func viewDidLayoutSubviews() {
        super.viewDidLayoutSubviews()
        collectionView.layer.cornerRadius = 5;
        collectionView.layer.borderWidth = 0.5;
        collectionView.layer.borderColor = UIColor(red:232/255,green:191/255,blue:65/255,alpha:1).cgColor
        collectionView.clipsToBounds = true
    }
    
    //MARK: - UICollectionViewDatasource Methods
    func collectionView(_ collectionView: UICollectionView, numberOfItemsInSection section: Int) -> Int {
        if self.sessionsViewModel.sessionListArray != nil {
             arrCount = (self.sessionsViewModel.sessionListArray?.result.count)!
            let collectnWidth = arrCount! * 80
            if collectnWidth > 972 {
                collecionViewWidth.constant = 972
            }
            collecionViewWidth.constant = CGFloat(collectnWidth)
            return arrCount!
        }
        return 0
    }
    
    func collectionView(_ collectionView: UICollectionView, cellForItemAt indexPath: IndexPath) -> UICollectionViewCell {
        let cell = collectionView.dequeueReusableCell(withReuseIdentifier: "CellSession", for: indexPath) as! SessionCollectionCell
        cell.lblTitle.text = "Session \(indexPath.row + 1)"
        if selectedIndex == indexPath.item {
            cell.imgBg.isHidden = false
            cell.lblTitle.textColor = UIColor.white
        }else{
            cell.imgBg.isHidden = true
            cell.lblTitle.textColor = UIColor.black
        }
        return cell
    }
    
    //MARK: - UICollectionViewDelegateFlowLayout Methods
    func collectionView(_ collectionView: UICollectionView, layout collectionViewLayout: UICollectionViewLayout, sizeForItemAt indexPath: IndexPath) -> CGSize {
        return CGSize(width: 80, height: collectionView.frame.size.height)
    }
    
    //MARK: - UICollectionViewDelegate Methods
    func collectionView(_ collectionView: UICollectionView, didSelectItemAt indexPath: IndexPath) {
        selectedIndex = indexPath.item
        self.collectionView.reloadData()
        self.tblView.reloadData()
    }
    
    //MARK: - UITableViewDataSource Methods
    func tableView(_ tableView: UITableView, numberOfRowsInSection section: Int) -> Int {
        if self.sessionsViewModel.sessionListArray != nil {
            if (self.sessionsViewModel.sessionListArray?.result.isEmpty)! {
                return 0
            }
            return (self.sessionsViewModel.sessionListArray?.result[selectedIndex].json.count)!
        }
        return 0
    }
    
    func tableView(_ tableView: UITableView, cellForRowAt indexPath: IndexPath) -> UITableViewCell {
        let cell = tableView.dequeueReusableCell(withIdentifier: "CellSession", for: indexPath) as! SessionTableCell
        cell.textLabel?.text = self.sessionsViewModel.sessionListArray?.result[selectedIndex].json[indexPath.row].Q
        
        return cell
    }
    
    func tableView(_ tableView: UITableView, didSelectRowAt indexPath: IndexPath) {
        tableView.deselectRow(at: indexPath, animated: true)
        lblHeading.text = self.sessionsViewModel.sessionListArray?.result[selectedIndex].json[indexPath.row].Q
        txtViewAnswer.text = self.sessionsViewModel.sessionListArray?.result[selectedIndex].json[indexPath.row].A
    }
    
    //MARK: - Custom methods implementation
    private func decorateUI() {
        containerView.dropShadow(color: .lightGray, opacity: 1, offSet: CGSize(width: -1, height: 1), radius: 3, scale: true)
        subContainerView.dropShadow(color: .lightGray, opacity: 1, offSet: CGSize(width: -1, height: 1), radius: 3, scale: true)
        tblView.tableFooterView = UIView()
        DecorateControls.styleLabel(label: lblHeading, text: "", font: UIFont.systemFont(ofSize: FONT_SIZE_18), textColor: blackColor())
        DecorateControls.putText(textView: txtViewAnswer, text: "", font: UIFont.systemFont(ofSize: FONT_SIZE_16), textColor: UIColor.gray)
        
       
   }
    
    func getSessionsList() {
        self.sessionsViewModel.sessionsList { (sessionListArray) in
            self.sessionsViewModel.sessionListArray = sessionListArray
            if self.sessionsViewModel.sessionListArray?.result.count == 0
            {
                CommonUtility.loadNoDataFound(vc: self,message: NSLocalizedString("title.error.nodata", comment: "Showing no data found."))
                return
            }
            self.tblView.reloadData()
            self.collectionView.reloadData()
        }
    }
}
