//
//  CustomTableViewCell.swift
//  NewAppointments
//
//  Created by PujaDwivedi on 01/05/18.
//  Copyright © 2018 PujaDwivedi. All rights reserved.
//

import UIKit

class AppointmentsTableViewCell: UITableViewCell {
    
    @IBOutlet weak var lblTitle: UILabel!
    @IBOutlet weak var lblTime: UILabel?
    @IBOutlet weak var btnAddAppointment: UIButton?
    
    override func awakeFromNib() {
        super.awakeFromNib()
        DecorateControls.styleLabel(label: lblTitle, text: "", font: UIFont.boldSystemFont(ofSize: FONT_SIZE_18), textColor: color(red: 116, green: 116, blue: 116))
        DecorateControls.styleLabel(label: lblTime, text: "", font: UIFont.boldSystemFont(ofSize: FONT_SIZE_16), textColor: color(red: 116, green: 116, blue: 116))
        DecorateControls.putTitle(button: self.btnAddAppointment, text: "Book Appoinment", font: UIFont.boldSystemFont(ofSize: FONT_SIZE_18), textColor: whiteColor(), backGroundColor: appColor())
    }
    
    override func setSelected(_ selected: Bool, animated: Bool) {
        super.setSelected(selected, animated: animated)
        
        // Configure the view for the selected state
    }
    
}
