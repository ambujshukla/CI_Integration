//
//  PilatesAppointmentsViewController.swift
//  PPL
//
//  Created by PankajPurohit on 30/05/18.
//  Copyright © 2018 cdn. All rights reserved.
//

import UIKit
import FSCalendar
import EmptyDataSet_Swift

enum WeekDay: String {
    case today
    case yesterday
}

class PilateAppointmentsViewController: UIViewController,FSCalendarDelegate,FSCalendarDataSource {
    
    @IBOutlet weak var viewCalender: UIView!
    @IBOutlet weak var myTableView: UITableView!
    @IBOutlet weak var leftButton: UIButton!
    @IBOutlet weak var addImage: UIImageView!
    @IBOutlet weak var calLabel: UILabel!
    @IBOutlet weak var addButton: UIButton!
    @IBOutlet weak var rightButton: UIButton!
    var isServiceCall : Bool?
    
    fileprivate weak var calendar: FSCalendar!
    var scheduleViewModel = ScheduleViewModel()
    var filteredArray = [ScheduleList?]()
    
    override func viewDidLoad() {
        super.viewDidLoad()
        self.styleUI()
        self.setUpCalendar()
        self.isServiceCall = false
        self.getScheduleList()
    }
    
    override func viewWillAppear(_ animated: Bool) {
        super.viewWillAppear(true)
        self.navigationController?.isNavigationBarHidden = false
        if self.isServiceCall == true {
         self.getScheduleList()
        }
        
    }
    
    func styleUI()
    {
        self.leftButton.isHidden = false
        self.rightButton.isHidden = false
        self.calLabel.isHidden = true
        self.leftButton.setImage(#imageLiteral(resourceName: "left-arrow"), for: .normal)
        self.rightButton.setImage(#imageLiteral(resourceName: "right-arrow"), for: .normal)
        self.addButton.layer.cornerRadius = 5
        self.addImage.image =  #imageLiteral(resourceName: "add_icon")
        self.myTableView.tableFooterView = UIView()
        self.myTableView.separatorStyle = .none
        
        DecorateControls.styleLabel(label: calLabel, text: "October 2018", font: UIFont.boldSystemFont(ofSize: FONT_SIZE_20), textColor: appColor())
        DecorateControls.putTitle(button: addButton, text: "    Add Schedule", font: UIFont.boldSystemFont(ofSize: FONT_SIZE_18), textColor: whiteColor(), backGroundColor: appColor())
        
        self.styleNavigationBar()
        self.myTableView.estimatedRowHeight = 55
        self.myTableView.rowHeight = UITableViewAutomaticDimension
    }
    
    func setUpCalendar() {
        let calendar = FSCalendar(frame: CGRect(x: 20, y: 30, width: 368 , height: 320))
        calendar.dataSource = self
        calendar.delegate = self
        
        calendar.register(CalendarAppViewCell.self, forCellReuseIdentifier: "cell")
        
        viewCalender.addSubview(calendar)
        viewCalender.bringSubview(toFront: self.rightButton)
        viewCalender.bringSubview(toFront: self.leftButton)
        calendar.appearance.headerTitleColor = UIColor.init(red: 232/255.0, green: 191/255.0, blue: 63/255.0, alpha: 1)
        calendar.appearance.selectionColor = UIColor.init(red: 255/255.0, green: 255/255.0, blue: 255/255.0, alpha: 0)
        calendar.appearance.titleDefaultColor = UIColor.init(red: 116/255.0, green: 116/255.0, blue: 116/255.0, alpha: 1)
        calendar.appearance.titleFont = UIFont.boldSystemFont(ofSize: 14)
        calendar.appearance.titleSelectionColor = UIColor.init(red: 148/255.0, green: 151/255.0, blue: 154/255.0, alpha: 1)
        calendar.appearance.borderSelectionColor = UIColor.init(red: 232/255.0, green: 191/255.0, blue: 63/255.0, alpha: 1)
        calendar.appearance.todayColor = UIColor.init(red: 255/255.0, green: 255/255.0, blue: 255/255.0, alpha: 0)
        
        calendar.appearance.titleTodayColor = UIColor.init(red: 116/255.0, green: 116/255.0, blue: 116/255.0, alpha: 1)
        
        calendar.appearance.weekdayTextColor = UIColor.init(red: 232/255.0, green: 191/255.0, blue: 63/255.0, alpha: 1)
        
        calendar.appearance.caseOptions = [.headerUsesUpperCase,.weekdayUsesSingleUpperCase]
        calendar.appearance.headerMinimumDissolvedAlpha = 0.0
        calendar.scrollEnabled = true
        calendar.layer.borderColor = UIColor.clear.cgColor
        calendar.clipsToBounds = true
        calendar.appearance.subtitleSelectionColor = UIColor.green
        calendar.appearance.subtitlePlaceholderColor = UIColor.black
        calendar.appearance.headerTitleFont = UIFont.boldSystemFont(ofSize: 17)
        calendar.calendarHeaderView.frame = CGRect(x: 20, y: 30, width: 368 , height: 150)
        calendar.calendarHeaderView.frame.offsetBy(dx: 50, dy: 80)
        self.automaticallyAdjustsScrollViewInsets = false
        self.calendar = calendar
    }
    
    func getScheduleList() {
        self.scheduleViewModel.getScheduleList(completion: { (scheduleList) in
            self.scheduleViewModel.scheduleList = scheduleList
            self.filteredArray = (self.scheduleViewModel.scheduleList?.result)!
            self.myTableView.reloadData()
        }) { (error) in
            
        }
    }
    
    func styleNavigationBar()
    {
        if navigationController?.viewControllers.count == 1 {
            CommonUtility.createCustomBackButton(self, navBarItem: self.navigationItem, strImage: "menu_slide", select: #selector(doClickSideMenu))
        }
        else {
            CommonUtility.createCustomBackButton(self, navBarItem: self.navigationItem, strImage: "back_icon _white", select: #selector(openPopView))
        }
        
        CommonUtility.setNavBarTitle(self.navigationItem, title: NSLocalizedString("Schedule", comment: "The title of the appointments navigation bar"))
        CommonUtility.createRightBarHomeButtons(target: self, navigationItem: self.navigationItem, select1: #selector(openProfileView), select2: #selector(openDashBoardView))
    }
    
    @objc func openPopView() {
        self.navigationController?.popViewController(animated: true)
    }
    
    @objc func openProfileView()
    {
    self.navigationController?.pushViewController((self.storyboard?.instantiateViewController(withIdentifier: "DoctorProfileViewController"))!, animated: true)
        
    }
    
    @objc func openDashBoardView()
    {
        CommonUtility.setMenuSelectedOption(menuOptionIndex: 0)
        let centerVC : UIViewController
        let storyboard =  UIStoryboard(name: "Pilates", bundle: nil)
        centerVC = storyboard.instantiateViewController(withIdentifier: "PilatesDashboardViewController")
        let centerNavVC = UINavigationController(rootViewController: centerVC)
        self.panel?.configs.centerPanelTransitionType = .moveLeft
        self.panel?.configs.centerPanelTransitionDuration = 1.0
        _ = panel?.center(centerNavVC)
    }
    
    //MARK: - Navigation Bar Methods
    @objc func doClickSideMenu()
    {
        panel?.openLeft(animated: true)
    }
    
    @objc func openNotificationsView()
    {
        self.navigationController?.pushViewController((self.storyboard?.instantiateViewController(withIdentifier: "NotificationsViewController"))!, animated: true)
    }
    
    @objc func openSettingsView()
    {
        self.navigationController?.pushViewController((self.storyboard?.instantiateViewController(withIdentifier: "SettingsViewController"))!, animated: true)
    }
    
    func calendar(_ calendar: FSCalendar, cellFor date: Date, at position: FSCalendarMonthPosition) -> FSCalendarCell {
        let cell = calendar.dequeueReusableCell(withIdentifier: "cell", for: date, at: position)
        cell.backgroundColor = UIColor.init(red: 235/255.0, green: 235/255.0, blue: 235/255.0, alpha: 1)
        return cell
    }
    
    func calendar(_ calendar: FSCalendar, didSelect date: Date, at monthPosition: FSCalendarMonthPosition) {
        self.filteredArray = (self.scheduleViewModel.scheduleList?.result.filter({$0.date == CommonUtility.ChangeDateToString(dateObj: date, newFormate: "yyyy-MM-dd")}))!
        self.myTableView.reloadData()
    }
    @IBAction func addAppointment(sender : UIButton)
    {
        self.isServiceCall = true
        self.navigationController?.pushViewController((self.storyboard?.instantiateViewController(withIdentifier: "AddScheduleViewController"))!, animated: true)
    }
    
    @IBAction func leftSwipeActn(_ sender: UIButton) {
        let _calendar = Calendar.current
        var dateComponents = DateComponents()
        dateComponents.month = -1
        self.calendar.currentPage = _calendar.date(byAdding: dateComponents, to: self.calendar.currentPage)!
        self.calendar.setCurrentPage(self.calendar.currentPage, animated: true)
    }
    
    @IBAction func rightSwipeActn(_ sender: UIButton) {
        let _calendar = Calendar.current
        var dateComponents = DateComponents()
        dateComponents.month = 1
        self.calendar.currentPage = _calendar.date(byAdding: dateComponents, to: self.calendar.currentPage)!
        self.calendar.setCurrentPage(self.calendar.currentPage, animated: true)
    }
    
    func calendar(_ calendar: FSCalendar, shouldSelect date: Date, at monthPosition: FSCalendarMonthPosition) -> Bool {
        return monthPosition == .current
    }
}

extension PilateAppointmentsViewController: UITableViewDataSource {
    func tableView(_ tableView: UITableView, cellForRowAt indexPath: IndexPath) -> UITableViewCell {
      
        let cell = myTableView.dequeueReusableCell(withIdentifier: "cell") as! AppointmentsTableViewCell
        cell.selectionStyle = .none
        cell.lblTitle.text = self.filteredArray[indexPath.section]?.time_details![indexPath.row].title
        cell.lblTime?.text = "\(CommonUtility.changeDateFormateOfDate(obj: (self.filteredArray[indexPath.section]?.time_details![indexPath.row].start_time)!, oldFormate: "HH:mm:ss", newFormate: "hh:mm a")) - \(CommonUtility.changeDateFormateOfDate(obj: (self.filteredArray[indexPath.section]?.time_details![indexPath.row].end_time)!, oldFormate: "HH:mm:ss", newFormate: "hh:mm a"))"
        return cell
    }
    
    func numberOfSections(in tableView: UITableView) -> Int {
        return self.filteredArray.count
    }
    
    func tableView(_ tableView: UITableView, numberOfRowsInSection section: Int) -> Int {
        return (self.filteredArray[section]!.time_details?.count)!
    }
}

extension PilateAppointmentsViewController: UITableViewDelegate{
    func tableView(_ tableView: UITableView, viewForHeaderInSection section: Int) -> UIView? {
        let cell = myTableView.dequeueReusableCell(withIdentifier: "cellHeader") as! AppointmentsTableViewCell
        cell.lblTitle.font = UIFont.boldSystemFont(ofSize: 14)
        DecorateControls.styleLabel(label: cell.lblTitle, text: CommonUtility.changeDateFormateOfDate(obj: (self.filteredArray[section]?.date)!, oldFormate: "yyyy-MM-dd", newFormate: "dd-MM-yyyy"), font: UIFont.boldSystemFont(ofSize: FONT_SIZE_16), textColor: blackColor())
        return cell
    }
    
    func tableView(_ tableView: UITableView, heightForRowAt indexPath: IndexPath) -> CGFloat {
        return 50 //UITableViewAutomaticDimension
    }
    func tableView(_ tableView: UITableView, heightForHeaderInSection section: Int) -> CGFloat {
        return 40
    }
    func tableView(_ tableView: UITableView, didSelectRowAt indexPath: IndexPath) {
        let arrUserList =  (self.filteredArray[indexPath.section]?.time_details![indexPath.row].userList)
        self.isServiceCall = false
        if !(arrUserList!.isEmpty) {
            let storyboard =  UIStoryboard(name: "Pilates", bundle: nil)
            let vc = storyboard.instantiateViewController(withIdentifier: "MyClassViewController") as! MyClassViewController
            vc.myClassViewModel.schedule_id = arrUserList![0].schedules_id!
          
            //vc.userList = arrUserList!
                self.navigationController?.pushViewController(vc, animated: true)
        }else{
            CommonUtility.showErrorCRNotifications(title: appTitle(), message: "No Appointment available on selected schedule")
        }
    }
}

extension PilateAppointmentsViewController: EmptyDataSetSource, EmptyDataSetDelegate {
    func title(forEmptyDataSet scrollView: UIScrollView) -> NSAttributedString? {
        return CommonUtility.dzEmptySetTitle(title: NSLocalizedString("title.error.nodata", comment: "This string shows when there is no data found."))
    }
    
    func buttonTitle(forEmptyDataSet scrollView: UIScrollView, for state: UIControlState) -> NSAttributedString? {
        return CommonUtility.dzEmptySetButtonTitle(title: NSLocalizedString("title.retry", comment: "This gives the option for retry when there is no data."))
    }
    
    func emptyDataSet(_ scrollView: UIScrollView, didTapButton button: UIButton) {
        self.getScheduleList()
    }
    func emptyDataSetShouldDisplay(_ scrollView: UIScrollView) -> Bool {
        
        return true
    }
}

