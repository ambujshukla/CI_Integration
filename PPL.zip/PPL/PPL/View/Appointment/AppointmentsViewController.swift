//
//  ViewController.swift
//  NewAppointments
//
//  Created by PujaDwivedi on 01/05/18.
//  Copyright © 2018 PujaDwivedi. All rights reserved.
//

import UIKit
import EmptyDataSet_Swift

class AppointmentsViewController: UIViewController{
    
    //  var dataset = [["section"  : "TODAY 11/08/2017" , "data": [["label" : "\u{2022} Joint Mobilisation" , "labelTime" : "1:00 P.M. - 2:00 P.M." ],["label" : "\u{2022} Muscle Stretching" , "labelTime" : "1:00 P.M. - 2:00 P.M." ]]],["section" : "TOMORROW 1/09/2017" , "data" : [["label" : "\u{2022} Joint Mobilisation" , "labelTime" : "1:00 P.M. - 2:00 P.M." ],["label" : "\u{2022} Muscle Stretching" , "labelTime" : "1:00 P.M. - 2:00 P.M." ],["label" : "\u{2022} Muscle Stretching" , "labelTime" : "1:00 P.M. - 2:00 P.M." ]]]]
    
    @IBOutlet weak var viewCalender: UIView!
    @IBOutlet weak var myTableView: UITableView!
    @IBOutlet weak var labelTime: UILabel!
    @IBOutlet weak var labelPilate: UILabel!
    @IBOutlet weak var labelDuration: UILabel!
    @IBOutlet weak var labelSession: UILabel!
    @IBOutlet weak var labelDate: UILabel!
    @IBOutlet weak var timeValue: UILabel!
    @IBOutlet weak var pilateValue: UILabel!
    @IBOutlet weak var durationValue: UILabel!
    @IBOutlet weak var sessionValue: UILabel!
    @IBOutlet weak var dateValue: UILabel!
    @IBOutlet weak var todayLabel: UILabel!
    @IBOutlet weak var scheduleListTableView: UITableView!
    @IBOutlet weak var myAppointmentLabel: UILabel!
    @IBOutlet weak var scheduleListLabel: UILabel!
    
    var appointmentsViewModel = AppointmentsViewModel()
    
    override func viewDidLoad() {
        super.viewDidLoad()
        self.styleUI()
        self.styleNavigationBar()
        self.scheduleList()
    }
    
    override func viewWillAppear(_ animated: Bool) {
        super.viewWillAppear(true)
        self.navigationController?.isNavigationBarHidden = false
    }
    
    func styleUI()
    {
        self.myTableView.tableFooterView = UIView()
        self.myTableView.separatorStyle = .none
        
        self.scheduleListTableView.tableFooterView = UIView()
        self.scheduleListTableView.separatorStyle = .none
        self.scheduleListTableView.delegate = self
        self.scheduleListTableView.dataSource = self
        self.scheduleListTableView.emptyDataSetSource = self
        self.scheduleListTableView.emptyDataSetDelegate = self
        self.myTableView.emptyDataSetSource = self
        self.myTableView.emptyDataSetDelegate = self
      
        DecorateControls.styleLabel(label: labelDate, text: "Date :", font: UIFont.boldSystemFont(ofSize: FONT_SIZE_18), textColor: blackColor())
        DecorateControls.styleLabel(label: labelSession, text: "Session :", font: UIFont.boldSystemFont(ofSize: FONT_SIZE_18), textColor: blackColor())
        DecorateControls.styleLabel(label: labelDuration, text: "Duration :", font: UIFont.boldSystemFont(ofSize: FONT_SIZE_18), textColor: blackColor())
        DecorateControls.styleLabel(label: labelPilate, text: "Pilate :", font: UIFont.boldSystemFont(ofSize: FONT_SIZE_18), textColor: blackColor())
        DecorateControls.styleLabel(label: labelTime, text: "Time :", font: UIFont.boldSystemFont(ofSize: FONT_SIZE_18), textColor: blackColor())

        self.myTableView.estimatedRowHeight = 55
        self.myTableView.rowHeight = UITableViewAutomaticDimension
        
        DecorateControls.styleLabel(label: myAppointmentLabel, text: "My Appointments", font: UIFont.boldSystemFont(ofSize: FONT_SIZE_20), textColor: whiteColor())
        myAppointmentLabel.backgroundColor = appColor()
        
        DecorateControls.styleLabel(label: scheduleListLabel, text: "Pilate Schedules", font: UIFont.boldSystemFont(ofSize: FONT_SIZE_20), textColor: whiteColor())
        scheduleListLabel.backgroundColor = appColor()
    }
    
    func styleNavigationBar()
    {
        if navigationController?.viewControllers.count == 1 {
            CommonUtility.createCustomBackButton(self, navBarItem: self.navigationItem, strImage: "menu_slide", select: #selector(doClickSideMenu))
        }
        else {
            CommonUtility.createCustomBackButton(self, navBarItem: self.navigationItem, strImage: "back_icon _white", select: #selector(openPopView))
        }
        
        CommonUtility.setNavBarTitle(self.navigationItem, title: NSLocalizedString("My Appointments", comment: "The title of the appointments navigation bar"))
        
        CommonUtility.createRightBarHomeButtons(target: self, navigationItem: self.navigationItem, select1: #selector(openProfileView), select2: #selector(openDashBoardView))
    }
    
    func scheduleList() {
        self.appointmentsViewModel.schedules_AppointmentsList { (response) in
            self.appointmentsViewModel.appointmentsListArray = response
            if ((self.appointmentsViewModel.appointmentsListArray?.result != nil) && (self.appointmentsViewModel.appointmentsListArray?.result.appointments.count != 0)) {
                self.myTableView.reloadData()
                self.scheduleListTableView.reloadData()
                let indexPath = IndexPath(row: 0, section: 0)
                self.populatePilateInfo(indexPath: indexPath)
            }else if ((self.appointmentsViewModel.appointmentsListArray?.result != nil) && (self.appointmentsViewModel.appointmentsListArray?.result.schedules.count != 0)) {
                self.myTableView.reloadData()
                self.scheduleListTableView.reloadData()
            }
        }
    }
    
    //MARK: - Navigation Bar Methods
    @objc func openPopView () {
        self.navigationController?.popViewController(animated: true)
    }
    @objc func doClickSideMenu()
    {
        panel?.openLeft(animated: true)
    }
    
    @objc func openProfileView()
    {
    self.navigationController?.pushViewController((self.storyboard?.instantiateViewController(withIdentifier: "ProfileViewController"))!, animated: true)
    }
    
    @objc func openNotificationsView()
    {
        self.navigationController?.pushViewController((self.storyboard?.instantiateViewController(withIdentifier: "NotificationsViewController"))!, animated: true)
    }
    
    @objc func openDashBoardView()
    {
        CommonUtility.setMenuSelectedOption(menuOptionIndex: 0)
        let centerVC : UIViewController
        let storyboard =  UIStoryboard(name: "Main", bundle: nil)
        centerVC = storyboard.instantiateViewController(withIdentifier: "DashboardViewController")
        let centerNavVC = UINavigationController(rootViewController: centerVC)
        self.panel?.configs.centerPanelTransitionType = .moveLeft
        self.panel?.configs.centerPanelTransitionDuration = 1.0
        _ = panel?.center(centerNavVC)
    }
    
    @objc func openSettingsView()
    {
        self.navigationController?.pushViewController((self.storyboard?.instantiateViewController(withIdentifier: "SettingsViewController"))!, animated: true)
    }
    
    @IBAction func addAppointment(sender : UIButton)
    {
        self.navigationController?.pushViewController((self.storyboard?.instantiateViewController(withIdentifier: "AddAppointmentViewController"))!, animated: true)
    }
}

extension AppointmentsViewController: UITableViewDataSource {
    func tableView(_ tableView: UITableView, cellForRowAt indexPath: IndexPath) -> UITableViewCell {
        if tableView == myTableView {
            let cell = myTableView.dequeueReusableCell(withIdentifier: "cell") as! AppointmentsTableViewCell
            cell.lblTitle.text = self.appointmentsViewModel.appointmentsListArray?.result.appointments[indexPath.section].time_details[indexPath.row].title
            cell.lblTime?.text = "\(CommonUtility.changeDateFormateOfDate(obj: (self.appointmentsViewModel.appointmentsListArray?.result.appointments[indexPath.section].time_details[indexPath.row].start_time)!, oldFormate: "HH:mm:ss", newFormate: "hh:mm a")) - \(CommonUtility.changeDateFormateOfDate(obj: (self.appointmentsViewModel.appointmentsListArray?.result.appointments[indexPath.section].time_details[indexPath.row].end_time)!, oldFormate: "HH:mm:ss", newFormate: "hh:mm a"))"
            cell.selectionStyle = .none
            cell.selectionStyle = .none
            return cell
        }else {
            let cell = self.scheduleListTableView.dequeueReusableCell(withIdentifier: "cellSchedule") as! AppointmentsTableViewCell
            cell.selectionStyle = .none
            cell.lblTitle.text = self.appointmentsViewModel.appointmentsListArray?.result.schedules[indexPath.section].time_details[indexPath.row].title
            
            cell.lblTime?.text = "\(CommonUtility.changeDateFormateOfDate(obj: (self.appointmentsViewModel.appointmentsListArray?.result.schedules[indexPath.section].time_details[indexPath.row].start_time)!, oldFormate: "HH:mm:ss", newFormate: "hh:mm a")) - \(CommonUtility.changeDateFormateOfDate(obj: (self.appointmentsViewModel.appointmentsListArray?.result.schedules[indexPath.section].time_details[indexPath.row].end_time)!, oldFormate: "HH:mm:ss", newFormate: "hh:mm a"))"

            
            cell.selectionStyle = .none
            cell.btnAddAppointment?.tag = indexPath.row
            cell.btnAddAppointment?.addTarget(self, action: #selector(bookAnAppointment(sender:)), for: .touchUpInside)
            return cell
        }
    }
    
    func tableView(_ tableView: UITableView, didSelectRowAt indexPath: IndexPath) {
            self.populatePilateInfo(indexPath: indexPath)
    }
    
    func populatePilateInfo(indexPath: IndexPath) {
        let scheduleInfo = self.appointmentsViewModel.appointmentsListArray?.result.appointments[indexPath.section].time_details[indexPath.row]
        
        let doctorInfo = self.appointmentsViewModel.appointmentsListArray?.result.doctorList.filter({$0.id == scheduleInfo?.doctor_id})
        
        DecorateControls.styleLabel(label: todayLabel, text: CommonUtility.doGetKeyForHeader(strDate: CommonUtility.changeDateFormateOfDate(obj: (scheduleInfo?.date)!, oldFormate: "yyyy-MM-dd", newFormate: "dd-MM-yyyy")) , font: UIFont.boldSystemFont(ofSize: FONT_SIZE_20), textColor: blackColor())
        
        DecorateControls.styleLabel(label: dateValue, text:CommonUtility.changeDateFormateOfDate(obj: (scheduleInfo?.date)!, oldFormate: "yyyy-MM-dd", newFormate: "dd-MM-yyyy") , font: UIFont.boldSystemFont(ofSize: FONT_SIZE_18), textColor: color(red: 172, green: 172, blue: 172))
        
        DecorateControls.styleLabel(label: sessionValue, text: scheduleInfo?.title, font: UIFont.boldSystemFont(ofSize: FONT_SIZE_18), textColor: color(red: 172, green: 172, blue: 172))
    
        DecorateControls.styleLabel(label: durationValue, text: "\(CommonUtility.timeDifferenceInMinutes(time1: CommonUtility.changeDateFormateOfDate(obj: (scheduleInfo?.start_time)!, oldFormate: "HH:mm:ss", newFormate: "HH:mm"), time2: CommonUtility.changeDateFormateOfDate(obj: (scheduleInfo?.end_time)!, oldFormate: "HH:mm:ss", newFormate: "HH:mm")))minutes", font: UIFont.boldSystemFont(ofSize: FONT_SIZE_18), textColor: color(red: 172, green: 172, blue: 172))
        
        if (doctorInfo?.count)! > 0 {
            DecorateControls.styleLabel(label: pilateValue, text: doctorInfo![0].username, font: UIFont.boldSystemFont(ofSize: FONT_SIZE_18), textColor: color(red: 172, green: 172, blue: 172))
        }
        
        DecorateControls.styleLabel(label: timeValue, text: CommonUtility.changeDateFormateOfDate(obj: (scheduleInfo?.start_time)!, oldFormate: "HH:mm:ss", newFormate: "hh:mm a"), font: UIFont.boldSystemFont(ofSize: FONT_SIZE_18), textColor: color(red: 172, green: 172, blue: 172))
    }
    
    func numberOfSections(in tableView: UITableView) -> Int {
        
        if self.appointmentsViewModel.appointmentsListArray == nil {
            return 0
        }
        if tableView == self.myTableView {
            return (self.appointmentsViewModel.appointmentsListArray?.result.appointments.count)!
        }
        return (self.appointmentsViewModel.appointmentsListArray?.result.schedules.count)!
    }
    
    func tableView(_ tableView: UITableView, numberOfRowsInSection section: Int) -> Int {
        if tableView == self.myTableView {
            return (self.appointmentsViewModel.appointmentsListArray?.result.appointments[section].time_details.count)!
        }
        else
        {
            return (self.appointmentsViewModel.appointmentsListArray?.result.schedules[section].time_details.count)!
        }
    }
    
    @IBAction func bookAnAppointment(sender: UIButton) {
        guard let cell = sender.superview?.superview as? AppointmentsTableViewCell else {
            return // or fatalError() or whatever
        }
        
        let indexPath = self.scheduleListTableView.indexPath(for: cell)
        self.appointmentsViewModel.doctorId = self.appointmentsViewModel.appointmentsListArray?.result.schedules[(indexPath?.section)!].time_details[(indexPath?.row)!].doctor_id
        self.appointmentsViewModel.scheduleId = self.appointmentsViewModel.appointmentsListArray?.result.schedules[(indexPath?.section)!].time_details[(indexPath?.row)!].id

        self.appointmentsViewModel.addAppointments {
            self.scheduleList()
        }
    }
}

extension AppointmentsViewController: UITableViewDelegate{
    func tableView(_ tableView: UITableView, viewForHeaderInSection section: Int) -> UIView? {
        let cell = myTableView.dequeueReusableCell(withIdentifier: "cell") as! AppointmentsTableViewCell
        if tableView == self.myTableView {
            DecorateControls.styleLabel(label: cell.lblTitle, text: CommonUtility.changeDateFormateOfDate(obj: (self.appointmentsViewModel.appointmentsListArray?.result.appointments[section].date)!, oldFormate: "yyyy-MM-dd", newFormate: "dd-MM-yyyy") , font: UIFont.boldSystemFont(ofSize: FONT_SIZE_16), textColor: blackColor())
        }else {
            DecorateControls.styleLabel(label: cell.lblTitle, text: CommonUtility.changeDateFormateOfDate(obj: (self.appointmentsViewModel.appointmentsListArray?.result.schedules[section].date)!, oldFormate: "yyyy-MM-dd", newFormate: "dd-MM-yyyy") , font: UIFont.boldSystemFont(ofSize: FONT_SIZE_16), textColor: blackColor())
        }
        return cell
    }
    
    func tableView(_ tableView: UITableView, heightForRowAt indexPath: IndexPath) -> CGFloat {
        return UITableViewAutomaticDimension
    }
    func tableView(_ tableView: UITableView, heightForHeaderInSection section: Int) -> CGFloat {
        return 40
    }
}

extension AppointmentsViewController: EmptyDataSetSource, EmptyDataSetDelegate {
    func title(forEmptyDataSet scrollView: UIScrollView) -> NSAttributedString? {
        return CommonUtility.dzEmptySetTitle(title: NSLocalizedString("title.error.nodata", comment: "This string shows when there is no data found."))
    }
    
    func buttonTitle(forEmptyDataSet scrollView: UIScrollView, for state: UIControlState) -> NSAttributedString? {
        return CommonUtility.dzEmptySetButtonTitle(title: NSLocalizedString("title.retry", comment: "This gives the option for retry when there is no data."))
    }
    
    func emptyDataSet(_ scrollView: UIScrollView, didTapButton button: UIButton) {
        //   self.getClientsList()
    }
    func emptyDataSetShouldDisplay(_ scrollView: UIScrollView) -> Bool {
        
        return true
    }
}

