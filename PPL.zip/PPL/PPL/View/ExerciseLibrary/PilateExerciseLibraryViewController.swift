 //
//  PilateExerciseLibraryViewController.swift
//  PPL
//
//  Created by PankajPurohit on 30/05/18.
//  Copyright © 2018 cdn. All rights reserved.
//

import UIKit
import MobileCoreServices
import SDWebImage
import EmptyDataSet_Swift
import AVFoundation

class PilateExerciseLibraryViewController: UIViewController ,UICollectionViewDelegate,UICollectionViewDataSource,UICollectionViewDelegateFlowLayout,LabelValueDelegate{
   
    @IBOutlet weak var btnAddVdeo: UIButton!
    @IBOutlet weak var imgSeprtrView3Btnss: UIImageView!
    @IBOutlet weak var imgSprtrView3btns: UIImageView!
    @IBOutlet weak var viewTwoBtn: UIView!
    @IBOutlet weak var viewThreeBtn: UIView!
    @IBOutlet weak var btnAll: UIButton!
    @IBOutlet weak var btnUnlocked: UIButton!
    @IBOutlet weak var btnImage: UIButton!
    @IBOutlet weak var btnVideo: UIButton!
    @IBOutlet weak var btnPaid: UIButton!
    @IBOutlet weak var collectionViewLibrary: UICollectionView!
    
    var imagePickerController1 = UIImagePickerController()
    var imagePickerController2 = UIImagePickerController()
    var videoURL : NSURL?
    var exerciseImageModel = PilateExerciseLibraryViewModel()
    var exerciseVideoViewModel = PilateExerciseVideoViewModel()
    var strFrom : String = ""
    var strPatientId : String = ""
    var strPatientName : String = ""
    var strVideoId : String = ""
    var strImageId : String = ""
    var isVideo : Bool?
   
    let btnAttributes : [NSAttributedStringKey: Any] = [
        NSAttributedStringKey.font : UIFont.systemFont(ofSize: 15),
        NSAttributedStringKey.foregroundColor : UIColor.black,
        NSAttributedStringKey.underlineStyle : NSUnderlineStyle.styleSingle.rawValue]
  
    override func viewDidLoad() {
        super.viewDidLoad()
        self.styleUI()
        self.styleNavigationBar()
        self.getLibraryList()
    }
    override func viewWillAppear(_ animated: Bool) {
        super.viewWillAppear(true)
        self.navigationController?.isNavigationBarHidden = false
    }
    
    
    func styleUI() {
        collectionViewLibrary.delegate = self
        collectionViewLibrary.dataSource = self
        
        collectionViewLibrary.emptyDataSetSource = self
        collectionViewLibrary.emptyDataSetDelegate = self
        self.btnAddVdeo.isHidden = false
         if self.strFrom == "SendProgram" {
            self.btnAddVdeo.isHidden = true
        }
         else {
            self.btnAddVdeo.isHidden = false
        }
        self.btnVideo.setImage(#imageLiteral(resourceName: "videoOption_Unslected"), for: .normal)
        self.btnVideo.setImage(#imageLiteral(resourceName: "videoOption_Selected"), for: .selected)
        self.viewTwoBtn.layer.cornerRadius = 5
        
        self.viewTwoBtn.clipsToBounds = true
        self.viewTwoBtn.layer.borderWidth = 1
        self.viewTwoBtn.layer.borderColor = UIColor.init(red: 226/255.0, green: 193/255.0, blue: 68/255.0, alpha: 1).cgColor
        
        btnImage.setImage(#imageLiteral(resourceName: "imageOption_Unselected"), for: .normal)
        btnImage.setImage(#imageLiteral(resourceName: "imageOption_Selected"), for: .selected)
        DecorateControls.putTitle(button: btnVideo, text: "  Video", font: UIFont.systemFont(ofSize: FONT_SIZE_19), textColor: whiteColor(), backGroundColor: appColor())
        DecorateControls.putTitle(button: btnImage, text: "  Image", font: UIFont.systemFont(ofSize: FONT_SIZE_19), textColor: blackColor(), backGroundColor: whiteColor())
        DecorateControls.putTitle(button: btnAll, text: "All", font: UIFont.systemFont(ofSize: FONT_SIZE_19), textColor: whiteColor(), backGroundColor: appColor())
        DecorateControls.putTitle(button: btnUnlocked, text: "Unlocked", font: UIFont.systemFont(ofSize: FONT_SIZE_19), textColor: blackColor(), backGroundColor: whiteColor())
        DecorateControls.putTitle(button: btnPaid, text: "Paid", font: UIFont.systemFont(ofSize: FONT_SIZE_19), textColor: blackColor(), backGroundColor: whiteColor())
        
        self.viewThreeBtn.layer.cornerRadius = 5
        
        self.viewThreeBtn.clipsToBounds = true
        self.viewThreeBtn.layer.borderWidth = 1
        self.viewThreeBtn.layer.borderColor = UIColor.init(red: 226/255.0, green: 193/255.0, blue: 68/255.0, alpha: 1).cgColor
        self.imgSprtrView3btns.backgroundColor = UIColor.init(red: 226/255.0, green: 193/255.0, blue: 68/255.0, alpha: 1)
        
        self.imgSeprtrView3Btnss.backgroundColor = UIColor.init(red: 226/255.0, green: 193/255.0, blue: 68/255.0, alpha: 1)
        self.clickDisplayOptions(sender: self.btnVideo)
    }
    
    func styleNavigationBar()
    {
        if navigationController?.viewControllers.count == 1 {
            CommonUtility.createCustomBackButton(self, navBarItem: self.navigationItem, strImage: "menu_slide", select: #selector(doClickSideMenu))
        }
        else {
            CommonUtility.createCustomBackButton(self, navBarItem: self.navigationItem, strImage: "back_icon _white", select: #selector(openPopView))
        }
        if self.strFrom == "SendProgram" {
        CommonUtility.setNavBarTitle(self.navigationItem, title: NSLocalizedString("Assign Program", comment: "The title of the Library navigation bar"))
        }
        else {
            CommonUtility.setNavBarTitle(self.navigationItem, title: NSLocalizedString("My Exercise", comment: "The title of the Library navigation bar"))
        }
        CommonUtility.createRightBarHomeButtons(target: self, navigationItem: self.navigationItem, select1: #selector(openProfileView), select2: #selector(openDashBoardView))
    }
    
    //MARK: - Navigation Bar Methods
    
    @objc func openPopView() {
    self.navigationController?.popViewController(animated: true)
    }
    
    @objc func doClickSideMenu()
    {
        panel?.openLeft(animated: true)
    }
    
    @objc func openProfileView()
    {
    self.navigationController?.pushViewController((self.storyboard?.instantiateViewController(withIdentifier: "DoctorProfileViewController"))!, animated: true)
    }
    
    @objc func openDashBoardView()
    {
        CommonUtility.setMenuSelectedOption(menuOptionIndex: 0)
        let centerVC : UIViewController
        let storyboard =  UIStoryboard(name: "Pilates", bundle: nil)
        centerVC = storyboard.instantiateViewController(withIdentifier: "PilatesDashboardViewController")
        let centerNavVC = UINavigationController(rootViewController: centerVC)
        self.panel?.configs.centerPanelTransitionType = .moveLeft
        self.panel?.configs.centerPanelTransitionDuration = 1.0
        _ = panel?.center(centerNavVC)
    }
    
    func collectionView(_ collectionView: UICollectionView, numberOfItemsInSection section: Int) -> Int {
        if self.btnVideo.isSelected{
            if let vModel = self.exerciseVideoViewModel.videoModel {
                return (vModel.result.count)
            }
            return 0;
        } else {
            return (self.exerciseImageModel.imagesUploadData?.result.count)!
        }
    }
    
    func collectionView(_ collectionView: UICollectionView, cellForItemAt indexPath: IndexPath) -> UICollectionViewCell {
        
        if self.btnVideo.isSelected == true {
         
            let cell = collectionView.dequeueReusableCell(withReuseIdentifier: "cell2", for: indexPath) as! ExerciseLibraryCollectionViewCell
            cell.btnPlayed.isEnabled = false
            cell.imageVC.clipsToBounds = true
            let url = URL(string: (self.exerciseVideoViewModel.videoModel?.result[indexPath.row].video_file)!)
            
            cell.lblVideoName.text = (self.exerciseVideoViewModel.videoModel?.result[indexPath.row].title)!

            cell.imageVC.image = #imageLiteral(resourceName: "no-inage")
//            if let thumbnailImage = getThumbnailImage(forUrl: url!) {
//                cell.imageVC.image = thumbnailImage
//            }
            if ((indexPath.row % 2) == 0) {
                cell.self.btnPlayed.setImage(UIImage.init(named: "locked_icon"), for: .normal)
            }else {
                cell.self.btnPlayed.setImage(UIImage.init(named: "play_icon"), for: .normal)
            }
            return cell
        }else {
            let cell = collectionView.dequeueReusableCell(withReuseIdentifier: "cell1", for: indexPath) as!
            ExerciseLibraryCollectionViewCell
          
            self.viewThreeBtn.isHidden = true
            cell.imageVC.sd_addActivityIndicator()
            cell.imageVC.sd_showActivityIndicatorView()
            cell.imageVC.clipsToBounds = true
            cell.imageVC.sd_setImage(with: URL(string: (self.exerciseImageModel.imagesUploadData?.result[indexPath.row].image_file)!), placeholderImage: #imageLiteral(resourceName: "no-inage"))
            cell.lblImageName.text = (self.exerciseImageModel.imagesUploadData?.result[indexPath.row].title)!
        
            return cell
        }
    }
    
    func collectionView(_ collectionView: UICollectionView, layout collectionViewLayout: UICollectionViewLayout, sizeForItemAt indexPath: IndexPath) -> CGSize {
        
        if self.btnVideo.isSelected == true
        {
            let cellWidth = (collectionView.bounds.width/6.0) - 7.50
            let cellHeight = (collectionView.bounds.height/4.0)
            
            return CGSize(width: cellWidth , height: cellHeight)
        }
        else {
            let cellWidth = (collectionView.bounds.width/6.0) - 7.50
            let cellHeight = (collectionView.bounds.height/4.0)
            
            return CGSize(width: cellWidth , height: cellHeight)
        }
    }
    
    func collectionView(_ collectionView: UICollectionView, layout collectionViewLayout: UICollectionViewLayout, insetForSectionAt section: Int) -> UIEdgeInsets {
        return UIEdgeInsets.zero
    }
    
    func collectionView(_ collectionView: UICollectionView, layout collectionViewLayout: UICollectionViewLayout, minimumInteritemSpacingForSectionAt section: Int) -> CGFloat {
        return 0
    }
    
    func collectionView(_ collectionView: UICollectionView, layout collectionViewLayout: UICollectionViewLayout, minimumLineSpacingForSectionAt section: Int) -> CGFloat {
        return 15
    }
    
    func collectionView(_ collectionView: UICollectionView, didSelectItemAt indexPath: IndexPath) {
        if self.btnVideo.isSelected {
            if self.strFrom == "SendProgram" {
                strVideoId = (self.exerciseVideoViewModel.videoModel?.result[indexPath.row].id)!
                let popupViewCtrl = self.storyboard?.instantiateViewController(withIdentifier: "VideoAssignedPopViewController") as! VideoAssignedPopViewController
                popupViewCtrl.delegate = self
                popupViewCtrl.username = strPatientName
                 popupViewCtrl.isVideo = isVideo
                let window = UIApplication.shared.keyWindow
                window?.addSubview(popupViewCtrl.view)
                self.addChildViewController(popupViewCtrl)
            }else{
                let pushVc = self.storyboard?.instantiateViewController(withIdentifier:
                "PilateExerciseVideoViewController") as! PilateExerciseVideoViewController
                pushVc.selectURL = (self.exerciseVideoViewModel.videoModel?.result[indexPath.row].video_file)!
                let url = URL(string: (self.exerciseVideoViewModel.videoModel?.result[indexPath.row].video_file)!)
                pushVc.thumbnailImg = getThumbnailImage(forUrl: url!)!
                
                self.navigationController?.pushViewController(pushVc, animated: true)
             
            }
        } else {
            if self.strFrom == "SendProgram" {
                strImageId = (self.exerciseImageModel.imagesUploadData?.result[indexPath.row].id)!
                let popupViewCtrl = self.storyboard?.instantiateViewController(withIdentifier: "VideoAssignedPopViewController") as! VideoAssignedPopViewController
                popupViewCtrl.delegate = self
                 popupViewCtrl.username = strPatientName
                popupViewCtrl.isVideo = isVideo
                let window = UIApplication.shared.keyWindow
                window?.addSubview(popupViewCtrl.view)
                self.addChildViewController(popupViewCtrl)
            }else{
                let pushVc = self.storyboard?.instantiateViewController(withIdentifier:"PilateGalleryViewController") as! PilateGalleryViewController
             
                pushVc.imagegallery = (self.exerciseImageModel.imagesUploadData?.result)!
                pushVc.indexGallery = indexPath.row
                self.navigationController?.pushViewController(pushVc, animated: true)
            }
        }
    }
    
    func didOkPressButton() {
        if self.btnVideo.isSelected == true {
            self.doCallAssignImageVideo(assignId: strVideoId)
        }else {
            self.doCallAssignImageVideo(assignId: strImageId)
        }
    }
    
    func doCallAssignImageVideo(assignId:String){
        let apiManager = APIManager()
        var parameters = [String : Any]()
        parameters["patient_id"] = self.strPatientId
        parameters["video_image_id"] = assignId
        if self.btnVideo.isSelected {
            parameters["assign_type"] = 1
        }else{
            parameters["assign_type"] = 2
        }
        apiManager.assignImageVideo(parameters: parameters, completion: { (response) in
            let resultCode = response["result_code"] as! Bool
            if resultCode {
                if self.btnVideo.isSelected {
                    CommonUtility.showSuccessCRNotifications(title: "Success!!", message: NSLocalizedString("title.success.assign.video", comment: "This message shown after assigning video successfuly"))
                }else{
                    CommonUtility.showSuccessCRNotifications(title: "Success!!", message: NSLocalizedString("title.success.assign.image", comment: "This message shown after assigning image successfuly"))
                }
                
            }else {
                CommonUtility.showErrorCRNotifications(title: appTitle(), message: response["message"] as! String)
            }
        }) { (error) in
            CommonUtility.showErrorCRNotifications(title: "Error!", message: (error?.localizedDescription)!)
        }
    }
    
    @IBAction func btnImageActn(_ sender: UIButton) {
        self.btnVideo.backgroundColor = UIColor.clear
        btnImage.backgroundColor = UIColor.init(red: 226/255.0, green: 193/255.0, blue: 68/255.0, alpha: 1)
    }
    
    func getImages() {
        self.exerciseImageModel.getImageList { (imagesList) in
            self.exerciseImageModel.imagesUploadData = imagesList
            self.collectionViewLibrary.reloadData()
        }
    }
    
    func getVideos() {
        self.exerciseVideoViewModel.getVideoList { (videoList) in
            self.exerciseVideoViewModel.videoModel = videoList
            self.collectionViewLibrary.reloadData()
        }
    }
    
    func getThumbnailImage(forUrl url: URL) -> UIImage? {
        let asset: AVAsset = AVAsset(url: url)
        let imageGenerator = AVAssetImageGenerator(asset: asset)
        
        do {
            let thumbnailImage = try imageGenerator.copyCGImage(at: CMTimeMake(1, 60) , actualTime: nil)
            return UIImage(cgImage: thumbnailImage)
        } catch let error {
            print(error)
        }
        return nil
    }
    
    @IBAction func btnVideoActn(_ sender: UIButton) {
//        if self.btnVideo.isSelected == true {
//            collectionViewLibrary.reloadData()
//        }
    }
    
    @IBAction func clickDisplayOptions(sender  : UIButton){
        self.btnImage.isSelected = false
        self.btnVideo.isSelected = false
        self.viewThreeBtn.isHidden = true
        sender.isSelected = true
        colorTwoButton()
        if self.btnImage.isSelected {
            isVideo = false
            let attributeString = NSMutableAttributedString(string: "Add Image",attributes: btnAttributes)
            btnAddVdeo.setAttributedTitle(attributeString, for: .normal)
            if self.exerciseImageModel.imagesUploadData != nil
            {
                collectionViewLibrary.reloadData()
            }else {
            self.getImages()
     }
        } else {
            isVideo = true
            let attributeString = NSMutableAttributedString(string: "Add Video",attributes: btnAttributes)
            btnAddVdeo.setAttributedTitle(attributeString, for: .normal)
            if self.exerciseVideoViewModel.videoModel != nil {
                collectionViewLibrary.reloadData()
            }else{
                self.getVideos()
            }
        }
    }
    
    @IBAction func clickSubDisplayOptions(_ sender: UIButton) {
        self.btnAll.isSelected = false
        self.btnPaid.isSelected = false
        self.btnUnlocked.isSelected = false
        sender.isSelected = true
        colorThreeButton()
        self.collectionViewLibrary.reloadData()
    }
    
    func colorTwoButton() {
        self.btnImage.backgroundColor = UIColor.clear
        self.btnVideo.backgroundColor = UIColor.clear
        self.btnImage.setTitleColor(UIColor.black, for: .normal)
        self.btnVideo.setTitleColor(UIColor.black, for: .normal)
        self.btnVideo.setImage(UIImage.init(named: "videoOption_Unslected"), for: .normal)
        self.btnImage.setImage(UIImage.init(named: "imageOption_Unselected"), for: .normal)
        if self.btnVideo.isSelected == true {
            self.btnVideo.setTitleColor(UIColor.white, for: .normal)
            self.btnVideo.backgroundColor = UIColor.init(red: 226/255.0, green: 193/255.0, blue: 68/255.0, alpha: 1)
        }else {
            btnImage.setTitleColor(UIColor.white, for: .normal)
            btnImage.backgroundColor = UIColor.init(red: 226/255.0, green: 193/255.0, blue: 68/255.0, alpha: 1)
        }
    }
    
    func colorThreeButton() {
        
        self.btnPaid.backgroundColor = UIColor.clear
        self.btnUnlocked.backgroundColor = UIColor.clear
        self.btnAll.backgroundColor = UIColor.clear
        self.btnUnlocked.setTitleColor(UIColor.black, for: .normal)
        self.btnAll.setTitleColor(UIColor.black, for: .normal)
        self.btnPaid.setTitleColor(UIColor.black, for: .normal)
        
        if self.btnAll.isSelected == true{
            btnAll.setTitleColor(UIColor.white, for: .normal)
            btnAll.backgroundColor = UIColor.init(red: 226/255.0, green: 193/255.0, blue: 68/255.0, alpha: 1)
        }else if self.btnUnlocked.isSelected == true{
            btnUnlocked.setTitleColor(UIColor.white, for: .normal)
            btnUnlocked.backgroundColor = UIColor.init(red: 226/255.0, green: 193/255.0, blue: 68/255.0, alpha: 1)
        }else {
            btnPaid.setTitleColor(UIColor.white, for: .normal)
            btnPaid.backgroundColor = UIColor.init(red: 226/255.0, green: 193/255.0, blue: 68/255.0, alpha: 1)
        }
    }
    
    @IBAction func btnPlayedActn(_ sender: UIButton) {
        let pushVc = self.storyboard?.instantiateViewController(withIdentifier: "ExerciseVideoViewController") as! ExerciseVideoViewController
        self.navigationController?.pushViewController(pushVc, animated: true)
    }
    
    /////////////  FETCHING VIDEO FROM GALLERY////////////
    @IBAction func addBtnAcftn(_ sender: UIButton) {
        let alert : UIAlertController?
        let gallaryAction : UIAlertAction
        if btnVideo.isSelected == true {
            alert = UIAlertController(title: "Choose Video", message: nil, preferredStyle: UIAlertControllerStyle.alert)
             gallaryAction = UIAlertAction(title: "Video Gallery", style: UIAlertActionStyle.default){
                UIAlertAction in
                self.openGallary()
            }
        } else {
            alert = UIAlertController(title: "Choose Image", message: nil, preferredStyle: UIAlertControllerStyle.alert)
             gallaryAction = UIAlertAction(title: "Image Gallery", style: UIAlertActionStyle.default){
                UIAlertAction in
                self.openGallary()
            }
        }
        
        let cameraAction = UIAlertAction(title: "Camera", style: UIAlertActionStyle.default){
            UIAlertAction in
            self.openCamera()
        }
        let cancelAction = UIAlertAction(title: "Cancel", style: UIAlertActionStyle.cancel){
            UIAlertAction in
        }
  
        alert?.addAction(cameraAction)
        alert?.addAction(gallaryAction)
        alert?.addAction(cancelAction)
        
        self.present(alert!, animated: true, completion: nil)
    }
    
    func openCamera() {
        if btnVideo.isSelected == true {
            if(UIImagePickerController .isSourceTypeAvailable(UIImagePickerControllerSourceType.camera)){
                imagePickerController1.sourceType = .camera
                imagePickerController1.mediaTypes = [kUTTypeMovie as NSString as String]
                imagePickerController1.cameraDevice = UIImagePickerControllerCameraDevice.rear
                imagePickerController1.allowsEditing = false
                imagePickerController1.delegate = self
                self .present(imagePickerController1, animated: true, completion: nil)
            }else{
                let alert = UIAlertController(title: "Warning", message: "You don't have camera", preferredStyle: UIAlertControllerStyle.alert)
                alert.addAction(UIAlertAction(title: "Ok", style: UIAlertActionStyle.default, handler: nil))
                self.present(alert, animated: true, completion: nil)
            }
        } else {
            
            if(UIImagePickerController .isSourceTypeAvailable(UIImagePickerControllerSourceType.camera)) {
                imagePickerController1.sourceType = .camera
                imagePickerController1.mediaTypes = [kUTTypeImage as String]
                imagePickerController1.delegate = self
                self .present(imagePickerController1, animated: true, completion: nil)
            }else{
                let alert = UIAlertController(title: "Warning", message: "You don't have camera", preferredStyle: UIAlertControllerStyle.alert)
                alert.addAction(UIAlertAction(title: "Ok", style: UIAlertActionStyle.default, handler: nil))
                self.present(alert, animated: true, completion: nil)
            }
        }
    }
    
    func openGallary(){
        if btnVideo.isSelected == true {
            imagePickerController1.sourceType = .savedPhotosAlbum
            imagePickerController1.delegate = self
            imagePickerController1.mediaTypes = [kUTTypeMovie as NSString as String]
            self.present(imagePickerController1, animated: true, completion: nil)
        }else {
            imagePickerController2.sourceType = .savedPhotosAlbum
            imagePickerController2.delegate = self
            present(imagePickerController2, animated: true, completion: nil)
        }
    }
    
    func getLibraryList() {
        collectionViewLibrary.reloadData()
    }
}

extension PilateExerciseLibraryViewController : UIImagePickerControllerDelegate, UINavigationControllerDelegate {
    
    
    func imagePickerController(_ picker: UIImagePickerController, didFinishPickingMediaWithInfo info: [String : Any]) {
        if btnVideo.isSelected == true {
            videoURL = info[UIImagePickerControllerMediaURL] as? URL as NSURL?
            
            let alert = UIAlertController(title: "Add Video", message: "Enter Video name", preferredStyle: .alert)
            
            self.dismiss(animated: true, completion: {
                
                alert.addAction(UIAlertAction(title: "OK", style: .default, handler: { [weak alert] (_) in
                    let textField = alert?.textFields![0]
                    
                    let videoFileURL = self.videoURL?.filePathURL
                    
                    let videoPath = videoFileURL?.path
                    let contents: NSData?
                    do {
                        self.exerciseImageModel.filesData.removeAll()
                        contents = try NSData(contentsOfFile: videoPath!, options: NSData.ReadingOptions.alwaysMapped)
                        self.exerciseImageModel.title = textField?.text
                        self.exerciseImageModel.filesData.append(contents! as Data)
                        self.exerciseImageModel.uploadVideos(completion: { (response) in
                            self.exerciseVideoViewModel.videoModel?.result.append(response.result[0])
                            self.collectionViewLibrary.reloadData()
                        }, failure: { (error) in
                        })
                    } catch _ {
                        contents = nil
                    }
                }))
                
                alert.addAction(UIAlertAction(title : "Cancel", style : .cancel))
                
                alert.actions[0].isEnabled = false
                
                alert.addTextField { tf in
                    tf.addTarget(self, action: #selector(self.textChanged(_:)), for: .editingChanged)
                }
                self.present(alert, animated: true, completion: nil)
            } )
        }else {
            let chosenImage = info[UIImagePickerControllerOriginalImage] as! UIImage
            let selectedImage : UIImage = chosenImage
            let alert = UIAlertController(title: "Add Image", message: "Enter Image name", preferredStyle: .alert)
            
            self.dismiss(animated: true, completion: {
                alert.addAction(UIAlertAction(title: "OK", style: .default, handler: { [weak alert] (_) in
                    let textField = alert?.textFields![0] // Force unwrapping because we know it exists.
                    print("Text field: \(textField?.text ?? "")")
                    
                    if textField?.text == "" {
                        return
                    }
                    self.exerciseImageModel.title = textField?.text
                    let imgData = UIImageJPEGRepresentation(selectedImage, 0.2)!
                    self.exerciseImageModel.filesData.removeAll()
                    self.exerciseImageModel.filesData.append(imgData)
                    print("caled image uploaded")
                    print(self.exerciseImageModel.filesData.count)
                    self.exerciseImageModel.uploadImages(completion: { (response) in
                        self.exerciseImageModel.imagesUploadData?.result.append(response.result[0])
                        self.collectionViewLibrary.reloadData()
                    }, failure: { (error) in
                    })
                }))
                alert.addAction(UIAlertAction(title : "Cancel", style : .cancel))
                
                alert.actions[0].isEnabled = false
                
                alert.addTextField { tf in
                    tf.addTarget(self, action: #selector(self.textChanged(_:)), for: .editingChanged)
                }
                self.present(alert, animated: true, completion: nil)
            } )
        }
    }
    
    @objc func textChanged(_ sender: Any) {
        let tf = sender as! UITextField
        var resp : UIResponder! = tf
        while !(resp is UIAlertController) { resp = resp.next }
        let alert = resp as! UIAlertController
        alert.actions[0].isEnabled = (tf.text != "")
    }
}
 
 //MARK: EmptyDataSource and Delegates
 extension PilateExerciseLibraryViewController: EmptyDataSetSource, EmptyDataSetDelegate {
    func title(forEmptyDataSet scrollView: UIScrollView) -> NSAttributedString? {
        return CommonUtility.dzEmptySetTitle(title: NSLocalizedString("title.error.nodata", comment: "This string shows when there is no data found."))
    }
    
    func emptyDataSetShouldDisplay(_ scrollView: UIScrollView) -> Bool {
        if self.btnVideo.isSelected{
            if let vModel = self.exerciseVideoViewModel.videoModel {
                return true
            }
            return false
        } else {
            return true
        }
    }
 }
