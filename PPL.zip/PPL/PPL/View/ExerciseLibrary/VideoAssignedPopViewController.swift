//
//  VideoAssignedPopViewController.swift
//  PPL
//
//  Created by TanjeetAjmani on 21/06/18.
//  Copyright © 2018 cdn. All rights reserved.
//

import UIKit
protocol LabelValueDelegate {
    func didOkPressButton()
}

class VideoAssignedPopViewController: UIViewController {

    @IBOutlet weak var btnCancel: UIButton!
    @IBOutlet weak var btnOk: UIButton!
    @IBOutlet weak var lblAssigned: UILabel!
    @IBOutlet weak var lblHeader: UILabel!
    @IBOutlet weak var viewPopUp: UIView!
    var username = ""
    var isVideo : Bool?
    var delegate : LabelValueDelegate? = nil
    
    override func viewDidLoad() {
       super.viewDidLoad()
     self.styleUI()
     self.decorateUI()
  
    }
    func styleUI() {
        DecorateControls.styleLabel(label: lblHeader, text: "Patient Pilate", font: UIFont.systemFont(ofSize: FONT_SIZE_25), textColor: blackColor())
        if isVideo == true {
         DecorateControls.styleLabel(label: lblAssigned, text: "Are you sure do you want to assigned this video to \(username)", font: UIFont.systemFont(ofSize: FONT_SIZE_22), textColor: blackColor())
        }
        else {
            DecorateControls.styleLabel(label: lblAssigned, text: "Are you sure do you want to assigned this  image to \(username)", font: UIFont.systemFont(ofSize: FONT_SIZE_22), textColor: blackColor())
        }
        DecorateControls.putTitle(button: btnOk, text: "Ok", font: UIFont.systemFont(ofSize: FONT_SIZE_25), textColor: whiteColor(), backGroundColor: appColor())
        DecorateControls.putTitle(button: btnCancel, text: "Cancel", font: UIFont.systemFont(ofSize: FONT_SIZE_25), textColor: whiteColor(), backGroundColor: appColor())
        self.btnOk.layer.cornerRadius = 5
        self.btnCancel.layer.cornerRadius = 5

    }
    func decorateUI(){
        self.view.backgroundColor = UIColor.black.withAlphaComponent(0.6)
        self.viewPopUp.layer.cornerRadius = 7
        self.viewPopUp.layer.shadowOpacity = 0.8
        self.viewPopUp.layer.borderWidth = 1.0
        self.viewPopUp.layer.borderColor = UIColor.black.cgColor
        self.viewPopUp.clipsToBounds = true
        self.showAnimation()
    }
    
    func showAnimation(){
        self.view.alpha = 0
        self.viewPopUp.transform = CGAffineTransform(scaleX: 0.1, y: 0.1)
        UIView.animate(withDuration: 0.3) {
            self.viewPopUp.transform = CGAffineTransform(scaleX: 1.0, y: 1.0)
            self.view.alpha = 1
        }
    }
    
    func hideViewWithAnimation() {
        UIView.animate(withDuration: 0.3, animations: {
            self.viewPopUp.transform = CGAffineTransform(scaleX: 0.1, y: 0.1)
            self.view.alpha = 0
        }, completion: {
            (value: Bool) in
            self.removeFromParentViewController()
            self.view.removeFromSuperview()
        })
    }

    override func touchesBegan(_ touches: Set<UITouch>, with event: UIEvent?) {
        if let touch = touches.first {
            if touch.view == self.view {
                self.hideViewWithAnimation()
            }
        }
    }
    
    @IBAction func btnOkActn(_ sender: UIButton) {
        delegate?.didOkPressButton()
        self.hideViewWithAnimation()
    }
    
    @IBAction func btnCanclActn(_ sender: UIButton) {
      self.hideViewWithAnimation()
    }
}
