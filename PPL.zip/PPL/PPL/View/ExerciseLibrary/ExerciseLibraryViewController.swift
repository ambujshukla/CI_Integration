//
//  ViewController.swift
//  PilateLibrary
//
//  Created by TanjeetAjmani on 30/04/18.
//  Copyright © 2018 TanjeetAjmani. All rights reserved.
//

import UIKit
import EmptyDataSet_Swift


class ExerciseLibraryViewController: UIViewController ,UICollectionViewDelegate,UICollectionViewDataSource,UICollectionViewDelegateFlowLayout{
    
    @IBOutlet weak var imgSeprtrView3Btnss: UIImageView!
    @IBOutlet weak var imgSprtrView3btns: UIImageView!
    @IBOutlet weak var viewTwoBtn: UIView!
    @IBOutlet weak var viewThreeBtn: UIView!
    @IBOutlet weak var btnAll: UIButton!
    @IBOutlet weak var btnUnlocked: UIButton!
    @IBOutlet weak var btnImage: UIButton!
    @IBOutlet weak var btnVideo: UIButton!
    @IBOutlet weak var btnPaid: UIButton!
    @IBOutlet weak var collectionViewLibrary: UICollectionView!
    var patientLibraryViewModel = PatientLibraryListViewModel()
    var shouldShowNoData: Bool = false
    
    override func viewDidLoad() {
        super.viewDidLoad()
        self.styleUI()
        self.styleNavigationBar()
        self.patientLibraryViewModel.getExerciseList{ (response) in
             self.patientLibraryViewModel.exerciseData = response
            if self.patientLibraryViewModel.exerciseData == nil {
                self.shouldShowNoData = true
            }
            self.collectionViewLibrary.reloadData()
        }
    }
    override func viewWillAppear(_ animated: Bool) {
        super.viewWillAppear(true)
        self.navigationController?.isNavigationBarHidden = false
    }
    
    
    func styleUI() {
        collectionViewLibrary.delegate = self
        collectionViewLibrary.dataSource = self
        collectionViewLibrary.emptyDataSetSource = self
        collectionViewLibrary.emptyDataSetDelegate = self
        
        self.btnVideo.setImage(#imageLiteral(resourceName: "videoOption_Unslected"), for: .normal)
        self.btnVideo.setImage(#imageLiteral(resourceName: "videoOption_Selected"), for: .selected)
        
        
        DecorateControls.putTitle(button: btnVideo, text: "  Video", font: UIFont.systemFont(ofSize: FONT_SIZE_19), textColor: whiteColor(), backGroundColor: appColor())
        
        self.viewTwoBtn.layer.cornerRadius = 5
        
        self.viewTwoBtn.clipsToBounds = true
        self.viewTwoBtn.layer.borderWidth = 1
        self.viewTwoBtn.layer.borderColor = UIColor.init(red: 226/255.0, green: 193/255.0, blue: 68/255.0, alpha: 1).cgColor
        
        btnImage.setImage(#imageLiteral(resourceName: "imageOption_Unselected"), for: .normal)
        btnImage.setImage(#imageLiteral(resourceName: "imageOption_Selected"), for: .selected)
        DecorateControls.putTitle(button: btnImage, text: "  Image", font: UIFont.systemFont(ofSize: FONT_SIZE_19), textColor: blackColor(), backGroundColor: whiteColor())
        
        self.viewThreeBtn.layer.cornerRadius = 5
        
        self.viewThreeBtn.clipsToBounds = true
        self.viewThreeBtn.layer.borderWidth = 1
        self.viewThreeBtn.layer.borderColor = UIColor.init(red: 226/255.0, green: 193/255.0, blue: 68/255.0, alpha: 1).cgColor
        self.imgSprtrView3btns.backgroundColor = UIColor.init(red: 226/255.0, green: 193/255.0, blue: 68/255.0, alpha: 1)
        
        self.imgSeprtrView3Btnss.backgroundColor = UIColor.init(red: 226/255.0, green: 193/255.0, blue: 68/255.0, alpha: 1)
        
        DecorateControls.putTitle(button: btnAll, text: "All", font: UIFont.systemFont(ofSize: FONT_SIZE_19), textColor: whiteColor(), backGroundColor: appColor())
        DecorateControls.putTitle(button: btnUnlocked, text: "Unlocked", font: UIFont.systemFont(ofSize: FONT_SIZE_19), textColor: blackColor(), backGroundColor: whiteColor())
        DecorateControls.putTitle(button: btnPaid, text: "Paid", font: UIFont.systemFont(ofSize: FONT_SIZE_19), textColor: blackColor(), backGroundColor: whiteColor())
        
        self.clickDisplayOptions(sender: self.btnVideo)
    }
    
    func styleNavigationBar()
    {
        if navigationController?.viewControllers.count == 1 {
            CommonUtility.createCustomBackButton(self, navBarItem: self.navigationItem, strImage: "menu_slide", select: #selector(doClickSideMenu))
        }
        else {
            CommonUtility.createCustomBackButton(self, navBarItem: self.navigationItem, strImage: "back_icon _white", select: #selector(openPopView))
        }
        
        CommonUtility.setNavBarTitle(self.navigationItem, title: NSLocalizedString("My Exercise", comment: "The title of the Library navigation bar"))

        CommonUtility.createRightBarHomeButtons(target: self, navigationItem: self.navigationItem, select1: #selector(openProfileView), select2: #selector(openDashBoardView))
    }
    
    //MARK: - Navigation Bar Methods
    @objc func openPopView() {
        self.navigationController?.popViewController(animated: true)
    }
    
    @objc func doClickSideMenu()
    {
        panel?.openLeft(animated: true)
    }
    
    @objc func openDashBoardView()
    {
        CommonUtility.setMenuSelectedOption(menuOptionIndex: 0)
        let centerVC : UIViewController
        let storyboard =  UIStoryboard(name: "Main", bundle: nil)
        centerVC = storyboard.instantiateViewController(withIdentifier: "DashboardViewController")
        let centerNavVC = UINavigationController(rootViewController: centerVC)
        self.panel?.configs.centerPanelTransitionType = .moveLeft
        self.panel?.configs.centerPanelTransitionDuration = 1.0
        _ = panel?.center(centerNavVC)
    }
    
    @objc func openProfileView()
    {
   self.navigationController?.pushViewController((self.storyboard?.instantiateViewController(withIdentifier: "ProfileViewController"))!, animated: true)
      
    }
    
    func collectionView(_ collectionView: UICollectionView, numberOfItemsInSection section: Int) -> Int {
        if self.patientLibraryViewModel.exerciseData == nil {
            return 0
        }
        if self.btnVideo.isSelected{
            return (self.patientLibraryViewModel.exerciseData?.result.video.count)!
        }
        else {
            return (self.patientLibraryViewModel.exerciseData?.result.image.count)!
        }
    }
    
    func collectionView(_ collectionView: UICollectionView, cellForItemAt indexPath: IndexPath) -> UICollectionViewCell {
        
        if self.btnVideo.isSelected == true
        {
            let cell = collectionView.dequeueReusableCell(withReuseIdentifier: "cell2", for: indexPath) as! ExerciseLibraryCollectionViewCell
            
            
            self.viewThreeBtn.isHidden = false
            
            //            let url = URL(string: (self.exerciseVideoViewModel.videoModel?.result[indexPath.row].video_file)!)
         //   cell.lblVideoName.text = self.patientLibraryViewModel.exerciseData?.result.video[indexPath.row].title

            cell.btnPlayed.isEnabled = false
         //   let cellImage = imageData[indexPath.row]
            cell.imageVC.clipsToBounds = true
            cell.imageVC.image = #imageLiteral(resourceName: "no-inage")
            if ((indexPath.row % 2) == 0)
            {
                cell.self.btnPlayed.setImage(UIImage.init(named: "locked_icon"), for: .normal)
            }
            else
            {
                cell.self.btnPlayed.setImage(UIImage.init(named: "play_icon"), for: .normal)
            }
            return cell
        }
        else {
            let cell = collectionView.dequeueReusableCell(withReuseIdentifier: "cell1", for: indexPath) as!
            ExerciseLibraryCollectionViewCell
            self.viewThreeBtn.isHidden = true
            cell.imageVC.clipsToBounds = true
            cell.imageVC.sd_setImage(with: URL(string: (self.patientLibraryViewModel.exerciseData?.result.image[indexPath.row].image_file)!), placeholderImage: #imageLiteral(resourceName: "no-inage"))
            return cell
        }
    }
    
    //    func collectionView(_ collectionView: UICollectionView, didSelectItemAt indexPath: IndexPath) {
    //        self.navigationController?.pushViewController((self.storyboard?.instantiateViewController(withIdentifier: "ExerciseDetailViewController"))!, animated: true)
    //    }
    
    func collectionView(_ collectionView: UICollectionView, layout collectionViewLayout: UICollectionViewLayout, sizeForItemAt indexPath: IndexPath) -> CGSize {
        
        if self.btnVideo.isSelected == true
        {
            let cellWidth = (collectionView.bounds.width/6.0) - 7.50
            let cellHeight = (collectionView.bounds.height/4.0)
            
            return CGSize(width: cellWidth , height: cellHeight)
        }
        else {
            let cellWidth = (collectionView.bounds.width/6.0) - 7.50
            let cellHeight = (collectionView.bounds.height/4.0)
            
            return CGSize(width: cellWidth , height: cellHeight)
        }
    }
    
    func collectionView(_ collectionView: UICollectionView, layout collectionViewLayout: UICollectionViewLayout, insetForSectionAt section: Int) -> UIEdgeInsets {
        return UIEdgeInsets.zero
    }
    
    func collectionView(_ collectionView: UICollectionView, layout collectionViewLayout: UICollectionViewLayout, minimumInteritemSpacingForSectionAt section: Int) -> CGFloat {
        return 0
    }
    
    func collectionView(_ collectionView: UICollectionView, layout collectionViewLayout: UICollectionViewLayout, minimumLineSpacingForSectionAt section: Int) -> CGFloat {
        return 15
    }
    
    func collectionView(_ collectionView: UICollectionView, didSelectItemAt indexPath: IndexPath) {
        
        if self.btnVideo.isSelected {
            let pushVc = self.storyboard?.instantiateViewController(withIdentifier: "ExerciseVideoViewController") as! ExerciseVideoViewController
            self.navigationController?.pushViewController(pushVc, animated: true)
        }
        else {
            let storyBoard = UIStoryboard.init(name: "Pilates", bundle: nil)
            let pushVc = storyBoard.instantiateViewController(withIdentifier:"PilateGalleryViewController") as! PilateGalleryViewController
            
            pushVc.imagegallery = (self.patientLibraryViewModel.exerciseData?.result.image)!
            pushVc.indexGallery = indexPath.row
            self.navigationController?.pushViewController(pushVc, animated: true)
          //  let pushVc = self.storyboard?.instantiateViewController(withIdentifier: "GalleryViewController") as! GalleryViewController
          //  self.navigationController?.pushViewController(pushVc, animated: true)
        }
    }
    
    @IBAction func btnImageActn(_ sender: UIButton) {
        self.btnVideo.backgroundColor = UIColor.clear
        btnImage.backgroundColor = UIColor.init(red: 226/255.0, green: 193/255.0, blue: 68/255.0, alpha: 1)
        
        if btnImage.isSelected == true {
            
            collectionViewLibrary.reloadData()
        }
    }
    
    @IBAction func btnVideoActn(_ sender: UIButton) {
        
        if self.btnVideo.isSelected == true {
            
            collectionViewLibrary.reloadData()
        }
    }
    
    @IBAction func clickDisplayOptions(sender  : UIButton)
    {
        self.btnImage.isSelected = false
        self.btnVideo.isSelected = false
        
        sender.isSelected = true
        colorTwoButton()
        self.collectionViewLibrary.reloadData()
    }
    
    @IBAction func clickSubDisplayOptions(_ sender: UIButton) {
        self.btnAll.isSelected = false
        self.btnPaid.isSelected = false
        self.btnUnlocked.isSelected = false
        
        sender.isSelected = true
        colorThreeButton()
        self.collectionViewLibrary.reloadData()
        
    }
    
    func colorTwoButton() {
        
        self.btnImage.backgroundColor = UIColor.clear
        self.btnVideo.backgroundColor = UIColor.clear
        self.btnImage.setTitleColor(UIColor.black, for: .normal)
        self.btnVideo.setTitleColor(UIColor.black, for: .normal)
        self.btnVideo.setImage(UIImage.init(named: "videoOption_Unslected"), for: .normal)
        self.btnImage.setImage(UIImage.init(named: "imageOption_Unselected"), for: .normal)
        
        if self.btnVideo.isSelected == true {
            self.btnVideo.setTitleColor(UIColor.white, for: .normal)
            self.btnVideo.backgroundColor = UIColor.init(red: 226/255.0, green: 193/255.0, blue: 68/255.0, alpha: 1)
        }
        else {
            btnImage.setTitleColor(UIColor.white, for: .normal)
            btnImage.backgroundColor = UIColor.init(red: 226/255.0, green: 193/255.0, blue: 68/255.0, alpha: 1)
        }
        
    }
    
    func colorThreeButton() {
        
        self.btnPaid.backgroundColor = UIColor.clear
        self.btnUnlocked.backgroundColor = UIColor.clear
        self.btnAll.backgroundColor = UIColor.clear
        self.btnUnlocked.setTitleColor(UIColor.black, for: .normal)
        self.btnAll.setTitleColor(UIColor.black, for: .normal)
        self.btnPaid.setTitleColor(UIColor.black, for: .normal)
        
        if self.btnAll.isSelected == true{
            btnAll.setTitleColor(UIColor.white, for: .normal)
            btnAll.backgroundColor = UIColor.init(red: 226/255.0, green: 193/255.0, blue: 68/255.0, alpha: 1)
        }
        else if self.btnUnlocked.isSelected == true{
            btnUnlocked.setTitleColor(UIColor.white, for: .normal)
            btnUnlocked.backgroundColor = UIColor.init(red: 226/255.0, green: 193/255.0, blue: 68/255.0, alpha: 1)
        }
        else {
            btnPaid.setTitleColor(UIColor.white, for: .normal)
            btnPaid.backgroundColor = UIColor.init(red: 226/255.0, green: 193/255.0, blue: 68/255.0, alpha: 1)
        }
    }
    
    @IBAction func btnPlayedActn(_ sender: UIButton) {
        let pushVc = self.storyboard?.instantiateViewController(withIdentifier: "ExerciseVideoViewController") as! ExerciseVideoViewController
        self.navigationController?.pushViewController(pushVc, animated: true)
    }
}

extension ExerciseLibraryViewController: EmptyDataSetSource, EmptyDataSetDelegate {
    func title(forEmptyDataSet scrollView: UIScrollView) -> NSAttributedString? {
        return CommonUtility.dzEmptySetTitle(title: NSLocalizedString("title.error.nodata", comment: "This string shows when there is no data found."))
    }
    
    func emptyDataSetShouldDisplay(_ scrollView: UIScrollView) -> Bool {
        if self.patientLibraryViewModel.exerciseData == nil && !shouldShowNoData{
            return false
        }
        if self.btnVideo.isSelected{
            if self.patientLibraryViewModel.exerciseData?.result.video.count == 0 {
                return true
            }
        }else if self.patientLibraryViewModel.exerciseData?.result.image.count == 0 {
            return true
        }
        return false
    }
}
