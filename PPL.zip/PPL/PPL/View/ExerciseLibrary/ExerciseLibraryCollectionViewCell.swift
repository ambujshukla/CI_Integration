//
//  CustomCollectionViewCell.swift
//  PilateLibrary
//
//  Created by TanjeetAjmani on 30/04/18.
//  Copyright © 2018 TanjeetAjmani. All rights reserved.
//

import UIKit

class ExerciseLibraryCollectionViewCell: UICollectionViewCell {
    @IBOutlet weak var image: UIImageView!
    
    @IBOutlet weak var lblVideoName: UILabel!
    @IBOutlet weak var lblImageName: UILabel!
    @IBOutlet weak var imageVC: UIImageView!
    @IBOutlet weak var lblTime: UILabel!
    @IBOutlet weak var btnVideoStatus: UIButton!
    @IBOutlet weak var btnPlay: UIButton!
    
    @IBOutlet weak var btnPlayed: UIButton!
    @IBOutlet weak var lblExercise: UILabel!
    @IBOutlet weak var lblName: UILabel!
    @IBOutlet weak var lblTitle: UILabel!
    
    override func awakeFromNib() {
        super.awakeFromNib()
        DecorateControls.styleLabel(label: lblTitle, text: "", font: UIFont.systemFont(ofSize: FONT_SIZE_15), textColor: blackColor())
        DecorateControls.styleLabel(label: lblName, text: "", font: UIFont.systemFont(ofSize: FONT_SIZE_12), textColor: blackColor())
        DecorateControls.styleLabel(label: lblTime, text: "", font: UIFont.systemFont(ofSize: FONT_SIZE_10), textColor: blackColor())
    }
    
}
