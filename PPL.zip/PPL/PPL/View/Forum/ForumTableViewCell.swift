//
//  CustomTableViewCell.swift
//  33NewForum
//
//  Created by PujaDwivedi on 04/05/18.
//  Copyright © 2018 PujaDwivedi. All rights reserved.
//

import UIKit

class ForumTableViewCell: UITableViewCell {
    
    @IBOutlet weak var senderBubbleCorner: UIImageView!
    @IBOutlet weak var rcvrBubbleCorner: UIImageView!
    @IBOutlet weak var receivedMsgLbl: UILabel!
    @IBOutlet weak var sentMsgLbl: UILabel!
    @IBOutlet weak var receivedMsgImage: UIImageView!
    @IBOutlet weak var sentMsgImage: UIImageView!
    @IBOutlet weak var chatUserImage: UIImageView!
    @IBOutlet weak var editButton: UIButton!
    @IBOutlet weak var label1Detail: UILabel!
    @IBOutlet weak var label1: UILabel!
    @IBOutlet weak var userImage: UIImageView!
    
    override func awakeFromNib() {
        super.awakeFromNib()
        DecorateControls.styleLabel(label: label1, text: "", font: UIFont.boldSystemFont(ofSize: FONT_SIZE_25), textColor: blackColor())
        DecorateControls.styleLabel(label: label1Detail, text: "", font: UIFont.boldSystemFont(ofSize: FONT_SIZE_16), textColor: color(red: 126, green: 126, blue: 126))
        DecorateControls.styleLabel(label: sentMsgLbl, text: "", font: UIFont.boldSystemFont(ofSize: FONT_SIZE_16), textColor: color(red: 126, green: 126, blue: 126))
        DecorateControls.styleLabel(label: receivedMsgLbl, text: "", font: UIFont.boldSystemFont(ofSize: FONT_SIZE_16), textColor: whiteColor())
        DecorateControls.putTitle(button: editButton, text: "", font: UIFont.boldSystemFont(ofSize: FONT_SIZE_20), textColor: whiteColor(), backGroundColor: appColor())
        
    }
}
