//
//  PilateForumViewController.swift
//  PPL
//
//  Created by PankajPurohit on 30/05/18.
//  Copyright © 2018 cdn. All rights reserved.
//

import UIKit

class PilateForumViewController: UIViewController, UITableViewDelegate , UITableViewDataSource {
    
    @IBOutlet weak var sentButton: UIButton!
    @IBOutlet weak var chatTableView: UITableView!
    @IBOutlet weak var chatView: UIView!
    @IBOutlet weak var buttonBorderImage: UIImageView!
    @IBOutlet weak var publicButton: UIButton!
    @IBOutlet weak var privateButton: UIButton!
    @IBOutlet weak var messageTxtFld: UITextField!
    @IBOutlet weak var cameraButton: UIButton!
    @IBOutlet weak var moreLabel: UILabel!
    @IBOutlet weak var peopleLabel: UILabel!
    @IBOutlet weak var addLabel: UILabel!
    @IBOutlet weak var muteButton: UIButton!
    @IBOutlet weak var muteLabel: UILabel!
    @IBOutlet weak var moreButton: UIButton!
    @IBOutlet weak var peopleButton: UIButton!
    @IBOutlet weak var addButton: UIButton!
    @IBOutlet weak var newView2Labels: UIView!
    @IBOutlet weak var view2Labels: UIView!
    @IBOutlet weak var view2Buttons: UIView!
    @IBOutlet weak var View2: UIView!
    @IBOutlet weak var lblLastSeen: UILabel!
    @IBOutlet weak var lblChatUser: UILabel!
    @IBOutlet weak var myTableView: UITableView!
    @IBOutlet weak var forumLabel: UILabel!
    var senderText = ""
    var rowSelectnIndex = 0
    
    var arrData = [["labelName" : "Regina Phallange" , "labelDetail" : "You are suggested to continue old sessions with increased number of sets.You are suggested to continue old sessions with increased number of sets.You are suggested to continue old sessions with increased number of sets.Pujaincreased number of sets.Puja" , "userBtn" : "Private"],["labelName" : "Regina Phallange" , "labelDetail" : "You are suggested to continue old sessions with increased number of sets.You are suggested to continue old sessions with increased number of sets.You are suggested to continue old sessions with increased number of sets.Puja" , "userBtn" : "Public"]]
    
    
    var dictForumDetails = [["btnTextColor" : blackColor() ,"btnBgColor" : whiteColor()],["btnTextColor" : whiteColor() ,"btnBgColor" : appColor()]]
    
    override func viewDidLoad() {
        super.viewDidLoad()
        self.styleUI()
    }
    
    func styleUI() {
        self.myTableView.separatorColor = UIColor.clear
        self.chatTableView.separatorColor = UIColor.clear
        
        DecorateControls.styleLabel(label: forumLabel, text: "Forum", font: UIFont.boldSystemFont(ofSize: FONT_SIZE_27), textColor: blackColor())
        
        DecorateControls.styleLabel(label: lblChatUser, text: "Regina Phallange", font: UIFont.boldSystemFont(ofSize: FONT_SIZE_25), textColor: blackColor())
        DecorateControls.styleLabel(label: lblLastSeen, text: "Saturday, 22nd January, 4:45 PM", font: UIFont.boldSystemFont(ofSize: FONT_SIZE_16), textColor: lightGray())
        DecorateControls.putText(textField: messageTxtFld, text: "", placehoder: "Text Message", font: UIFont.boldSystemFont(ofSize: FONT_SIZE_18), textColor: color(red: 172, green: 172, blue: 172))
        messageTxtFld.backgroundColor = UIColor.init(red: 245/255.0 , green: 245/255.0 , blue: 245/255.0 , alpha: 1)
        sentButton.setImage(#imageLiteral(resourceName: "send@1"), for: .normal)
        messageTxtFld.layer.cornerRadius = 10.0
        messageTxtFld.layer.borderColor = UIColor.init(red: 106/255.0, green: 106/255.0, blue: 106/255.0, alpha: 1).cgColor
        messageTxtFld.layer.borderWidth = 1.0
        
        self.myTableView.estimatedRowHeight = 90
        self.myTableView.rowHeight = UITableViewAutomaticDimension
        self.chatTableView.estimatedRowHeight = 80
        self.chatTableView.rowHeight = UITableViewAutomaticDimension
        self.messageTxtFld.setLeftPaddingPoints(10)
        self.messageTxtFld.setRightPaddingPoints(10)
        self.styleNavigationBar()
    }
    
    func styleNavigationBar()
    {
        if navigationController?.viewControllers.count == 1 {
            CommonUtility.createCustomBackButton(self, navBarItem: self.navigationItem, strImage: "menu_slide", select: #selector(doClickSideMenu))
        }
        else {
            CommonUtility.createCustomBackButton(self, navBarItem: self.navigationItem, strImage: "back_icon _white", select: #selector(openPopView))
        }
        
        CommonUtility.setNavBarTitle(self.navigationItem, title: NSLocalizedString("Forum", comment: "The title of the forum navigation bar"))
        
        CommonUtility.createRightBarHomeButtons(target: self, navigationItem: self.navigationItem, select1: #selector(openProfileView), select2: #selector(openDashBoardView))
    }
    
    //MARK: - Navigation Bar Methods
    @objc func openPopView() {
        self.navigationController?.popViewController(animated: true)
    }
    
    @objc func doClickSideMenu()
    {
        panel?.openLeft(animated: true)
    }
    
    @objc func openProfileView()
    {
    self.navigationController?.pushViewController((self.storyboard?.instantiateViewController(withIdentifier: "DoctorProfileViewController"))!, animated: true)
    }
    
    @objc func openDashBoardView()
    {
        CommonUtility.setMenuSelectedOption(menuOptionIndex: 0)
        let centerVC : UIViewController
        let storyboard =  UIStoryboard(name: "Pilates", bundle: nil)
        centerVC = storyboard.instantiateViewController(withIdentifier: "PilatesDashboardViewController")
        let centerNavVC = UINavigationController(rootViewController: centerVC)
        self.panel?.configs.centerPanelTransitionType = .moveLeft
        self.panel?.configs.centerPanelTransitionDuration = 1.0
        _ = panel?.center(centerNavVC)

    }
    
    @objc func openNotificationsView()
    {
        self.navigationController?.pushViewController((self.storyboard?.instantiateViewController(withIdentifier: "NotificationsViewController"))!, animated: true)
    }
    
    
    @objc func openSettingsView()
    {
        self.navigationController?.pushViewController((self.storyboard?.instantiateViewController(withIdentifier: "SettingsViewController"))!, animated: true)
    }
    
    
    
    func tableView(_ tableView: UITableView, heightForRowAt indexPath: IndexPath) -> CGFloat {
        return UITableViewAutomaticDimension
    }
    
    func tableView(_ tableView: UITableView, numberOfRowsInSection section: Int) -> Int {
        if tableView == myTableView {
            return arrData.count
        } else {
            return 2 }
    }
    
    func tableView(_ tableView: UITableView, cellForRowAt indexPath: IndexPath) -> UITableViewCell {
        if tableView == myTableView {
            let cell = myTableView.dequeueReusableCell(withIdentifier: "cell") as! ForumTableViewCell
            cell.userImage?.image = #imageLiteral(resourceName: "forum_user")
            cell.label1?.text = arrData[indexPath.row]["labelName"]
            cell.label1Detail?.text =  arrData[indexPath.row]["labelDetail"]
            cell.editButton?.setTitle(arrData[indexPath.row]["userBtn"], for: .normal)
            cell.editButton.layer.borderWidth = 1
            cell.editButton.layer.borderColor = appColor().cgColor
            //cell.editButton.setImage(#imageLiteral(resourceName: "edit_icon"), for: .normal)
            cell.selectionStyle = .none
            cell.backgroundColor  = UIColor.white
            if rowSelectnIndex == indexPath.row {
                cell.backgroundColor = colorWithAlpha(red: 232, green: 191, blue: 63, alpha: 0.3)
            }
            
            return cell
        } else {
            if indexPath.row == 0 {
                let cell = chatTableView.dequeueReusableCell(withIdentifier: "sentMsgCell") as! ForumTableViewCell
                cell.chatUserImage?.image = #imageLiteral(resourceName: "bubel_user")
                
                //cell.sentMsgLbl?.text = arrData[0]["labelDetail"]
                               cell.sentMsgLbl?.text = "Hello"
                // cell.sentMsgLbl?.font = UIFont.systemFont(ofSize: 12)
                // cell.sentMsgLbl?.textColor = UIColor.init(red: 45/255.0 , green: 46/255.0 , blue: 44/255.0 , alpha: 0.7)
                cell.senderBubbleCorner.image = #imageLiteral(resourceName: "sender_icon")
                cell.senderBubbleCorner.layer.cornerRadius = 10
                cell.sentMsgImage.layer.cornerRadius = 10
                cell.sentMsgImage.backgroundColor = UIColor.init(red: 245/255.0 , green: 245/255.0 , blue: 245/255.0 , alpha: 1)
                cell.selectionStyle = .none
                return cell
            } else {
                let cell1 = chatTableView.dequeueReusableCell(withIdentifier: "receivedMsgCell") as! ForumTableViewCell
            //    cell1.receivedMsgLbl?.text = "Ok.You You are suggested to continue old sessions with increased number of test2Ok.You You are suggested to continue old sessions with increased number of test2Ok.You You are suggested to continue old sessions with increased number of test2Ok.You You are suggested to continue old sessions with increased number of test2Ok.You You are suggested to continue old sessions with increased number of test2 Puja"
                cell1.receivedMsgLbl?.text = "Hello"
                // cell1.receivedMsgLbl?.font = UIFont.systemFont(ofSize: 12)
                // cell1.receivedMsgLbl?.textColor = UIColor.white
                cell1.receivedMsgImage.backgroundColor = UIColor.init(red: 231/255.0 , green: 192/255.0 , blue: 66/255.0 , alpha: 1)
                cell1.rcvrBubbleCorner.image = #imageLiteral(resourceName: "receiver_icon")
                cell1.receivedMsgImage.layer.cornerRadius = 10
                cell1.receivedMsgImage.clipsToBounds = true
                cell1.selectionStyle = .none
                return cell1
            }
        }
    }
    
    func tableView(_ tableView: UITableView, didSelectRowAt indexPath: IndexPath) {
        
        if tableView == myTableView {
            self.rowSelectnIndex = indexPath.row
            self.myTableView.reloadData()
        }
    }
    
    func colorBackgrnd() {
        privateButton.setTitleColor(UIColor.white, for: .selected)
        privateButton.setTitleColor(UIColor.black, for: .normal)
        privateButton.backgroundColor = UIColor.white
        publicButton.backgroundColor = UIColor.white
        publicButton.setTitleColor(UIColor.black, for: .normal)
        publicButton.setTitleColor(UIColor.white, for: .selected)
        view2Labels.isHidden = false
        newView2Labels.isHidden = true
        
        if privateButton.isSelected == true{
            privateButton.backgroundColor = UIColor.init(red: 231/255.0 , green: 192/255.0 , blue: 66/255.0 , alpha: 1)
            view2Labels.isHidden = true
            newView2Labels.isHidden = false
        } else {
            publicButton.backgroundColor = UIColor.init(red: 231/255.0 , green: 192/255.0 , blue: 66/255.0 , alpha: 1)
            view2Labels.isHidden = false
            newView2Labels.isHidden = true
        }}
    
    @IBAction func btnSelection(_ sender: UIButton) {
        privateButton.isSelected = false
        publicButton.isSelected = false
        
        sender.isSelected = true
        colorBackgrnd()
    }
    
    override func touchesBegan(_ touches: Set<UITouch>, with event: UIEvent?) {
        self.view.endEditing(true)
    }
    
    @IBAction func btnSentAction(_ sender: Any) {
        self.view.endEditing(true)
    }
}
