//
//  ViewController.swift
//  33NewForum
//
//  Created by PujaDwivedi on 04/05/18.
//  Copyright © 2018 PujaDwivedi. All rights reserved.
//

import UIKit
import Realm
import RealmSwift
import NotificationBannerSwift
import GrowingTextView

class ForumViewController: UIViewController , UITableViewDelegate , UITableViewDataSource, AppData,GrowingTextViewDelegate {
    
    @IBOutlet weak var sentButton: UIButton!
    @IBOutlet weak var chatTableView: UITableView!
    @IBOutlet weak var chatView: UIView!
    @IBOutlet weak var buttonBorderImage: UIImageView!
    @IBOutlet weak var publicButton: UIButton!
    @IBOutlet weak var privateButton: UIButton!
    @IBOutlet weak var messageTxtFld: UITextField!
    @IBOutlet weak var cameraButton: UIButton!
    @IBOutlet weak var moreLabel: UILabel!
    @IBOutlet weak var peopleLabel: UILabel!
    @IBOutlet weak var addLabel: UILabel!
    @IBOutlet weak var muteButton: UIButton!
    @IBOutlet weak var muteLabel: UILabel!
    @IBOutlet weak var moreButton: UIButton!
    @IBOutlet weak var peopleButton: UIButton!
    @IBOutlet weak var addButton: UIButton!
    @IBOutlet weak var newView2Labels: UIView!
    @IBOutlet weak var view2Labels: UIView!
    @IBOutlet weak var view2Buttons: UIView!
    @IBOutlet weak var View2: UIView!
    @IBOutlet weak var lblLastSeen: UILabel!
    @IBOutlet weak var lblChatUser: UILabel!
    @IBOutlet weak var myTableView: UITableView!
    @IBOutlet weak var forumLabel: UILabel!
    @IBOutlet weak var bottomTxtViewConstraint: NSLayoutConstraint!
    @IBOutlet weak var textViewMsg: GrowingTextView!
    @IBOutlet weak var chatViewHeight: NSLayoutConstraint!
    
    var senderText = ""
    var rowSelectnIndex = 0
    var forumViewModel = ForumViewModel()
    var strGroupId = ""
    fileprivate var arrChatData = [ChatMessage]()
    var userModel: UserModel = CommonUtility.userProfile()!
    var lastTimeStamp = 0
    
    var dictForumDetails = [["btnTextColor" : blackColor() ,"btnBgColor" : whiteColor()],["btnTextColor" : whiteColor() ,"btnBgColor" : appColor()]]
    
    var refreshControl: UIRefreshControl!
    
    override func viewDidLoad() {
        super.viewDidLoad()
        self.myTableView.separatorColor = UIColor.clear
        self.chatTableView.separatorColor = UIColor.clear
        self.lastTimeStamp = 0
        self.textViewMsg.delegate = self
//        let realmDelete = try! Realm()
//        try! realmDelete.write() {
//            let allChatMessages = realmDelete.objects(ChatMessage.self)
//            realmDelete.delete(allChatMessages)
//        }
        
        DecorateControls.styleLabel(label: forumLabel, text: "Forum", font: UIFont.boldSystemFont(ofSize: FONT_SIZE_27), textColor: blackColor())

        DecorateControls.putText(textView: textViewMsg, text: "", font: UIFont.boldSystemFont(ofSize: FONT_SIZE_18), textColor: color(red: 172, green: 172, blue: 172))
        textViewMsg.backgroundColor = UIColor.init(red: 245/255.0 , green: 245/255.0 , blue: 245/255.0 , alpha: 1)
        sentButton.setImage(#imageLiteral(resourceName: "send@1"), for: .normal)
        textViewMsg.layer.cornerRadius = 10.0
        textViewMsg.layer.borderColor = UIColor.init(red: 106/255.0, green: 106/255.0, blue: 106/255.0, alpha: 1).cgColor
        textViewMsg.layer.borderWidth = 1.0
        textViewMsg.placeholder = "Enter Message"
        
        self.myTableView.estimatedRowHeight = 90
        self.myTableView.rowHeight = UITableViewAutomaticDimension
        self.chatTableView.estimatedRowHeight = 80
        self.chatTableView.rowHeight = UITableViewAutomaticDimension
        self.textViewMsg.minHeight = 40.0
        self.textViewMsg.maxHeight = 90.0
        self.styleNavigationBar()
        
        NotificationCenter.default.addObserver(self, selector: #selector(self.didReceiveMsgListInRoom(notification:)), name: Notification.Name("receiveLastMessagesInRoom"), object: nil)
        NotificationCenter.default.addObserver(self, selector: #selector(keyboardWillChangeFrame), name: NSNotification.Name.UIKeyboardWillChangeFrame, object: nil)
        
        self.forumViewModel.chatGroupList { (chatGroupList) in
            self.forumViewModel.groupList = chatGroupList
            if (self.forumViewModel.groupList?.result.count)! > 0 {
                self.myTableView.reloadData()
                self.strGroupId =  (self.forumViewModel.groupList?.result[0].id)!
                //self.doGetChatDataWithRoomId()
                for  chatGroup in (self.forumViewModel.groupList?.result)!{
                    var params = [String: String]()
                    params["sent_to_group_id"] = chatGroup.id
                    SocketIOManager.doConnectToRoom(dictMessage: params)
                }
                self.forumViewModel.history_type = "1"
                self.getChatHistory()
            }
        }//self.history_type
        
        self.addRefreshControl()
    }
    
    func addRefreshControl() {
        refreshControl = UIRefreshControl()
        self.chatTableView.addSubview(self.refreshControl)
        self.refreshControl.attributedTitle = NSAttributedString(string: "Pull to refresh")
        self.refreshControl.addTarget(self, action: #selector(getChatHistory), for: .valueChanged)
    }
    
    @objc func getChatHistory() {
        self.forumViewModel.groupId = self.strGroupId
        self.forumViewModel.chatHistoryList { (chatHistory) in
            self.refreshControl.endRefreshing()
            if let result = chatHistory["result"] as? Array<Any> {
                if result.count > 0 {
                    self.doInertOrUpdateChat(arrChatGroup: result,shouldAddNewChat: false)
                    self.forumViewModel.history_type = "2"
                }else {
                   // self.refreshControl = nil
                }
                self.doGetChatDataWithRoomId()
            }
        }
    }
    
    @objc func doGetChatDataWithRoomId()
    {
        let realm = try! Realm()
        
        var strPredicateCondition = "sent_to_group_id == %@ && timestamp > %lli"
        if self.arrChatData.count > 0 {
            strPredicateCondition = "sent_to_group_id == %@ && timestamp < %lli"
        }
        
        let predicate = NSPredicate(format: strPredicateCondition, self.strGroupId, self.lastTimeStamp)
        
        // retrieves all Chats from the default Realm
        var arrTemp = Array(realm.objects(ChatMessage.self).filter(predicate).sorted(byKeyPath: "timestamp", ascending: true))
        if arrTemp.count > 0 {
            if arrTemp.count > 10 {
                arrTemp = Array(arrTemp.dropFirst(arrTemp.count - 10))
            }
            if self.arrChatData.count > 0 {
                self.arrChatData.append(contentsOf: arrTemp)
            }else {
                self.arrChatData = arrTemp
                self.scrollToBottom()
            }
            
            self.arrChatData = self.arrChatData.sorted(by: { $0.timestamp < $1.timestamp })
            
            self.lastTimeStamp = self.arrChatData.first!["timestamp"] as! Int
            self.chatTableView.reloadData()
            if self.arrChatData.count > 0 {
                self.forumViewModel.lastDateTime = self.arrChatData.first?.created_at
                print()
            }
        }
    }
    
    func styleNavigationBar()
    {
        if navigationController?.viewControllers.count == 1 {
            CommonUtility.createCustomBackButton(self, navBarItem: self.navigationItem, strImage: "menu_slide", select: #selector(doClickSideMenu))
        }
        else {
            CommonUtility.createCustomBackButton(self, navBarItem: self.navigationItem, strImage: "back_icon _white", select: #selector(openPopView))
        }
        
        CommonUtility.setNavBarTitle(self.navigationItem, title: NSLocalizedString("Forum", comment: "The title of the forum navigation bar"))
        
        
        CommonUtility.createRightBarHomeButtons(target: self, navigationItem: self.navigationItem, select1: #selector(openProfileView), select2: #selector(openDashBoardView))
    }
    
    func getChatGroupList() {
        
    }
    
    //MARK: - Navigation Bar Methods
    
    @objc func openPopView() {
        self.navigationController?.popViewController(animated: true)
    }
    
    @objc func doClickSideMenu()
    {
        panel?.openLeft(animated: true)
    }
    
    @objc func openProfileView()
    {
        let storyboard = UIStoryboard(name: "Main", bundle: nil)
        self.navigationController?.pushViewController((storyboard.instantiateViewController(withIdentifier: "ProfileViewController")), animated: true)
    }
    
    @objc func openNotificationsView()
    {
        self.navigationController?.pushViewController((self.storyboard?.instantiateViewController(withIdentifier: "NotificationsViewController"))!, animated: true)
    }
    
    @objc func openDashBoardView()
    {
        CommonUtility.setMenuSelectedOption(menuOptionIndex: 0)
        let centerVC : UIViewController
        let storyboard = UIStoryboard(name: "Main", bundle: nil)
        centerVC = storyboard.instantiateViewController(withIdentifier: "DashboardViewController")
        let centerNavVC = UINavigationController(rootViewController: centerVC)
        self.panel?.configs.centerPanelTransitionType = .moveLeft
        self.panel?.configs.centerPanelTransitionDuration = 1.0
        _ = panel?.center(centerNavVC)
    }
    
    @objc func openSettingsView()
    {
        self.navigationController?.pushViewController((self.storyboard?.instantiateViewController(withIdentifier: "SettingsViewController"))!, animated: true)
    }
    
    func tableView(_ tableView: UITableView, heightForRowAt indexPath: IndexPath) -> CGFloat {
        return UITableViewAutomaticDimension
    }
    
    func tableView(_ tableView: UITableView, numberOfRowsInSection section: Int) -> Int {
        if tableView == myTableView {
            guard let chatGroupList = self.forumViewModel.groupList else {
                return 0
            }
            return (chatGroupList.result.count)
        } else {
            return self.arrChatData.count
        }
    }
    
    func tableView(_ tableView: UITableView, cellForRowAt indexPath: IndexPath) -> UITableViewCell {
        if tableView == myTableView {
            let cell = myTableView.dequeueReusableCell(withIdentifier: "cell") as! ForumTableViewCell
            cell.userImage?.image = #imageLiteral(resourceName: "forum_user")
            cell.label1?.text = self.forumViewModel.groupList?.result[indexPath.row].name
            if self.forumViewModel.groupList?.result[indexPath.row].group_type == "1" {
                cell.editButton?.setTitle("Private", for: .normal)
            }else {
                cell.editButton?.setTitle("Public", for: .normal)
            }
            cell.editButton.layer.borderWidth = 1
            cell.editButton.layer.borderColor = appColor().cgColor
            cell.selectionStyle = .none
            cell.backgroundColor  = UIColor.white
            if rowSelectnIndex == indexPath.row {
                cell.backgroundColor = colorWithAlpha(red: 232, green: 191, blue: 63, alpha: 0.3)
            }
            return cell
        } else {
            if self.arrChatData[indexPath.row].sent_by != self.userModel.result.user_id {
                let cell = chatTableView.dequeueReusableCell(withIdentifier: "sentMsgCell") as! ForumTableViewCell
                cell.chatUserImage?.image = #imageLiteral(resourceName: "bubel_user")
                
                cell.sentMsgLbl?.text = self.arrChatData[indexPath.row]["message"] as? String
                cell.senderBubbleCorner.image = #imageLiteral(resourceName: "sender_icon")
                cell.senderBubbleCorner.layer.cornerRadius = 10
                cell.sentMsgImage.backgroundColor = UIColor.init(red: 245/255.0 , green: 245/255.0 , blue: 245/255.0 , alpha: 1)
                cell.sentMsgImage.layer.cornerRadius = 10.0
                
                cell.selectionStyle = .none
                return cell
            } else {
                let cell1 = chatTableView.dequeueReusableCell(withIdentifier: "receivedMsgCell") as! ForumTableViewCell
                cell1.receivedMsgLbl?.text = self.arrChatData[indexPath.row]["message"] as? String
                cell1.receivedMsgImage.backgroundColor = UIColor.init(red: 231/255.0 , green: 192/255.0 , blue: 66/255.0 , alpha: 1)
                cell1.rcvrBubbleCorner.image = #imageLiteral(resourceName: "receiver_icon")
                cell1.receivedMsgImage.layer.cornerRadius = 10.0
                cell1.selectionStyle = .none
                return cell1
            }
        }
    }
    
    func tableView(_ tableView: UITableView, didSelectRowAt indexPath: IndexPath) {
        
        if tableView == myTableView {
            self.forumViewModel.history_type = "1"
            self.lastTimeStamp = 0
            self.forumViewModel.lastDateTime = "-1"
            self.rowSelectnIndex = indexPath.row
            self.arrChatData.removeAll()
            self.chatTableView.reloadData()
            self.strGroupId = (self.forumViewModel.groupList?.result[indexPath.row].id)!
            self.getChatHistory()
            self.myTableView.reloadData()
        }
    }
    
    func colorBackgrnd() {
        privateButton.setTitleColor(UIColor.white, for: .selected)
        privateButton.setTitleColor(UIColor.black, for: .normal)
        privateButton.backgroundColor = UIColor.white
        publicButton.backgroundColor = UIColor.white
        publicButton.setTitleColor(UIColor.black, for: .normal)
        publicButton.setTitleColor(UIColor.white, for: .selected)
        view2Labels.isHidden = false
        newView2Labels.isHidden = true
        if privateButton.isSelected == true{
            privateButton.backgroundColor = UIColor.init(red: 231/255.0 , green: 192/255.0 , blue: 66/255.0 , alpha: 1)
            view2Labels.isHidden = true
            newView2Labels.isHidden = false
        } else {
            publicButton.backgroundColor = UIColor.init(red: 231/255.0 , green: 192/255.0 , blue: 66/255.0 , alpha: 1)
            view2Labels.isHidden = false
            newView2Labels.isHidden = true
        }}
    
    @IBAction func btnSelection(_ sender: UIButton) {
        privateButton.isSelected = false
        publicButton.isSelected = false
        sender.isSelected = true
        colorBackgrnd()
    }
    
    override func touchesBegan(_ touches: Set<UITouch>, with event: UIEvent?) {
        self.view.endEditing(true)
    }
    @IBAction func btnSentAction(_ sender: Any) {
        NetworkManager.isUnreachable { _ in
            CommonUtility.showErrorCRNotifications(title: "No Internet Connection", message: "Connect your device with Internet")
            return
        }
        var params = [String : Any]()
        params["sent_by"] = self.userModel.result.user_id
        params["sent_to_group_id"] = self.forumViewModel.groupList?.result[self.rowSelectnIndex].id
        params["user_type"] = CommonUtility.userType()
        params["local_id"] = self.uuid
        params["message"] = self.textViewMsg.text
        params["created_at"] = CommonUtility.doGetCurrentDateTime(withFormat: "yyyy-MM-dd hh:mm:ss")
        params["timestamp"] = self.timeStamp
        params["name"] = self.userModel.result.username
        
        self.textViewMsg.text = ""
        SocketIOManager.doSendMessage(dictMessage: params)
        self.view.endEditing(true)
        self.chatViewHeight.constant = 540
    }
    
    ///Receiving last messages
    @objc func didReceiveMsgListInRoom(notification : NSNotification)
    {
        if let userInfo = (notification.userInfo)
        {
            if let arrChatGroup = userInfo["args"] as? Array<Any>
            {
                self.doInertOrUpdateChat(arrChatGroup: arrChatGroup,shouldAddNewChat: true)
                guard let chatList = arrChatGroup as? Array<Dictionary<String,Any>> else{
                    return
                }
                if self.userModel.result.user_id != (chatList[0]["sent_by"]! as! String) {
                    let banner = NotificationBanner(title: (chatList[0]["name"]! as! String), subtitle: (chatList[0]["message"]! as! String), style: .success)
                 //   banner.show()
                //    CommonUtility.showSuccessCRNotifications(title: (chatList[0]["name"]! as! String), message: (chatList[0]["message"]! as! String))
                }
                print("")
            }
        }
    }
    
    func doInertOrUpdateChat(arrChatGroup: Array<Any>, shouldAddNewChat: Bool) {
        guard let chatList = arrChatGroup as? Array<Dictionary<String,Any>> else{
            return
        }
        for (_, dict) in chatList.enumerated()
        {
            print(dict)
            doSaveChatData(chatData: dict,shouldAddNewChat: shouldAddNewChat)
        }
        
        //        if chatList[0]["sent_to_group_id"] as! String == self.strGroupId {
        //            self.doGetChatDataWithRoomId()
        //        }
    //    self.chatTableView.reloadData()
//        if self.arrChatData.count <= 10 {
//            scrollToBottom()
//        }
    }
    
    func doSaveChatData(chatData : [String : Any], shouldAddNewChat: Bool)
    {
//        let predicate = NSPredicate(format: "timestamp == %d and sent_to_group_id == %@", self.getTimeStamp(chatData: chatData), self.strGroupId)

        let predicate = NSPredicate(format: "local_id == %@ and sent_to_group_id == %@", chatData["local_id"] as! CVarArg, self.strGroupId)

        let realm = try! Realm()
        let arrChatMessages = realm.objects(ChatMessage.self).filter(predicate)
        
        var messageModel = ChatMessage()
        if arrChatMessages.count > 0
        {
            messageModel = arrChatMessages[0]
            self.doInsertOrUpdateInChatTable(chatModel: messageModel, dictData: chatData, shouldInsert: false,shouldAddNewChat: shouldAddNewChat)
        }else
        {
            self.doInsertOrUpdateInChatTable(chatModel: messageModel, dictData: chatData, shouldInsert: true,shouldAddNewChat: shouldAddNewChat)
        }
    }
    
    func getTimeStamp(chatData : [String : Any]) -> Int {
        var timeStamp = 0
        
        if let timeStampValue = chatData["timestamp"] as? String {
            timeStamp = Int(timeStampValue)!
        }
        else {
            timeStamp = chatData["timestamp"] as! Int
        }
        return timeStamp
    }
    
    func doInsertOrUpdateInChatTable(chatModel : ChatMessage, dictData : [String : Any], shouldInsert : Bool,shouldAddNewChat: Bool) {
        let realm = try! Realm()
        try! realm.write() {
            chatModel.created_at = dictData["created_at"] as! String
            chatModel.local_id   = dictData["local_id"] as! String
            chatModel.message    = dictData["message"] as! String
            chatModel.name    = dictData["name"] as! String
            chatModel.sent_by    = dictData["sent_by"] as! String
            chatModel.sent_to_group_id = dictData["sent_to_group_id"] as! String
            chatModel.timestamp = self.getTimeStamp(chatData: dictData)
            chatModel.user_type = dictData["user_type"] as! String
            
            if shouldInsert
            {
                realm.add(chatModel)
            }
            if shouldAddNewChat {
                if self.strGroupId == chatModel.sent_to_group_id {
                    self.arrChatData.append(chatModel)
                    self.chatTableView.reloadData()
                    self.scrollToBottom()
                }
            }
        }
    }
    
    func scrollToBottom(){
        
        if self.arrChatData.count == 0 {
            return
        }
        DispatchQueue.main.async {
            let indexPath = IndexPath(row: self.arrChatData.count - 1, section: 0)
            self.chatTableView.scrollToRow(at: indexPath, at: .bottom, animated: false)
        }
    }
    
//    func getTimeStamp() {
//        let realm = try! Realm()
//
//      //  var strPredicateCondition = "sent_to_group_id == %@ && timestamp > %d"
//      //  if self.arrChatData.count > 0 {
//          //  strPredicateCondition = "sent_to_group_id == %@ && timestamp < %d"
//      //  }
//
//        let predicate = NSPredicate(format: "sent_to_group_id == %@ && timestamp < %d", self.strGroupId)
//
//        // retrieves all Chats from the default Realm
//        let arrTemp = Array(realm.objects(ChatMessage.self).filter(predicate).sorted(byKeyPath: "timestamp", ascending: true))
//        if arrTemp.count > 0 {
//            self.forumViewModel.lastDateTime = arrTemp.first!["timestamp"] as? String
//        }else {
//            self.forumViewModel.lastDateTime = "-1"
//        }
//    }
    
    //////////////// Text View ///////////////////
    deinit {
        NotificationCenter.default.removeObserver(self)
    }
    @objc private func keyboardWillChangeFrame(_ notification: Notification) {
        if let endFrame = (notification.userInfo?[UIKeyboardFrameEndUserInfoKey] as? NSValue)?.cgRectValue {
            var keyboardHeight = UIScreen.main.bounds.height - endFrame.origin.y
            if #available(iOS 11, *) {
                if keyboardHeight > 0 {
                    keyboardHeight = keyboardHeight - view.safeAreaInsets.bottom
                }
            }
            if keyboardHeight == 0 {
                bottomTxtViewConstraint.constant =  10
                view.layoutIfNeeded()
                self.scrollToTop()
            }
            else {
                bottomTxtViewConstraint.constant = keyboardHeight - 25
                view.layoutIfNeeded()
                self.scrollToTop()
                self.chatViewHeight.constant = 150
            }
        }
    }
    func scrollToTop(){
        
        if self.arrChatData.count == 0 {
            return
        }
        DispatchQueue.main.async {
            let indexPath = IndexPath(row: self.arrChatData.count - 1, section: 0)
            self.chatTableView.scrollToRow(at: indexPath, at: .top, animated: false)
        }
    }
    
    func textViewDidChangeHeight(_ textView: GrowingTextView, height: CGFloat) {
        UIView.animate(withDuration: 0.3, delay: 0.0, usingSpringWithDamping: 0.7, initialSpringVelocity: 0.7, options: [.curveLinear], animations: { () -> Void in
            self.view.layoutIfNeeded()
        }, completion: nil)
    }
    
    internal func textViewDidEndEditing(_ textView: UITextView) {
        self.chatViewHeight.constant = 540
    }
}
