
//
//  DashboardTableViewCell.swift
//  PPL
//
//  Created by cdn68 on 27/04/18.
//  Copyright © 2018 cdn. All rights reserved.
//

import UIKit

class DashboardTableViewCell: UITableViewCell {
    
    //MARK: Private Variables
    @IBOutlet  weak var lblGoalsTitle : UILabel?
    @IBOutlet fileprivate weak var imgArrow : UIImageView?
    
    @IBOutlet fileprivate weak var imgLogo : UIImageView?
    @IBOutlet  weak var lblDashboardOptions : UILabel?
    @IBOutlet  weak var viewImage : UIView?
    @IBOutlet  weak var btnArrow : UIButton?
    
    override func awakeFromNib() {
        super.awakeFromNib()
        self.imgArrow?.image = #imageLiteral(resourceName: "arrow_icon")
        self.btnArrow?.setImage(#imageLiteral(resourceName: "dashboard__table_arrow"), for: .normal)
        self.viewImage?.backgroundColor = color(red : Float(232) , green : Float(191) , blue : Float(63))
        DecorateControls.styleLabel(label: self.lblGoalsTitle, text: "", font: UIFont.systemFont(ofSize: FONT_SIZE_22), textColor: color(red: 106, green: 106 , blue: 106))
        DecorateControls.styleLabel(label: self.lblDashboardOptions, text: "", font: UIFont.boldSystemFont(ofSize: FONT_SIZE_28), textColor: color(red: 26, green: 53, blue: 61))
    }
    
    var goalsTitle : String = "" {
        didSet{
            self.lblGoalsTitle?.text = goalsTitle
        }
    }
    
    var dashboardTitle : String = "" {
        didSet{
            self.lblDashboardOptions?.text = dashboardTitle
        }
    }
    
    var dashboardImage : String = "" {
        didSet{
            self.imgLogo?.image = UIImage(named : dashboardImage)
        }
    }
}
