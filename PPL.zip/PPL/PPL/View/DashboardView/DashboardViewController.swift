
//
//  DashboardViewController.swift
//  PPL
//
//  Created by cdn68 on 27/04/18.
//  Copyright © 2018 cdn. All rights reserved.
//

import UIKit

private enum TableDashboardSection: Int {
    case clients = 0
    case schedule
    case myexercises
    case forum
    
    static let count: Int = {
        var max: Int = 0
        while let _ = TableDashboardSection(rawValue: max) { max += 1 }
        return max
    }()
}

class DashboardViewController: UIViewController, UITableViewDelegate, UITableViewDataSource {
    
    //MARK : Private variables
    @IBOutlet fileprivate weak var imgBg : UIImageView!
    @IBOutlet fileprivate weak var imgProfile : UIImageView!
    @IBOutlet fileprivate weak var viewProfile : UIView!
    @IBOutlet fileprivate weak var viewGoalDate : UIView!
    @IBOutlet fileprivate weak var lblUserName : UILabel!
    @IBOutlet fileprivate weak var lblDay : UILabel!
    @IBOutlet fileprivate weak var lblDate : UILabel!
    @IBOutlet fileprivate weak var btnCalendar : UIButton!
    
    @IBOutlet fileprivate weak var lblGoals : UILabel!
    @IBOutlet fileprivate weak var tblView : UITableView!
    @IBOutlet fileprivate weak var tblViewDashboardOptions : UITableView!
    
    @IBOutlet fileprivate weak var imgSep1 : UIImageView!
    @IBOutlet fileprivate weak var imgSep2 : UIImageView!
    
    var arrDashboardData = [String : [[String : Any]]]()
    var userModel: UserModel = CommonUtility.userProfile()!
    
    //MARK : Life cycle
    override func viewDidLoad(){
        super.viewDidLoad()
        self.styleUI()
        self.configureInitialParameters()
    }
    
    override func viewWillAppear(_ animated: Bool) {
        super.viewWillAppear(true)
        self.navigationController?.isNavigationBarHidden = false
    }
    
    //MARK : Private Methods
    private func styleUI() {
        DecorateControls.styleLabel(label: lblDay, text: CommonUtility.changeDateFormateOfDate(obj: userModel.result.dob ?? "", oldFormate: "YYYY-MM-dd", newFormate: "EEEE"), font: UIFont.boldSystemFont(ofSize: FONT_SIZE_20), textColor: color(red: 106, green: 106, blue: 106))
        DecorateControls.styleLabel(label: lblDate, text: CommonUtility.changeDateFormateOfDate(obj: userModel.result.dob ?? "", oldFormate: "YYYY-MM-dd", newFormate: "MMMM dd"), font: UIFont.boldSystemFont(ofSize: FONT_SIZE_20), textColor: color(red: 106, green: 106, blue: 106))
        self.imgBg.image = #imageLiteral(resourceName: "background_img")
        self.lblDate.textAlignment = .center
        self.lblDay.textAlignment = .center
        
        self.btnCalendar.setImage(#imageLiteral(resourceName: "calendar_icon"), for: .normal)
        DecorateControls.styleLabel(label: lblGoals, text: "Goals", font: UIFont.boldSystemFont(ofSize: FONT_SIZE_30), textColor: blackColor())
        DecorateControls.styleLabel(label: lblUserName, text: " \(userModel.result.firstname!) \(userModel.result.lastname!)", font: UIFont.boldSystemFont(ofSize: FONT_SIZE_28), textColor: blackColor())

        self.imgSep1.backgroundColor = color(red: 246, green: 246, blue: 246)
        self.imgSep2.backgroundColor = color(red: 246, green: 246, blue: 246)
        self.viewGoalDate.layer.borderColor = color(red: 246, green: 246, blue: 246).cgColor
        self.viewGoalDate.layer.borderWidth = 1.0;
        
        self.viewProfile.layer.borderColor = color(red: 225, green: 225, blue: 225).cgColor
        self.viewProfile.layer.borderWidth = 1.0;
        self.imgProfile.backgroundColor = UIColor.lightGray
        
        //Style TableView
        self.doSetUpTableView()
        self.styleNavigationBar()
        self.tblView.isScrollEnabled = false
        self.tblView.allowsSelection = false
        self.tblViewDashboardOptions.isScrollEnabled = false
        self.tblViewDashboardOptions.allowsSelection = true
        
        if (userModel.result.profile_image != nil) {
            self.imgProfile.sd_setImage(with: URL(string: userModel.result.profile_image!), placeholderImage: #imageLiteral(resourceName: "no-inage"))
        }

        self.imgProfile.contentMode = .scaleToFill
        
        if  userModel.result.goals != nil {
            if (userModel.result.goals?.isEmpty)! {
                self.tblView.isHidden = true
                self.lblGoals.isHidden = true
            }
        }
    }
    
    func styleNavigationBar()
    {
        if navigationController?.viewControllers.count == 1 {
            CommonUtility.createCustomBackButton(self, navBarItem: self.navigationItem, strImage: "menu_slide", select: #selector(doClickSideMenu))
        }
        else {
            CommonUtility.createCustomBackButton(self, navBarItem: self.navigationItem, strImage: "back_icon _white", select: #selector(openPopView))
        }
        
        CommonUtility.createCustomRightButton(self, navBarItem: self.navigationItem, strImage: "dashboard_user_button", select: #selector(doOpenProfile))
        
        CommonUtility.setNavBarTitle(self.navigationItem, title: NSLocalizedString("title.dashboard", comment: "The title of the dashboard navigation bar"))
    }
    
    //MARK: - Navigation Bar Methods
    @objc func openPopView() {
      self.navigationController?.popViewController(animated: true)
    }
    
    @objc func doClickSideMenu()
    {
        panel?.openLeft(animated: true)
    }
    
    @objc func doOpenProfile()
    {
    let pushVc = self.storyboard?.instantiateViewController(withIdentifier: "ProfileViewController") as! ProfileViewController
    self.navigationController?.pushViewController(pushVc, animated: true)
    }
    
    private func configureInitialParameters()
    {
        self.arrDashboardData = ["goalsData" : [["title" : "Weight Loss"],["title" : "Core Muscle Strength"]],"dashboardData" : [["title" : "Pilates Instructor","image":"dashboard_pilates_Instructor"],["title" : "My Appointments","image":"dashboard_my_oppointment"], ["title" : "My Exercises","image":"dashboard_my_exercises"], ["title" : "Forum","image":"dashboard_forum"]]]
    }
    
    private func doSetUpTableView()
    {
        self.tblView.estimatedRowHeight = 70
        self.tblView.rowHeight = UITableViewAutomaticDimension
        
        self.tblView.preventEmptyCellSeparators()
        self.tblViewDashboardOptions.preventEmptyCellSeparators()
        self.tblViewDashboardOptions.backgroundColor = UIColor.clear
    }
    
    override func viewDidLayoutSubviews() {
        self.viewProfile.layer.borderWidth = 1
        self.viewProfile.layer.masksToBounds = true
        self.viewProfile.layer.borderColor = UIColor.lightGray.cgColor
        self.viewProfile.layer.cornerRadius = viewProfile.frame.width/2
        self.viewProfile.clipsToBounds = true
        self.imgProfile.layer.borderWidth = 1
        self.imgProfile.layer.masksToBounds = true
        self.imgProfile.layer.borderColor = UIColor.lightGray.cgColor
        self.imgProfile.layer.cornerRadius = imgProfile.frame.height/2
        self.imgProfile.clipsToBounds = true
    }
    
    //MARK : TableView Delegate and DataSources
    
    func numberOfSections(in tableView: UITableView) -> Int {
        if tableView.tag == 100 {
            return TableDashboardSection.count
        }
        return 1
    }
    func tableView(_ tableView: UITableView, numberOfRowsInSection section: Int) -> Int {
        if tableView.tag == 100 {
            return 1
        }
        if  userModel.result.goals == nil {
            return 0
        }
        return (userModel.result.goals?.components(separatedBy: ",").count)!
    }
    
    func tableView(_ tableView: UITableView, cellForRowAt indexPath: IndexPath) -> UITableViewCell {
        if tableView.tag == 100 {
            return self.configureDashboardCell(atSection: indexPath.section)
        }else{
            return self.configureGoalsCell(atRow: indexPath.row)
        }
    }
    
    func tableView(_ tableView: UITableView, didSelectRowAt indexPath: IndexPath) {
        
        tblViewDashboardOptions.reloadData()
        
        if tableView == tblViewDashboardOptions
        {
            
          // CommonUtility.setMenuSelectedOption(menuOptionIndex: indexPath.section + 1)
            
            if indexPath.section == 0 {
                let pushVc = self.storyboard?.instantiateViewController(withIdentifier: "PilatesViewController") as! PilatesViewController
                self.navigationController?.pushViewController(pushVc, animated: true)
            }
            else if indexPath.section == 1
            {
                let pushVc1 = self.storyboard?.instantiateViewController(withIdentifier: "AppointmentsViewController") as! AppointmentsViewController
                self.navigationController?.pushViewController(pushVc1, animated: true)
            }
            else if indexPath.section == 2 {
                let pushVc2 = self.storyboard?.instantiateViewController(withIdentifier: "ExerciseLibraryViewController") as! ExerciseLibraryViewController
                self.navigationController?.pushViewController(pushVc2, animated: true)
            }
            else {
            
                let pushVc3 = self.storyboard?.instantiateViewController(withIdentifier: "ForumViewController") as! ForumViewController
                self.navigationController?.pushViewController(pushVc3, animated: true)
            }}
    }
    
    private func configureDashboardCell(atSection section: Int) -> UITableViewCell {
        let cell = self.tblViewDashboardOptions.dequeueReusableCell(withIdentifier: "cellRight") as! DashboardTableViewCell
        cell.selectionStyle = .none
        cell.dashboardTitle = self.arrDashboardData["dashboardData"]![section]["title"] as! String
        cell.dashboardImage = self.arrDashboardData["dashboardData"]![section]["image"] as! String
        return cell
    }
    
    private func configureGoalsCell(atRow row: Int) -> UITableViewCell {
        let cell = self.tblView.dequeueReusableCell(withIdentifier: "cell") as! DashboardTableViewCell
        cell.selectionStyle = .none
        cell.goalsTitle = (userModel.result.goals?.components(separatedBy: ",")[row])!
        return cell
    }
    
    func tableView(_ tableView: UITableView, heightForHeaderInSection section: Int) -> CGFloat {
        if tableView.tag == 100 {
            return 20
        }
        return 0
    }
    
    func tableView(_ tableView: UITableView, heightForRowAt indexPath: IndexPath) -> CGFloat {
        if tableView.tag == 100 {
            return 144
        }
        return UITableViewAutomaticDimension
    }
}
