//
//  PilatesDashboardViewController.swift
//  PPL
//
//  Created by PankajPurohit on 30/05/18.
//  Copyright © 2018 cdn. All rights reserved.
//

import UIKit
import SDWebImage

private enum TableDashboardSection: Int {
    case clients = 0
    case schedule
    case myexercises
    case forum
    
    static let count: Int = {
        var max: Int = 0
        while let _ = TableDashboardSection(rawValue: max) { max += 1 }
        return max
    }()
}

private enum TableGoalsRows: Int {
    case weightLoss = 0
    case coreMuscleStrength
    
    static let count: Int = {
        var max: Int = 0
        while let _ = TableGoalsRows(rawValue: max) { max += 1 }
        return max
    }()
}

class PilatesDashboardViewController: UIViewController, UITableViewDelegate, UITableViewDataSource {
    
    //MARK : Private variables
    @IBOutlet fileprivate weak var imgBg : UIImageView!
    @IBOutlet fileprivate weak var imgProfile : UIImageView!
    @IBOutlet fileprivate weak var viewProfile : UIView!
    @IBOutlet fileprivate weak var lblQualificatnDetail: UILabel!
    @IBOutlet fileprivate weak var lblQualificatn: UILabel!
    @IBOutlet fileprivate weak var lblUserName : UILabel!
    @IBOutlet fileprivate weak var lblExpertise: UILabel!
    @IBOutlet fileprivate weak var lblExperienceDetail: UILabel!
    @IBOutlet fileprivate weak var lblExperience: UILabel!
    @IBOutlet fileprivate weak var lblExpertiseDetail: UILabel!
    @IBOutlet fileprivate weak var tblViewDashboardOptions : UITableView!
    
    @IBOutlet weak var viewBox: UIView!
    var userModel: UserModel = CommonUtility.userProfile()!

    var arrDashboardData = [String : [[String : Any]]]()
    
    //MARK : Life cycle
    override func viewDidLoad(){
        super.viewDidLoad()
        self.styleUI()
        self.configureInitialParameters()
    }
    
    override func viewWillAppear(_ animated: Bool) {
        super.viewWillAppear(true)
        self.navigationController?.isNavigationBarHidden = false
    }
    
    //MARK : Private Methods
    func styleUI(){
        self.imgBg.image = #imageLiteral(resourceName: "background_img")
        DecorateControls.styleLabel(label: lblUserName, text: " \(userModel.result.firstname!) \(userModel.result.lastname!)", font: UIFont.boldSystemFont(ofSize: FONT_SIZE_28), textColor: blackColor())
        DecorateControls.styleLabel(label: lblQualificatn, text: "Qualification :", font: UIFont.systemFont(ofSize: FONT_SIZE_18), textColor: color(red: 89, green: 89, blue: 89))
        DecorateControls.styleLabel(label: lblQualificatnDetail, text: userModel.result.qualification, font: UIFont.systemFont(ofSize: FONT_SIZE_18), textColor: color(red: 89, green: 89, blue: 89))
        DecorateControls.styleLabel(label: lblExpertise, text: "Expertise :", font: UIFont.systemFont(ofSize: FONT_SIZE_18), textColor: color(red: 89, green: 89, blue: 89))
        DecorateControls.styleLabel(label: lblExpertiseDetail, text: userModel.result.expertise, font: UIFont.systemFont(ofSize: FONT_SIZE_18), textColor: color(red: 89, green: 89, blue: 89))
        DecorateControls.styleLabel(label: lblExperience, text: "Experience :", font: UIFont.systemFont(ofSize: FONT_SIZE_18), textColor: color(red: 89, green: 89, blue: 89))
        DecorateControls.styleLabel(label: lblExperienceDetail, text: userModel.result.experience, font: UIFont.systemFont(ofSize: FONT_SIZE_18), textColor: color(red: 89, green: 89, blue: 89))
        
        self.viewProfile.layer.borderColor = color(red: 225, green: 225, blue: 225).cgColor
        self.viewProfile.layer.borderWidth = 1.0;
        self.imgProfile.sd_setImage(with: URL(string: userModel.result.profile_image!), placeholderImage: #imageLiteral(resourceName: "no-inage"))

        

        self.imgProfile.backgroundColor = UIColor.lightGray
        self.viewBox.layer.borderColor = UIColor.lightGray.cgColor
        self.viewBox.layer.borderWidth = 1.0;
        
        //Style TableView
        self.doSetUpTableView()
        self.styleNavigationBar()
        self.tblViewDashboardOptions.isScrollEnabled = false
        self.tblViewDashboardOptions.allowsSelection = true
    }
    
    func styleNavigationBar()
    {
        if navigationController?.viewControllers.count == 1 {
            CommonUtility.createCustomBackButton(self, navBarItem: self.navigationItem, strImage: "menu_slide", select: #selector(doClickSideMenu))
        }
        else {
            CommonUtility.createCustomBackButton(self, navBarItem: self.navigationItem, strImage: "back_icon _white", select: #selector(openPopView))
        }
        
        CommonUtility.createCustomRightButton(self, navBarItem: self.navigationItem, strImage: "dashboard_user_button", select: #selector(openProfileView))
        
        CommonUtility.setNavBarTitle(self.navigationItem, title: NSLocalizedString("title.dashboard", comment: "The title of the dashboard navigation bar"))
        
        
    }
    //MARK: - Navigation Bar Methods
    @objc func openPopView() {
        self.navigationController?.popViewController(animated: true)
    }
    
    @objc func doClickSideMenu()
    {
        panel?.openLeft(animated: true)
    }
    
    @objc func openProfileView()
    {
       let pushVc = self.storyboard?.instantiateViewController(withIdentifier: "DoctorProfileViewController") as! DoctorProfileViewController
        self.navigationController?.pushViewController(pushVc, animated: true)
    }
    
    private func configureInitialParameters()
    {
        self.arrDashboardData = ["goalsData" : [["title" : "Weight Loss"],["title" : "Core Muscle Strength"]],"dashboardData" : [["title" : "Clients","image":"dashboard_pilates_Instructor"],["title" : "Schedule","image":"dashboard_my_oppointment"], ["title" : "My Exercises","image":"dashboard_my_exercises"], ["title" : "Forum","image":"dashboard_forum"]]]
    }
    
    private func doSetUpTableView()
    {
        self.tblViewDashboardOptions.preventEmptyCellSeparators()
        self.tblViewDashboardOptions.backgroundColor = UIColor.clear
    }
    
    override func viewWillLayoutSubviews() {
        super.viewWillLayoutSubviews()
        self.viewProfile.layer.borderWidth = 1
        self.viewProfile.layer.masksToBounds = true
        self.viewProfile.layer.borderColor = UIColor.lightGray.cgColor
        self.viewProfile.layer.cornerRadius = viewProfile.frame.width/2
        self.viewProfile.clipsToBounds = true
        self.imgProfile.layer.borderWidth = 1
        self.imgProfile.layer.masksToBounds = true
        self.imgProfile.layer.borderColor = UIColor.lightGray.cgColor
        self.imgProfile.layer.cornerRadius = imgProfile.frame.width/2
        self.imgProfile.clipsToBounds = true
    }
    
    //MARK : TableView Delegate and DataSources
    
    func numberOfSections(in tableView: UITableView) -> Int {
        if tableView.tag == 100 {
            return TableDashboardSection.count
        }
        return 1
    }
    func tableView(_ tableView: UITableView, numberOfRowsInSection section: Int) -> Int {
        if tableView.tag == 100 {
            return 1
        }
        return TableGoalsRows.count
    }
    
    func tableView(_ tableView: UITableView, cellForRowAt indexPath: IndexPath) -> UITableViewCell {
        
        return self.configureDashboardCell(atSection: indexPath.section)
    }
    
    func tableView(_ tableView: UITableView, didSelectRowAt indexPath: IndexPath) {
        if tableView == tblViewDashboardOptions
        {
           
           // CommonUtility.setMenuSelectedOption(menuOptionIndex: indexPath.section + 1)
            
            if indexPath.section == 0 {
                let pushVc = self.storyboard?.instantiateViewController(withIdentifier: "PatientListViewController") as! PatientListViewController
                self.navigationController?.pushViewController(pushVc, animated: true)
            }
            else if indexPath.section == 1
            {
                let pushVc = self.storyboard?.instantiateViewController(withIdentifier: "PilateAppointmentsViewController") as! PilateAppointmentsViewController
                self.navigationController?.pushViewController(pushVc, animated: true)
            }
            else if indexPath.section == 2 {
                let pushVc = self.storyboard?.instantiateViewController(withIdentifier: "PilateExerciseLibraryViewController") as! PilateExerciseLibraryViewController
                self.navigationController?.pushViewController(pushVc, animated: true)
            }
            else {
               // let pushVc = self.storyboard?.instantiateViewController(withIdentifier: "PilateForumViewController") as! PilateForumViewController
                let storyBoard = UIStoryboard.init(name: "Main", bundle: nil)
                let pushVc = storyBoard.instantiateViewController(withIdentifier: "ForumViewController") as! ForumViewController
                self.navigationController?.pushViewController(pushVc, animated: true)
            }}
    }
    
    private func configureDashboardCell(atSection section: Int) -> UITableViewCell {
        let cell = self.tblViewDashboardOptions.dequeueReusableCell(withIdentifier: "cellRight") as! DashboardTableViewCell
        cell.selectionStyle = .none
        cell.dashboardTitle = self.arrDashboardData["dashboardData"]![section]["title"] as! String
        cell.dashboardImage = self.arrDashboardData["dashboardData"]![section]["image"] as! String
        return cell
    }
    
    func tableView(_ tableView: UITableView, heightForHeaderInSection section: Int) -> CGFloat {
        if tableView.tag == 100 {
            return 20
        }
        return 0
    }
    
    func tableView(_ tableView: UITableView, heightForRowAt indexPath: IndexPath) -> CGFloat {
        if tableView.tag == 100 {
            return 144
        }
        return UITableViewAutomaticDimension
    }
}


