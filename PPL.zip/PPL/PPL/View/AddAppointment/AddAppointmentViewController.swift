//
//  ViewController.swift
//  PilateAppointment
//
//  Created by TanjeetAjmani on 30/04/18.
//  Copyright © 2018 TanjeetAjmani. All rights reserved.
//

import UIKit
import ActionSheetPicker_3_0

class AddAppointmentViewController: UIViewController {
    @IBOutlet weak var btnTimeSlot: UIButton!
    @IBOutlet weak var btnDate: UIButton!
    @IBOutlet weak var imageSeperator2: UIImageView!
    @IBOutlet weak var imageSeperator1: UIImageView!
    @IBOutlet weak var btnSubmit: UIButton!
    @IBOutlet weak var btnBack: UIButton!
    @IBOutlet weak var lblTimeSlot: UILabel!
    @IBOutlet weak var lblDate: UILabel!
    @IBOutlet weak var lblAppointment: UILabel!
    @IBOutlet weak var imageBackGrnd: UIImageView!
    
    @IBOutlet weak var btnTimeSlotIcon: UIButton!
    @IBOutlet weak var btnDateIcon: UIButton!
    var max = Date()
    var maxTime = Date()
    
    override func viewDidLoad() {
        super.viewDidLoad()
        self.styleUI()
    }
    
    func styleUI() {
        
        self.imageBackGrnd.image = #imageLiteral(resourceName: "background_img")
        self.btnDateIcon.setImage(#imageLiteral(resourceName: "calender_appointments"), for: .normal)
        self.btnTimeSlotIcon.setImage(#imageLiteral(resourceName: "time_appointments"), for: .normal)
        self.btnBack.setImage(#imageLiteral(resourceName: "back_icon"), for: .normal)
        self.btnSubmit.layer.cornerRadius = 5
        self.btnSubmit.clipsToBounds = true
        self.navigationController?.isNavigationBarHidden = true
    
        DecorateControls.styleLabel(label: lblAppointment, text: "Enter Details For Appointment", font: UIFont.boldSystemFont(ofSize: FONT_SIZE_35), textColor: blackColor())
        DecorateControls.styleLabel(label: lblDate, text: "Enter Date :", font: UIFont.boldSystemFont(ofSize: FONT_SIZE_18), textColor: blackColor())
        DecorateControls.styleLabel(label: lblTimeSlot, text: "Select Time Slot :", font: UIFont.boldSystemFont(ofSize: FONT_SIZE_18), textColor: blackColor())
        DecorateControls.putTitle(button: btnSubmit, text: "Submit", font:  UIFont.boldSystemFont(ofSize: FONT_SIZE_28), textColor: whiteColor(), backGroundColor: appColor())
        DecorateControls.putTitle(button: btnDate, text: "00/00/0000", font:  UIFont.boldSystemFont(ofSize: FONT_SIZE_18), textColor: color(red: 172  , green: 172, blue: 172), backGroundColor: clearColor())
        DecorateControls.putTitle(button: btnTimeSlot, text: "00:00 pm", font:  UIFont.boldSystemFont(ofSize: FONT_SIZE_18), textColor: color(red: 172  , green: 172, blue: 172), backGroundColor: clearColor())
        btnTimeSlotIcon.isEnabled = false
        btnDateIcon.isEnabled = false
    }
    
    
    @IBAction func dateSelected(_ sender: UIButton) {
        let datePicker = ActionSheetDatePicker(title: "Date:", datePickerMode: UIDatePickerMode.date, selectedDate: max, doneBlock: {
            picker, value, index in
            
            let dateFormatter = DateFormatter()
            dateFormatter.dateFormat = "MM/dd/yyyy"
            let selectedDate = dateFormatter.string(from: value as! Date)
            print(selectedDate)
            
            
            self.max = dateFormatter.date(from: selectedDate)!
            
            
            
            self.btnDate.setTitle(selectedDate , for: .normal)
            return
            
        }, cancel: { ActionStringCancelBlock in return }, origin: sender)
        //let secondsInWeek: TimeInterval = 7 * 24 * 60 * 60;
        let secondsInWeek: TimeInterval = 1 * 365 * 24 * 60 * 60;
        //datePicker?.minimumDate = Date(timeInterval: -secondsInWeek, since: Date())
        datePicker?.minimumDate = Date()
        datePicker?.maximumDate = Date(timeInterval: 3*secondsInWeek, since: Date())
        
        datePicker?.show()
    }
    
    @IBAction func timeSelected(_ sender: UIButton) {
        let datePicker = ActionSheetDatePicker(title: "Time:", datePickerMode: UIDatePickerMode.time, selectedDate: maxTime, doneBlock: {
            picker, value, index in
            
            let timeFormatter = DateFormatter()
            timeFormatter.dateFormat = "hh:mm a"
            let selectedDate = timeFormatter.string(from: value as! Date)
            print(selectedDate)
            self.maxTime = timeFormatter.date(from: selectedDate)!
            self.btnTimeSlot.setTitle(selectedDate , for: .normal)
            return
        }, cancel: { ActionStringCancelBlock in return }, origin: sender)
        datePicker?.show()
    }
    
    @IBAction func btnTimeSlotIconActn(_ sender: UIButton) {
        
        let datePicker = ActionSheetDatePicker(title: "Time:", datePickerMode: UIDatePickerMode.time, selectedDate: maxTime, doneBlock: {
            picker, value, index in
            
            let timeFormatter = DateFormatter()
            
            timeFormatter.dateFormat = "hh:mm a"
            let selectedDate = timeFormatter.string(from: value as! Date)
            
            print(selectedDate)
            
            self.maxTime = timeFormatter.date(from: selectedDate)!
            
            self.btnTimeSlot.setTitle(selectedDate , for: .normal)
            
            return
        }, cancel: { ActionStringCancelBlock in return }, origin: sender)
        datePicker?.show()
    }
    @IBAction func btnDateIconActn(_ sender: UIButton) {
        
        let datePicker = ActionSheetDatePicker(title: "Date:", datePickerMode: UIDatePickerMode.date, selectedDate: max, doneBlock: {
            picker, value, index in
            let dateFormatter = DateFormatter()
            dateFormatter.dateFormat = "MM/dd/yyyy"
            let selectedDate = dateFormatter.string(from: value as! Date)
            print(selectedDate)
            self.max = dateFormatter.date(from: selectedDate)!
            self.btnDate.setTitle(selectedDate , for: .normal)
            return
            
        }, cancel: { ActionStringCancelBlock in return }, origin: sender)
        //let secondsInWeek: TimeInterval = 7 * 24 * 60 * 60;
        let secondsInWeek: TimeInterval = 1 * 365 * 24 * 60 * 60;
        //datePicker?.minimumDate = Date(timeInterval: -secondsInWeek, since: Date())
        datePicker?.minimumDate = Date()
        datePicker?.maximumDate = Date(timeInterval: 3*secondsInWeek, since: Date())
        
        datePicker?.show()
    }
    @IBAction func goSubmit(_ sender: UIButton) {
        
        let (isValid , message) = CommonUtility.doValidateAppointment(self)
        
        if isValid {
            CommonUtility.showSuccessCRNotifications(title: "Success!", message: message)
            DispatchQueue.main.asyncAfter(deadline: .now() + .seconds(1), execute: {
                self.navigationController?.popViewController(animated: true)
                
            })
            
        }else{
            CommonUtility.showErrorCRNotifications(title: "Error!", message: message)
        }
        
    }
    @IBAction fileprivate func goBack(sender: UIButton) {
        self.navigationController?.popViewController(animated: true)
    }
}

