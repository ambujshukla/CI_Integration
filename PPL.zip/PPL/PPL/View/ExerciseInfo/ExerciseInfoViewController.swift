//
//  ExerciseDetailsViewController.swift
//  PPL
//
//  Created by TanjeetAjmani on 07/05/18.
//  Copyright © 2018 cdn. All rights reserved.
//

import UIKit

class ExerciseInfoViewController: UIViewController, UITableViewDelegate, UITableViewDataSource {
    
    @IBOutlet weak var btnBack: UIButton!
    @IBOutlet weak var tVImages: UITableView!
    @IBOutlet weak var tVDetails: UITableView!
    
    
    var arrImg = ["man_box1","woman_box1","woman_box2"]
    var arrDetails = [["lblType": "Type","lblDetails" : "Mobilising"],["lblType": "Duration","lblDetails" : "60 Minutes"],["lblType": "Purpose","lblDetails" : "Core Muscular Strength"],["lblType": "Pilate Name","lblDetails" : "Regina Phallange"],["lblType": "No. of Sets","lblDetails" : "20"],["lblType": "No. of Days","lblDetails" : "4 Weeks"],["lblType": "Attachments","lblDetails" : "2 Videos,1 Image"],["lblType": "Description","lblDetails" : "Regina Phallange is Pilate' Name.She is from Indopre gina Phallange is Pilate' Name.She is from Indopr"]]
    
    override func viewDidLoad() {
        super.viewDidLoad()
        self.styleUI()
        self.styleNavigationBar()
        self.automaticallyAdjustsScrollViewInsets = false
    }
    
    override func viewWillAppear(_ animated: Bool) {
        super.viewWillAppear(true)
        self.navigationController?.isNavigationBarHidden = false
    }
    
    
    private func styleUI(){
        self.tVDetails.estimatedRowHeight = 42
        self.tVDetails.rowHeight = UITableViewAutomaticDimension
        self.tVImages.separatorStyle = .none
        self.tVDetails.separatorStyle = .none
        
    }
    
    private func styleNavigationBar()
    {
        CommonUtility.createCustomBackButton(self, navBarItem: self.navigationItem, strImage: "back_icon _white", select: #selector(openPopView))
        
        CommonUtility.setNavBarTitle(self.navigationItem, title: NSLocalizedString("Two minutes lower body exercise", comment: "The title of the exercised assigned navigation bar"))
        
        //  CommonUtility.createRightBarButtons(target: self, navigationItem: self.navigationItem, select1: #selector(openProfileView), select2: #selector(openNotificationsView), select3: #selector(openSettingsView))
        
        CommonUtility.createRightBarHomeButtons(target: self, navigationItem: self.navigationItem, select1: #selector(openProfileView), select2: #selector(openDashBoardView))
        
    }
    @objc func openProfileView()
    {
        self.navigationController?.pushViewController((self.storyboard?.instantiateViewController(withIdentifier: "ProfileViewController"))!, animated: true)
    }
    
    @objc func openNotificationsView()
    {
        self.navigationController?.pushViewController((self.storyboard?.instantiateViewController(withIdentifier: "NotificationsViewController"))!, animated: true)
    }
    
    @objc func openSettingsView()
    {
        self.navigationController?.pushViewController((self.storyboard?.instantiateViewController(withIdentifier: "SettingsViewController"))!, animated: true)
    }
    
    @objc func openPopView()
    {
        self.navigationController?.popViewController(animated: true)
    }
    
    @objc func openDashBoardView()
    {
        CommonUtility.setMenuSelectedOption(menuOptionIndex: 0)
        if CommonUtility.isPilate() {
            let storyboard =  UIStoryboard(name: "Pilates", bundle: nil)
            self.navigationController?.pushViewController((storyboard.instantiateViewController(withIdentifier: "PilatesDashboardViewController")), animated: true)
        }else{
            let storyboard = UIStoryboard(name: "Main", bundle: nil)
            self.navigationController?.pushViewController((storyboard.instantiateViewController(withIdentifier: "DashboardViewController")), animated: true)
        }
    }
    
    //MARK: - Navigation Bar Methods
    @objc func doClickSideMenu()
    {
        panel?.openLeft(animated: true)
    }
    
    
    
    func tableView(_ tableView: UITableView, numberOfRowsInSection section: Int) -> Int {
        if tableView == tVDetails {
            return arrDetails.count
        }
        else {
            return arrImg.count
        }
    }
    
    func tableView(_ tableView: UITableView, cellForRowAt indexPath: IndexPath) -> UITableViewCell {
        
        if tableView == tVDetails{
            let cell = tVDetails.dequeueReusableCell(withIdentifier: "cell1") as! ExerciseInfoTableViewCell
            cell.selectionStyle = .none
            cell.contentView.layer.borderWidth = 1
            cell.contentView.layer.borderColor = UIColor.lightGray.cgColor
            cell.lblType.text = arrDetails[indexPath.row]["lblType"]
            cell.lblColon.text = ":"
            cell.lblDetail.text = arrDetails[indexPath.row]["lblDetails"]
            return cell
        }
        else {
            let cell = tVImages.dequeueReusableCell(withIdentifier: "cell2") as! ExerciseInfoTableViewCell
            cell.selectionStyle = .none
            let cellImg = arrImg[indexPath.row]
            cell.btnPlay.setImage(UIImage.init(named: "play"), for: .normal)
            cell.imgBanner.image = UIImage.init(named: cellImg)
            return cell
        }
    }
    
    
    
    @IBAction func playBtnclicked(_ sender: UIButton) {
        
        self.navigationController?.pushViewController((self.storyboard?.instantiateViewController(withIdentifier: "ExerciseVideoViewController"))!, animated: true)
    }
    
    @IBAction func btnBack(_ sender: UIButton) {
        self.navigationController?.popViewController(animated: true)
    }
    
    func tableView(_ tableView: UITableView, heightForRowAt indexPath: IndexPath) -> CGFloat {
        if tableView == tVDetails{
            return UITableViewAutomaticDimension
        } else{
            return 220
        }
    }
}
