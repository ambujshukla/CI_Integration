//
//  ExerciseInfoTableViewCell.swift
//  PPL
//
//  Created by TanjeetAjmani on 07/05/18.
//  Copyright © 2018 cdn. All rights reserved.
//

import UIKit

class ExerciseInfoTableViewCell: UITableViewCell {
    
    override func awakeFromNib() {
        super.awakeFromNib()
        
        DecorateControls.styleLabel(label: lblType, text: "", font: UIFont.boldSystemFont(ofSize: FONT_SIZE_16), textColor: color(red: 172, green: 172, blue: 172))
        DecorateControls.styleLabel(label: lblDetail, text: "", font: UIFont.boldSystemFont(ofSize: FONT_SIZE_16), textColor: color(red: 172, green: 172, blue: 172))
        DecorateControls.styleLabel(label: lblColon, text: "", font: UIFont.boldSystemFont(ofSize: FONT_SIZE_16), textColor: color(red: 172, green: 172, blue: 172))
    }
    
    @IBOutlet weak var lblType: UILabel!
    @IBOutlet weak var btnPlay: UIButton!
    @IBOutlet weak var imgBanner: UIImageView!
    @IBOutlet weak var lblDetail: UILabel!
    @IBOutlet weak var lblColon: UILabel!
    
    
}
