//
//  NewChangePasswordViewController.swift
//  PilateImageDetail
//
//  Created by TanjeetAjmani on 03/05/18.
//  Copyright © 2018 TanjeetAjmani. All rights reserved.
//

import UIKit

class ChangePasswordViewController: UIViewController {
    
    @IBOutlet weak var btnSubmit: UIButton!
    @IBOutlet weak var imageUser: UIImageView!
    
    @IBOutlet weak var tableViewChangePassword: UITableView!
    @IBOutlet weak var lblChangePassword: UILabel!
    @IBOutlet weak var imageBg: UIImageView!
    @IBOutlet weak var btnBack: UIButton!
    
    var arrPasswrd = ["Old Password","New Password","Confirm New Password"]
    var changePasswordViewModel = ChangePasswordViewModel()
    
    override func viewDidLoad() {
        super.viewDidLoad()
        self.styleUI()
    }
    
    private func styleUI(){
        self.imageBg.image = #imageLiteral(resourceName: "background_img")
        self.imageUser.image = #imageLiteral(resourceName: "user_profile_profile")
        self.btnSubmit.layer.cornerRadius = 5
        
        self.tableViewChangePassword.separatorStyle = UITableViewCellSeparatorStyle.none
        tableViewChangePassword.backgroundColor = .clear
        
        self.navigationController?.isNavigationBarHidden = true
        self.btnBack.setImage(UIImage(named: "back_icon"), for: .normal)
        
        self.tableViewChangePassword.isScrollEnabled = false
        
        self.tableViewChangePassword.estimatedRowHeight = 75
        self.tableViewChangePassword.rowHeight = UITableViewAutomaticDimension
        
        DecorateControls.styleLabel(label: lblChangePassword , text: "Change Password", font: UIFont.boldSystemFont(ofSize: FONT_SIZE_35), textColor: blackColor())
        DecorateControls.putTitle(button: btnSubmit, text: "Save", font: UIFont.boldSystemFont(ofSize: FONT_SIZE_28), textColor: whiteColor(), backGroundColor: appColor())
    }
    
    @IBAction func doSubmitBtn(_ sender: UIButton) {
        if self.changePasswordViewModel.validate() {
            self.changePasswordViewModel.changePassword(completion: {
                self.navigationController?.popViewController(animated: true)
            }) { (error) in
            }
        }
    }
    
    @IBAction fileprivate func goBack(sender: UIButton){
        self.navigationController?.popViewController(animated: true)
    }
}

extension ChangePasswordViewController: UITableViewDataSource,UITextFieldDelegate{
    func tableView(_ tableView: UITableView, numberOfRowsInSection section: Int) -> Int {
        return arrPasswrd.count
    }
    
    func tableView(_ tableView: UITableView, cellForRowAt indexPath: IndexPath) -> UITableViewCell {
        let cell = tableView.dequeueReusableCell(withIdentifier: "cell2") as! ChangePasswordTableViewCell
        cell.backgroundColor = .clear
        cell.txtUserDetail.attributedPlaceholder = NSAttributedString(string: arrPasswrd[indexPath.row],attributes: [NSAttributedStringKey.foregroundColor: UIColor.darkGray])
        cell.txtUserDetail.placeholder = arrPasswrd[indexPath.row]
        cell.imgKey.image =  #imageLiteral(resourceName: "key_icon")
        cell.selectionStyle = .none
        cell.txtUserDetail.tag = indexPath.row
        cell.txtUserDetail.delegate = self 
        return cell
    }
    
    func textField(_ textField: UITextField, shouldChangeCharactersIn range: NSRange, replacementString string: String) -> Bool {
        if let text = textField.text as NSString? {
            let txtAfterUpdate = text.replacingCharacters(in: range, with: string)
            if textField.tag == 0 {
                self.changePasswordViewModel.currentPassword = txtAfterUpdate
            }else if textField.tag == 1 {
                self.changePasswordViewModel.newPassword = txtAfterUpdate
            }else  {
                self.changePasswordViewModel.confirmPassword = txtAfterUpdate
            }
        }
        return true
    }
    
    override func touchesBegan(_ touches: Set<UITouch>, with event: UIEvent?) {
        self.view.endEditing(true)
    }
}

extension ChangePasswordViewController: UITableViewDelegate{
    func tableView(_ tableView: UITableView, heightForRowAt indexPath: IndexPath) -> CGFloat {
        return UITableViewAutomaticDimension
        // return 72
    }
}
