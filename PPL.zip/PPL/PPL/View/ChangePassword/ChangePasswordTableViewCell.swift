//
//  CustomTableViewCell.swift
//  PilateImageDetail
//
//  Created by TanjeetAjmani on 02/05/18.
//  Copyright © 2018 TanjeetAjmani. All rights reserved.
//

import UIKit

class ChangePasswordTableViewCell: UITableViewCell {
    
    @IBOutlet weak var imgSeperator: UIImageView!
    @IBOutlet weak var txtUserDetail: UITextField!
    @IBOutlet weak var imgKey: UIImageView!
    
    override func awakeFromNib() {
        super.awakeFromNib()
        txtUserDetail.isSecureTextEntry = true
        DecorateControls.putText(textField: txtUserDetail, text: "", placehoder: "", font: UIFont.boldSystemFont(ofSize: FONT_SIZE_18), textColor: blackColor())
        imgSeperator.backgroundColor = UIColor.init(red: 165/255.0, green: 165/255.0, blue: 165/255.0, alpha: 1)
    }
    
    override func setSelected(_ selected: Bool, animated: Bool) {
        super.setSelected(selected, animated: animated)
        
        // Configure the view for the selected state
    }
    
}
