//
//  CustomTableViewCell.swift
//  NewSettings
//
//  Created by PujaDwivedi on 02/05/18.
//  Copyright © 2018 PujaDwivedi. All rights reserved.
//

import UIKit

protocol YourCellDelegate : class {
    func didPressButton(_ tag: Int)
}

class SettingsTableViewCell: UITableViewCell {
    
    @IBOutlet weak var switchButton: UISwitch!
    @IBOutlet weak var settingsButton: UIButton!
    @IBOutlet weak var settingsLabel: UILabel!
    
    weak var cellDelegate: YourCellDelegate?
    
    override func awakeFromNib() {
        super.awakeFromNib()
        
        DecorateControls.putTitle(button: settingsButton, text: "", font: UIFont.systemFont(ofSize: FONT_SIZE_18), textColor: blackColor(), backGroundColor: clearColor())
        DecorateControls.styleLabel(label: settingsLabel, text: "", font: UIFont.boldSystemFont(ofSize: FONT_SIZE_18), textColor: blackColor())
    }
    
    
    @IBAction func settingsBtnClicked(_ sender: UIButton) {
        cellDelegate?.didPressButton(sender.tag)
    }
    
    
    override func setSelected(_ selected: Bool, animated: Bool) {
        super.setSelected(selected, animated: animated)
        
        // Configure the view for the selected state
    }
    
}
