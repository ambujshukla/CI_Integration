//
//  ViewController.swift
//  NewSettings
//
//  Created by PujaDwivedi on 02/05/18.
//  Copyright © 2018 PujaDwivedi. All rights reserved.
//puja

import UIKit

class SettingsViewController: UIViewController , UITableViewDelegate , UITableViewDataSource , YourCellDelegate {
    
    @IBOutlet weak var switchBtn: UISwitch!
    var arrData = [["section" : "GENERAL" , "data" : [["lbl" : "GENERAL" ] , ["lbl" : "Push Notification" ],["lbl" : "About Us"],["lbl" : "Terms & Conditions"]]]]
    
    @IBOutlet weak var myTableView: UITableView!
    var settingsViewModel = SettingsViewModel()
    var userModel: UserModel = CommonUtility.userProfile()!

    override func viewDidLoad() {
        super.viewDidLoad()
        self.styleUI()
        self.styleNavigationBar()
    }
    
    func styleUI()
    {
        self.myTableView.tableFooterView = UIView()
    }
    
    func styleNavigationBar()
    {
        CommonUtility.createCustomBackButton(self, navBarItem: self.navigationItem, strImage: "menu_slide", select: #selector(doClickSideMenu))
        
        CommonUtility.setNavBarTitle(self.navigationItem, title: NSLocalizedString("title.settings", comment: "The title of the settings navigation bar"))
        
        CommonUtility.createRightBarHomeButtons(target: self, navigationItem: self.navigationItem, select1: #selector(openProfileView), select2: #selector(openDashBoardView))
        
    }
    
    @objc func openProfileView()
    {
     self.navigationController?.pushViewController((self.storyboard?.instantiateViewController(withIdentifier: "ProfileViewController"))!, animated: true)
      
    }
    
    @objc func openDashBoardView()
    {
        CommonUtility.setMenuSelectedOption(menuOptionIndex: 0)
        let centerVC : UIViewController
        let storyboard =  UIStoryboard(name: "Main", bundle: nil)
        centerVC = storyboard.instantiateViewController(withIdentifier: "DashboardViewController")
        let centerNavVC = UINavigationController(rootViewController: centerVC)
        self.panel?.configs.centerPanelTransitionType = .moveLeft
        self.panel?.configs.centerPanelTransitionDuration = 1.0
        _ = panel?.center(centerNavVC)
  
    }
    
    @objc func openNotificationsView()
    {
        self.navigationController?.pushViewController((self.storyboard?.instantiateViewController(withIdentifier: "NotificationsViewController"))!, animated: true)
    }
    
    @objc func openSettingsView()
    {
        self.navigationController?.pushViewController((self.storyboard?.instantiateViewController(withIdentifier: "SettingsViewController"))!, animated: true)
    }
    
    //MARK: - Navigation Bar Methods
    @objc func doClickSideMenu()
    {
        panel?.openLeft(animated: true)
    }
    
    func tableView(_ tableView: UITableView, heightForRowAt indexPath: IndexPath) -> CGFloat {
        return 75
    }
    
    func tableView(_ tableView: UITableView, numberOfRowsInSection section: Int) -> Int {
        return 4
    }
    
    
    func tableView(_ tableView: UITableView, heightForHeaderInSection section: Int) -> CGFloat {
        return 0
    }
    
    func tableView(_ tableView: UITableView, cellForRowAt indexPath: IndexPath) -> UITableViewCell {
        
        let cell = myTableView.dequeueReusableCell(withIdentifier: "cell") as! SettingsTableViewCell
        
        cell.cellDelegate = self
        cell.tag = indexPath.row
        
        let item : [String : Any] = arrData[indexPath.section]
        let itemValue : [[String : Any]] = item["data"] as! [[String : Any]]
        cell.settingsLabel.text = itemValue [indexPath.row]["lbl"] as? String
        cell.settingsButton.isHidden = true
        cell.switchButton.isHidden = false
        cell.settingsButton.setImage(UIImage.init(named: "right-arrow"), for: .normal)
        
        cell.settingsButton.isHidden = false
        cell.switchButton.isHidden = true
        if indexPath.row == 0 {
            DecorateControls.styleLabel(label: cell.settingsLabel, text: "", font: UIFont.boldSystemFont(ofSize: FONT_SIZE_24), textColor: blackColor())
            cell.settingsButton.isHidden = true
            cell.switchButton.isHidden = true
            cell.settingsLabel.text = itemValue [indexPath.row]["lbl"] as? String
        }
        else if indexPath.row == 1{
            DecorateControls.styleLabel(label: cell.settingsLabel, text: "", font: UIFont.boldSystemFont(ofSize: FONT_SIZE_18), textColor: blackColor())
            cell.settingsButton.isHidden = true
            cell.switchButton.isHidden = false
            cell.settingsLabel.text = itemValue [indexPath.row]["lbl"] as? String
            cell.switchButton.addTarget(self, action: #selector(switchValueDidChange(sender:)), for: .valueChanged)
            cell.switchButton.isOn = UserDefaults.standard.value(forKey: UserdefaultsKey.isPushEnabled.rawValue)! as! Bool
        } else {
            DecorateControls.styleLabel(label: cell.settingsLabel, text: "", font: UIFont.boldSystemFont(ofSize: FONT_SIZE_17), textColor: blackColor())
            cell.settingsLabel.text = itemValue [indexPath.row]["lbl"] as? String
        }
        cell.selectionStyle = .none
        return cell
    }
    
    
    func didPressButton(_ tag: Int) {
        self.navigationController?.pushViewController((self.storyboard?.instantiateViewController(withIdentifier: "WebViewController"))!, animated: true)
    }
    
    @objc func switchValueDidChange(sender:UISwitch!)
    {
        self.settingsViewModel.pushNotificationValue = sender.isOn
        self.settingsViewModel.enableDisablePush(completion: {
            self.userModel.result.push_notification = sender.isOn ? "1" : "2"
            UserDefaults.standard.set(sender.isOn, forKey: UserdefaultsKey.isPushEnabled.rawValue)
           // UserDefaults.standard.set(self.userModel, forKey:UserdefaultsKey.userData.rawValue)
        }) { (error) in
            
        }
    }
    
    func tableView(_ tableView: UITableView, didSelectRowAt indexPath: IndexPath) {
        if indexPath.row == 2 || indexPath.row == 3
        {
            if indexPath.row == 2 {
                let pushVc = self.storyboard?.instantiateViewController(withIdentifier: "WebViewController") as! WebViewController
                pushVc.isTitleText = true
                self.navigationController?.pushViewController(pushVc, animated: true)
            }
            else {
                self.navigationController?.pushViewController((self.storyboard?.instantiateViewController(withIdentifier: "WebViewController"))!, animated: true)
            }
        }
    }
    
}

