
//
//  ViewController.swift
//  NewProfile
//
//  Created by PujaDwivedi on 02/05/18.
//  Copyright © 2018 PujaDwivedi. All rights reserved.
//puja

import UIKit
import FAPanels
import ActionSheetPicker_3_0

class SetGoalsViewController1: UIViewController , UIImagePickerControllerDelegate , UINavigationControllerDelegate {
    
   
    @IBOutlet weak var btnDob: UIButton!
    @IBOutlet weak var btnAge: UIButton!
    @IBOutlet weak var txtFldMedicalCondn: UITextField!
    @IBOutlet weak var firstNameText: UITextField!
    @IBOutlet weak var goal1Btn: UIButton!
    @IBOutlet weak var goal2ImgBtn: UIButton!
    @IBOutlet weak var goal1ImgBtn: UIButton!
    @IBOutlet weak var goal2Btn: UIButton!
    @IBOutlet weak var ageText: UITextField!
    @IBOutlet weak var dobText: UITextField!
    @IBOutlet weak var lastNameText: UITextField!
    @IBOutlet weak var goal2Label: UILabel!
    @IBOutlet weak var goal1Label: UILabel!
    @IBOutlet weak var ageLabel: UILabel!
    @IBOutlet weak var medicalLabel: UILabel!
    @IBOutlet weak var dobLabel: UILabel!
    @IBOutlet weak var lastNameLabel: UILabel!
    @IBOutlet weak var firstNameLabel: UILabel!
    @IBOutlet weak var goalLabel: UILabel!
    @IBOutlet weak var profileImage: UIImageView!
    @IBOutlet weak var welcomeLbl: UILabel!
    @IBOutlet weak var backgrndImage: UIImageView!
    @IBOutlet weak var saveButton: UIButton!
    @IBOutlet fileprivate weak var btnBack : UIButton!

    var ageSelectionIndex = 0
    var goal1SelectionIndex = 0
    var goal2SelectionIndex = 0
    var max = Date()
    
    var arrAge = ["18", "19", "20","21","22","23","24","25","26", "27", "28","29","30","31","32","33","34", "35", "36","37","38","39","40","41","42", "43", "44","45","46","47","48","49","50", "51", "52","53","54","55","56","57","58", "59", "60","61","62","63","64","65","66", "67", "68","69","70","71","72","73","74", "75", "76","77","78","79","80","81","82", "83", "84","85","86","87","88","89","90", "91", "92","93","94","95","96","97","98", "99"]
    
      var arrGoals = ["Muscle Strength", "Weight Loss", "Tall Height"]
    
    let imagePicker = UIImagePickerController()
    
    //MARK: - Life cycle
    override func viewDidLoad() {
        super.viewDidLoad()
        self.styleUI()
    }
    
    func styleUI()
    {
        backgrndImage.image = #imageLiteral(resourceName: "background_img")
        DecorateControls.styleLabel(label: welcomeLbl, text: "Welcome to Pilates Patients!", font: UIFont.systemFont(ofSize: FONT_SIZE_32), textColor: blackColor())
        profileImage.image = #imageLiteral(resourceName: "bubel_user")
        DecorateControls.putTitle(button: saveButton, text: "Save", font: UIFont.boldSystemFont(ofSize: FONT_SIZE_23), textColor: whiteColor(), backGroundColor: appColor())
        saveButton.layer.cornerRadius = 5
        
        DecorateControls.putText(textField: firstNameText, text: "", placehoder: "First Name", font: UIFont.boldSystemFont(ofSize: FONT_SIZE_16), textColor: color(red: 172, green: 172, blue: 172))
        DecorateControls.putText(textField: lastNameText, text: "", placehoder: "Last Name", font: UIFont.boldSystemFont(ofSize: FONT_SIZE_16), textColor: color(red: 172, green: 172, blue: 172))
        DecorateControls.putText(textField: dobText, text: "", placehoder: "D.O.B", font: UIFont.boldSystemFont(ofSize: FONT_SIZE_16), textColor: color(red: 172, green: 172, blue: 172))
        DecorateControls.putText(textField: ageText, text: "", placehoder: "Age", font: UIFont.boldSystemFont(ofSize: FONT_SIZE_16), textColor: color(red: 172, green: 172, blue: 172))
        DecorateControls.styleLabel(label: firstNameLabel, text: "First Name", font: UIFont.boldSystemFont(ofSize: FONT_SIZE_16), textColor: blackColor())
        DecorateControls.styleLabel(label: lastNameLabel, text: "Last Name", font: UIFont.boldSystemFont(ofSize: FONT_SIZE_16), textColor: blackColor())
        DecorateControls.styleLabel(label: ageLabel, text: "Age", font: UIFont.boldSystemFont(ofSize: FONT_SIZE_16), textColor: blackColor())
        DecorateControls.styleLabel(label: dobLabel, text: "D.O.B", font: UIFont.boldSystemFont(ofSize: FONT_SIZE_16), textColor: blackColor())
        DecorateControls.styleLabel(label: medicalLabel, text: "Medical Condition (If Any)", font: UIFont.boldSystemFont(ofSize: FONT_SIZE_16), textColor: blackColor())
        DecorateControls.styleLabel(label: goal1Label, text: "Goal", font: UIFont.boldSystemFont(ofSize: FONT_SIZE_16), textColor: blackColor())
        DecorateControls.styleLabel(label: goal2Label, text: "Goal", font: UIFont.boldSystemFont(ofSize: FONT_SIZE_16), textColor: blackColor())
        DecorateControls.styleLabel(label: goalLabel, text: "Goal", font: UIFont.boldSystemFont(ofSize: FONT_SIZE_32), textColor: blackColor())
        DecorateControls.putTitle(button: goal1Btn, text: "Goal 1", font: UIFont.boldSystemFont(ofSize: FONT_SIZE_16), textColor: color(red: 172  , green: 172, blue: 172), backGroundColor: clearColor())
        DecorateControls.putTitle(button: goal2Btn, text: "Goal 2", font:  UIFont.boldSystemFont(ofSize: FONT_SIZE_16), textColor: color(red: 172  , green: 172, blue: 172), backGroundColor: clearColor())
        DecorateControls.putTitle(button: btnAge, text: "Age", font:  UIFont.boldSystemFont(ofSize: FONT_SIZE_16), textColor: color(red: 172  , green: 172, blue: 172), backGroundColor: clearColor())
        DecorateControls.putTitle(button: btnDob, text: "D.O.B", font:  UIFont.boldSystemFont(ofSize: FONT_SIZE_16), textColor: color(red: 172  , green: 172, blue: 172), backGroundColor: clearColor())
         DecorateControls.putText(textField: txtFldMedicalCondn, text: "", placehoder: "", font: UIFont.boldSystemFont(ofSize: FONT_SIZE_16), textColor: color(red: 172, green: 172, blue: 172))
        goal1ImgBtn.setImage(#imageLiteral(resourceName: "drop_arrow"), for: .normal)
        goal2ImgBtn.setImage(#imageLiteral(resourceName: "drop_arrow"), for: .normal)
        self.btnBack.setImage(#imageLiteral(resourceName: "back_icon"), for: .normal)
        
        let tapG = UITapGestureRecognizer.init(target: self, action: #selector(self.profileImageClicked(sender:)))
        tapG.numberOfTapsRequired = 1
        self.profileImage.isUserInteractionEnabled = true
        self.profileImage.addGestureRecognizer(tapG)
        self.imagePicker.delegate = self
    }
    
    @objc func profileImageClicked(sender: UITapGestureRecognizer? = nil){
        if UIImagePickerController.isSourceTypeAvailable(UIImagePickerControllerSourceType.photoLibrary){
            print("Button capture")
            
            self.imagePicker.sourceType = UIImagePickerControllerSourceType.photoLibrary;
           // self.imagePicker.sourceType = .camera;
           // self.imagePicker.sourceType = .savedPhotosAlbum;
            self.imagePicker.allowsEditing = true
            self.present(self.imagePicker, animated: true, completion: nil)
            self.imagePicker.modalPresentationStyle = .overCurrentContext
        }
    }
    
    
    func imagePickerController(_ picker: UIImagePickerController, didFinishPickingMediaWithInfo info: [String : Any]) {
        let chosenImage = info[UIImagePickerControllerOriginalImage] as! UIImage //2
        let selectedImage : UIImage = chosenImage
        profileImage.image=selectedImage
        self.dismiss(animated: true, completion: nil)
    }
    func imagePickerControllerDidCancel(_ picker: UIImagePickerController) {
         self.dismiss(animated: true, completion: nil)
    }
    
    
    
    @IBAction func btnDobActn(_ sender: UIButton) {
        let datePicker = ActionSheetDatePicker(title: "Date:", datePickerMode: UIDatePickerMode.date, selectedDate: max, doneBlock: {
            picker, value, index in

            let dateFormatter = DateFormatter()
            dateFormatter.dateFormat = "MM/dd/yyyy"
            let selectedDate = dateFormatter.string(from: value as! Date)
            print(selectedDate)
            
            
            self.max = dateFormatter.date(from: selectedDate)!
            
            
            
            self.btnDob.setTitle(selectedDate , for: .normal)
            return
        }, cancel: { ActionStringCancelBlock in return }, origin: sender )
        let secondsInWeek: TimeInterval = 1 * 365 * 24 * 60 * 60;
        datePicker?.minimumDate = Date(timeInterval: -18 * secondsInWeek, since: Date())
        datePicker?.maximumDate = Date(timeInterval: secondsInWeek, since: Date())

        datePicker?.show()
    

   }
    
    @IBAction func saveAndContinue(sender : UIButton!)
    {
        let mainStoryboard: UIStoryboard = UIStoryboard(name: "Main", bundle: nil)
        
        let leftMenuVC: MenuViewController = mainStoryboard.instantiateViewController(withIdentifier: "MenuViewController") as! MenuViewController
        let centerVC : UIViewController
        if CommonUtility.isPilate() {
            let storyboard =  UIStoryboard(name: "Pilates", bundle: nil)
            centerVC = storyboard.instantiateViewController(withIdentifier: "PilatesDashboardViewController")
        }else{
            centerVC = mainStoryboard.instantiateViewController(withIdentifier: "DashboardViewController")
        }
        let centerNavVC = UINavigationController(rootViewController: centerVC)
        //  Set the Panel controllers with just two lines of code
        let panelVC = FAPanelController()
        panelVC.configs.leftPanelWidth = kLeftPanelWidth
        panelVC.leftPanelPosition = .front
        
        _ = panelVC.center(centerNavVC).left(leftMenuVC)
        
        UIView.transition(from: self.view, to: centerVC.view, duration: 0.0, options: UIViewAnimationOptions.transitionCrossDissolve) { (finished) in
            _ = panelVC.center(centerNavVC).left(leftMenuVC); UIApplication.shared.keyWindow?.rootViewController = panelVC
        }
    }
    
    @IBAction func btnGoalActn(_ sender: Any) {
        
        ActionSheetStringPicker.show(withTitle: "Set Goal", rows: arrGoals, initialSelection: goal2SelectionIndex, doneBlock: {
            picker, value, index in
            
            let indexx = index

            self.goal2Btn.setTitle(indexx as? String, for: .normal)
            
            self.goal2SelectionIndex = value
            
            return
        }, cancel: { ActionStringCancelBlock in return }, origin: sender)
    }
    
    @IBAction func btnGoal1Actn(_ sender: UIButton) {
        
        ActionSheetStringPicker.show(withTitle: "Set Goal", rows: arrGoals, initialSelection: goal1SelectionIndex, doneBlock: {
                picker, value, index in
            
             let indexx = index
            self.goal1Btn.setTitle(indexx as? String, for: .normal)
            
            self.goal1SelectionIndex = value
            
            return
            }, cancel: { ActionStringCancelBlock in return }, origin: sender)
        }
   
    @IBAction func btnAgeActn(_ sender: UIButton) {
        
        ActionSheetStringPicker.show(withTitle: "Set Age", rows: arrAge, initialSelection: ageSelectionIndex, doneBlock: {
            picker, value, index in
            
            
            
            let indexx = index
            self.btnAge.setTitle(indexx as? String, for: .normal)
            
            self.ageSelectionIndex = value
            
            return
        }, cancel: { ActionStringCancelBlock in return }, origin: sender)
    }
    
    override func viewWillLayoutSubviews() {
        super.viewWillLayoutSubviews()
        
        self.profileImage.layer.borderWidth = 1
        self.profileImage.layer.masksToBounds = true
        self.profileImage.layer.borderColor = UIColor.lightGray.cgColor
        self.profileImage.layer.cornerRadius = profileImage.frame.width/2
        profileImage.clipsToBounds = true
        
    }
    
    @IBAction func doClickBack(sender : UIButton){
        self.navigationController?.popViewController(animated: true)
    }
}

