//
//  ViewController.swift
//  NewProfile
//
//  Created by PujaDwivedi on 02/05/18.
//  Copyright © 2018 PujaDwivedi. All rights reserved.
//

import UIKit
import FAPanels
import ActionSheetPicker_3_0

private let kInitialSelectedValue = 0

class SetGoalsViewController: UIViewController , UINavigationControllerDelegate , UIImagePickerControllerDelegate {
    
    @IBOutlet weak var goal1Btn: UIButton!
    @IBOutlet weak var medTxtFld2: UITextField!
    @IBOutlet weak var medTxtFld1: UITextField!
    @IBOutlet weak var goal2BTN: UIButton!
    @IBOutlet weak var btnHeight: UIButton!
    @IBOutlet weak var btnWeight: UIButton!
    @IBOutlet weak var btnAge: UIButton!
    @IBOutlet weak var btnBack: UIButton!
    @IBOutlet weak var txtHeight: UITextField!
    @IBOutlet weak var txtWeight: UITextField!
    @IBOutlet weak var txtAge: UITextField!
    @IBOutlet weak var lblHeight: UILabel!
    @IBOutlet weak var lblWeight: UILabel!
    @IBOutlet weak var lblAge: UILabel!
    @IBOutlet weak var lblMedical: UILabel!
    @IBOutlet weak var medicalBtn2: UIButton!
    @IBOutlet weak var medicalBtn1: UIButton!
    @IBOutlet weak var goal2Txt: UITextField!
    @IBOutlet weak var goal1Txt: UITextField!
    @IBOutlet weak var goal2ImgBtn: UIButton!
    @IBOutlet weak var goal1ImgBtn: UIButton!
    @IBOutlet weak var ageLabel: UILabel!
    @IBOutlet weak var goalLabel: UILabel!
    @IBOutlet weak var profileImage: UIImageView!
    @IBOutlet weak var welcomeLbl: UILabel!
    @IBOutlet weak var backgrndImage: UIImageView!
    @IBOutlet weak var saveButton: UIButton!
    
    let imagePicker = UIImagePickerController()
    
    var heightSelectionIndex0 = kInitialSelectedValue
    var heightSelectionIndex1 = kInitialSelectedValue
    var weightSelectionIndex = kInitialSelectedValue
    var goal1SelectionIndex = kInitialSelectedValue
    var goal2SelectionIndex = kInitialSelectedValue
    var ageSelectionIndex = kInitialSelectedValue
    var medicalSelectionIndex0 = kInitialSelectedValue
    var medicalSelectionIndex1 = kInitialSelectedValue
    var max = Date()
    
    var arrGoals = ["Weight Loss"]
    
    var arrWeight = ["30 kgs","31 kgs","32 kgs","33 kgs","34 kgs","35 kgs" ,"36 kgs","37 kgs","38 kgs","39 kgs","40 kgs","41 kgs","42 kgs","43 kgs","44 kgs","45 kgs" ,"46 kgs","47 kgs","48 kgs","49 kgs","50 kgs","51 kgs","52 kgs","53 kgs","54 kgs","55 kgs" ,"56 kgs","57 kgs","58 kgs","59 kgs","60 kgs","61 kgs","62 kgs","63 kgs","64 kgs","65 kgs" ,"66 kgs","67 kgs","68 kgs","69 kgs","70 kgs","71 kgs","72 kgs","73 kgs","74 kgs","75 kgs" ,"76 kgs","77 kgs","78 kgs","79 kgs","80 kgs","81 kgs","82 kgs","83 kgs","84 kgs","85 kgs" ,"86 kgs","87 kgs","88 kgs","89 kgs","90 kgs","91 kgs","92 kgs","93 kgs","94 kgs","95 kgs" ,"96 kgs","97 kgs","98 kgs","99 kgs","100 kgs","101 kgs","102 kgs","103 kgs","104 kgs","105 kgs" ,"106 kgs","107 kgs","108 kgs","109 kgs","110 kgs","111 kgs","112 kgs","113 kgs","114 kgs","115 kgs" ,"116 kgs","117 kgs","118 kgs","119 kgs","120 kgs"]
    
    var arrGoalWeight = ["40 kgs","45 kgs","50 kgs","55 kgs","60 kgs","65 kgs","70 kgs","75 kgs","80 kgs"]
    var arrHeight =  [
        ["2 ft", "3 ft", "4 ft", "5 ft" , "6 ft", "7 ft" ,"8 ft" ,"9 ft", "10 ft"],
        ["0 in"," 1 in","2 in", "3 in", "4 in", "5 in" , "6 in", "7 in" ,"8 in" ,"9 in", "10 in" ,"11 in","12 in"]
    ]
    
    var arrAge = ["18", "19", "20","21","22","23","24","25","26", "27", "28","29","30","31","32","33","34", "35", "36","37","38","39","40","41","42", "43", "44","45","46","47","48","49","50", "51", "52","53","54","55","56","57","58", "59", "60","61","62","63","64","65","66", "67", "68","69","70","71","72","73","74", "75", "76","77","78","79","80","81","82", "83", "84","85","86","87","88","89","90", "91", "92","93","94","95","96","97","98", "99"]
    
    var arrMedi1 = ["Yes" , "No"]
    
    var arrMedi2 = ["Mental Stress","Mentally Disturbed","Mentally Sick","Mentally Retarded","Mentally Weak"]
    
    var setGoalsViewModel = SetGoalsViewModel()

    override func viewDidLoad() {
        super.viewDidLoad()
        self.styleUI()
        self.populateUserData()
    }
    
    func styleUI() {
        profileImage.image = #imageLiteral(resourceName: "bubel_user")
        backgrndImage.image = #imageLiteral(resourceName: "background_img")
        btnBack.isHidden = true
        goal1ImgBtn.setImage(#imageLiteral(resourceName: "drop_arrow"), for: .normal)
        goal2ImgBtn.setImage(#imageLiteral(resourceName: "drop_arrow"), for: .normal)
        
        DecorateControls.styleLabel(label: welcomeLbl, text: "Welcome to Pilates Patients!", font: UIFont.systemFont(ofSize: 34), textColor: blackColor())
        DecorateControls.styleLabel(label: goalLabel, text: "What are your goals ?", font: UIFont.systemFont(ofSize: 34), textColor: blackColor())
        DecorateControls.putTitle(button: saveButton, text: "Save & Continue", font: UIFont.boldSystemFont(ofSize: 28), textColor: whiteColor(), backGroundColor: appColor())
        saveButton.layer.cornerRadius = 5
        DecorateControls.styleLabel(label: lblAge, text: "What is your Date of Birth?", font: UIFont.boldSystemFont(ofSize: FONT_SIZE_18), textColor: blackColor())
        DecorateControls.styleLabel(label: lblWeight, text: "What is your Weight?", font: UIFont.boldSystemFont(ofSize: FONT_SIZE_18), textColor: blackColor())
        DecorateControls.styleLabel(label: lblHeight, text: "What is your Height?", font: UIFont.boldSystemFont(ofSize: FONT_SIZE_18), textColor: blackColor())
        DecorateControls.styleLabel(label: ageLabel, text: "What are you looking for, from this application?", font: UIFont.boldSystemFont(ofSize: FONT_SIZE_18), textColor: blackColor())
        DecorateControls.styleLabel(label: lblMedical, text: "Do you have any Medical Condition?", font: UIFont.boldSystemFont(ofSize: FONT_SIZE_18), textColor: blackColor())
        DecorateControls.putTitle(button: btnAge, text: "Enter D.O.B", font:  UIFont.boldSystemFont(ofSize: FONT_SIZE_18), textColor: color(red: 172  , green: 172, blue: 172), backGroundColor: clearColor())
        DecorateControls.putTitle(button: btnWeight, text: "Enter Weight", font:  UIFont.boldSystemFont(ofSize: FONT_SIZE_18), textColor: color(red: 172  , green: 172, blue: 172), backGroundColor: clearColor())
        DecorateControls.putTitle(button: btnHeight, text: "Enter Height", font:  UIFont.boldSystemFont(ofSize: FONT_SIZE_18), textColor: color(red: 172  , green: 172, blue: 172), backGroundColor: clearColor())
        DecorateControls.putTitle(button: goal1Btn, text: "Goal 1", font:  UIFont.boldSystemFont(ofSize: FONT_SIZE_18), textColor: color(red: 172  , green: 172, blue: 172), backGroundColor: clearColor())
        DecorateControls.putTitle(button: goal2BTN, text: "Target", font:  UIFont.boldSystemFont(ofSize: FONT_SIZE_18), textColor: color(red: 172  , green: 172, blue: 172), backGroundColor: clearColor())
        DecorateControls.putText(textField: medTxtFld1, text: "", placehoder: "Yes (Mention below)", font: UIFont.boldSystemFont(ofSize: FONT_SIZE_18), textColor: color(red: 172, green: 172, blue: 172))
        DecorateControls.putText(textField: medTxtFld2, text: "", placehoder: "Select or Enter manually", font: UIFont.boldSystemFont(ofSize: FONT_SIZE_18), textColor: color(red: 172, green: 172, blue: 172))
        
        let tapG = UITapGestureRecognizer.init(target: self, action: #selector(self.profileImageClicked(sender:)))
        tapG.numberOfTapsRequired = 1
        self.profileImage.isUserInteractionEnabled = true
        self.profileImage.addGestureRecognizer(tapG)
        self.imagePicker.delegate = self
    }
    
    func populateUserData() {
        if let userModel = CommonUtility.userProfile() {
            self.btnWeight.setTitle(userModel.result.weight, for: .normal)
            self.btnHeight.setTitle(userModel.result.height, for: .normal)
            self.medTxtFld1.text = userModel.result.medical_history
            if let goals = userModel.result.goals {
                let arrGoals = goals.components(separatedBy: ",")
                if (arrGoals.count) > 0 {
                    self.goal1Btn.setTitle(arrGoals[0], for: .normal)
                }
                if (arrGoals.count) > 1 {
                    self.goal2BTN.setTitle(arrGoals[1], for: .normal)
                }
            }
        }
    }
    
    @objc func profileImageClicked(sender: UITapGestureRecognizer? = nil){
        let alert : UIAlertController = UIAlertController(title: "Choose Image", message: nil, preferredStyle: UIAlertControllerStyle.actionSheet)
        
        let cameraAction = UIAlertAction(title: "Camera", style: UIAlertActionStyle.default)
        {
            UIAlertAction in
            self.openCamera()
        }
        let gallaryAction = UIAlertAction(title: "Gallery", style: UIAlertActionStyle.default)
        {
            UIAlertAction in
            self.openGallary()
        }
        let cancelAction = UIAlertAction(title: "Cancel", style: UIAlertActionStyle.cancel)
        {
            UIAlertAction in
        }
        
        self.imagePicker.modalPresentationStyle = .overCurrentContext
        alert.addAction(cameraAction)
        alert.addAction(gallaryAction)
        alert.addAction(cancelAction)
        if let popoverController = alert.popoverPresentationController {
            popoverController.sourceView = self.profileImage
            popoverController.sourceRect = self.profileImage.bounds
        }
        self.present(alert, animated: true, completion: nil)
    }
    
    func openCamera()
    {
        if(UIImagePickerController .isSourceTypeAvailable(UIImagePickerControllerSourceType.camera))
        {
            imagePicker.sourceType = .camera
            self .present(imagePicker, animated: true, completion: nil)
        }
        else
        {
            let alert = UIAlertController(title: "Warning", message: "You don't have camera", preferredStyle: UIAlertControllerStyle.alert)
            alert.addAction(UIAlertAction(title: "Ok", style: UIAlertActionStyle.default, handler: nil))
            self.present(alert, animated: true, completion: nil)
        }
    }
    func openGallary()
    {
        imagePicker.sourceType = .savedPhotosAlbum
        self.present(imagePicker, animated: true, completion: nil)
    }
    
    func imagePickerController(_ picker: UIImagePickerController, didFinishPickingMediaWithInfo info: [String : Any]) {
        let chosenImage = info[UIImagePickerControllerOriginalImage] as! UIImage //2
        let selectedImage : UIImage = chosenImage
        profileImage.image=selectedImage
        self.dismiss(animated: true, completion: nil)
    }
    
    func imagePickerControllerDidCancel(_ picker: UIImagePickerController) {
        self.dismiss(animated: true, completion: nil)
    }
    
    @IBAction func save(_ sender: UIButton) {
        if self.setGoalsViewModel.validate() {
            let apiManager = APIManager()
            var parameters = [String : Any]()
            parameters["dob"] = self.btnAge.titleLabel?.text
            parameters["weight"] = self.btnWeight.titleLabel?.text
            parameters["height"] = self.btnHeight.titleLabel?.text
            parameters["goals"] = "\(self.goal1Btn.titleLabel?.text! ?? "goals"),\(self.goal2BTN.titleLabel?.text! ?? "goals1")"
            parameters["medical_history"] = self.medTxtFld1.text
            parameters["firstname"] = self.setGoalsViewModel.firstname
            parameters["lastname"] = self.setGoalsViewModel.lastname
            parameters["address"] = self.setGoalsViewModel.address

            let image = self.profileImage.image
            
            apiManager.uploadImageWithParameters(url: "https://www.cdnsolutionsgroup.com/ppl/ws/patient/profile_update", parameters: parameters, image: image!, completion: { (responseData) in
                if let jsonObject : [String : Any] = responseData.result.value as? [String : Any]{
                    let statusCode = jsonObject["result_code"] as! Bool
                    if statusCode {
                        do {
                            if let data = responseData.data {
                                let decoder = JSONDecoder()
                                let userModel = try decoder.decode(UserModel.self, from: data)
                                UserDefaults.standard.set(try? PropertyListEncoder().encode(userModel), forKey:UserdefaultsKey.userData.rawValue)
                                CommonUtility.showSuccessCRNotifications(title: appTitle(), message: NSLocalizedString("title.success.profile.update", comment: "This message will be shown once the profile being updated successfully."))
                                self.navigateToDashboard()
                            }
                        } catch  {
                            CommonUtility.showErrorCRNotifications(title: NSLocalizedString("title.error.occur", comment: "Error is shown when the json is unable to decode"), message: jsonObject["message"] as! String)
                        }
                    }else {
                        CommonUtility.showErrorCRNotifications(title: appTitle(), message: jsonObject["message"] as! String)
                    }
                }
            }) { (error) in
                CommonUtility.showErrorCRNotifications(title: appTitle(), message: (error?.localizedDescription)!)
            }
        }
    }
    
    func navigateToDashboard()
    {
        let mainStoryboard: UIStoryboard = UIStoryboard(name: "Main", bundle: nil)
        let leftMenuVC: MenuViewController = mainStoryboard.instantiateViewController(withIdentifier: "MenuViewController") as! MenuViewController
        let centerVC : UIViewController
        if CommonUtility.isPilate() {
            let storyboard =  UIStoryboard(name: "Pilates", bundle: nil)
            centerVC = storyboard.instantiateViewController(withIdentifier: "PilatesDashboardViewController")
        }else{
            centerVC = mainStoryboard.instantiateViewController(withIdentifier: "DashboardViewController")
        }
        let centerNavVC = UINavigationController(rootViewController: centerVC)
        //  Set the Panel controllers with just two lines of code
        let panelVC = FAPanelController()
        panelVC.configs.leftPanelWidth = kLeftPanelWidth
        panelVC.leftPanelPosition = .front
        
        _ = panelVC.center(centerNavVC).left(leftMenuVC)
        
        UIView.transition(from: self.view, to: centerVC.view, duration: 0.0, options: UIViewAnimationOptions.transitionCrossDissolve) { (finished) in
            _ = panelVC.center(centerNavVC).left(leftMenuVC); UIApplication.shared.keyWindow?.rootViewController = panelVC
        }
    }
    
    @IBAction func btnAgeClicked(_ sender: UIButton) {
        let datePicker = ActionSheetDatePicker(title: "Date of Birth", datePickerMode: UIDatePickerMode.date, selectedDate: max, doneBlock: {
            picker, value, index in
            let dateFormatter = DateFormatter()
            dateFormatter.dateFormat = "dd-MM-yyyy"
            let selectedDate = dateFormatter.string(from: value as! Date)
            print(selectedDate)
            self.max = dateFormatter.date(from: selectedDate)!
            self.btnAge.setTitle(selectedDate , for: .normal)
            self.setGoalsViewModel.dob = selectedDate
            return
        }, cancel: { ActionStringCancelBlock in return }, origin: sender)
        let secondsInWeek: TimeInterval = 1 * 365 * 24 * 60 * 60;
        datePicker?.minimumDate = Date(timeInterval: -80*secondsInWeek, since: Date())
        datePicker?.maximumDate = Date()
        datePicker?.show()
    }
    
    @IBAction func btnWeightClicked(_ sender: UIButton) {
        ActionSheetStringPicker.show(withTitle: "Weight", rows: arrWeight, initialSelection: weightSelectionIndex, doneBlock: {
            picker, value, index in
            let indexx = index
            self.btnWeight.setTitle(indexx as? String, for: .normal)
            self.weightSelectionIndex = value
            self.setGoalsViewModel.weight = (indexx as? String)!
            return
        }, cancel: { ActionStringCancelBlock in return }, origin: sender)
    }
    
    @IBAction func btnHeightClicked(_ sender: UIButton) {
        ActionSheetMultipleStringPicker.show(withTitle: "Height", rows: arrHeight, initialSelection: [heightSelectionIndex0 , heightSelectionIndex1], doneBlock: {
            picker , values , indexes in
            var heightValues = indexes as! [String]
            self.btnHeight.setTitle("\(heightValues[0]) \(heightValues[1])", for: .normal)
            self.setGoalsViewModel.height = "\(heightValues[0]) \(heightValues[1])"
            let  selectn0 = values![0]
            let selectn1 = values![1]
            self.heightSelectionIndex0 = (selectn0 as? Int)!
            self.heightSelectionIndex1 = (selectn1 as? Int)!
            return
        }, cancel: { ActionMultipleStringCancelBlock in return }, origin: sender)
    }
    
    @IBAction func goal1BtnClicked(_ sender: UIButton) {
        ActionSheetStringPicker.show(withTitle: "Set Goal", rows: arrGoals, initialSelection: goal1SelectionIndex, doneBlock: {
            picker, value, index in
            let indexx = index
            self.goal1Btn.setTitle(indexx as? String, for: .normal)
            self.goal1SelectionIndex = value
            return
        }, cancel: { ActionStringCancelBlock in return }, origin: sender)
    }
    
    @IBAction func goal2BtnClicked(_ sender: UIButton) {
        ActionSheetStringPicker.show(withTitle: "Target", rows: arrGoalWeight, initialSelection: goal2SelectionIndex, doneBlock: {
            picker, value, index in
            let indexx = index
            self.goal2BTN.setTitle(indexx as? String, for: .normal)
            self.goal2SelectionIndex = value
            return
        }, cancel: { ActionStringCancelBlock in return }, origin: sender)
    }
    
    @IBAction func btn1MediClicked(_ sender: UIButton) {
        ActionSheetStringPicker.show(withTitle: "Select", rows: arrMedi1, initialSelection: medicalSelectionIndex0, doneBlock: {
            picker, value, index in
            let indexx = index
            self.medTxtFld1.text = indexx as? String
            self.medicalSelectionIndex0 = value
            return
        }, cancel: { ActionStringCancelBlock in return }, origin: sender)
    }
    
    @IBAction func btn2MediClicked(_ sender: UIButton) {
        ActionSheetStringPicker.show(withTitle: "Select", rows: arrMedi2, initialSelection: medicalSelectionIndex0, doneBlock: {
            picker, value, index in
            let indexx = index
            self.medTxtFld2.text = indexx as? String
            self.medicalSelectionIndex0 = value
            self.medicalSelectionIndex1 = value
            return
        }, cancel: { ActionStringCancelBlock in return }, origin: sender)
    }
    
    override func viewWillLayoutSubviews() {
        super.viewWillLayoutSubviews()
        self.profileImage.layer.borderWidth = 1
        self.profileImage.layer.masksToBounds = true
        self.profileImage.layer.borderColor = UIColor.lightGray.cgColor
        self.profileImage.layer.cornerRadius = profileImage.frame.width/2
        profileImage.clipsToBounds = true
    }
    
    @IBAction func backBtnClicked(_ sender: UIButton) {
        self.navigationController?.popViewController(animated: true)
    }
    
    override func touchesBegan(_ touches: Set<UITouch>, with event: UIEvent?) {
        self.view.endEditing(true)
    }
}

