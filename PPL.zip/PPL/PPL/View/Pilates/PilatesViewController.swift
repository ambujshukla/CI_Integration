//
//  ViewController.swift
//  Pilates2
//
//  Created by PujaDwivedi on 27/04/18.
//  Copyright © 2018 PujaDwivedi. All rights reserved.
//

import UIKit
import EmptyDataSet_Swift

class PilatesViewController: UIViewController, UICollectionViewDelegateFlowLayout {
    
    @IBOutlet weak var applyButton: UIButton!
    @IBOutlet weak var tblViewFilter: UITableView!
    @IBOutlet weak var view3: UIView!
    @IBOutlet weak var view2: UIView!
    @IBOutlet weak var view1: UIView!
    @IBOutlet weak var collectionView: UICollectionView!
    @IBOutlet weak var btnSearch: UIButton!
    @IBOutlet weak var txtSearch: UITextField!
    @IBOutlet weak var sortLabel: UILabel!
    @IBOutlet weak var searchTxt: UITextField!
    @IBOutlet weak var filteredCollectionView: UICollectionView!
    @IBOutlet weak var searchImage: UIImageView!
    @IBOutlet weak var filterButton: UIButton!
    
    var data = ["Location" , "Name" , "Expertise" ,"Experience"]
    var selectedRows:[IndexPath] = []
    var pilateViewModel = PilateListViewModel()
    
    var dict = [["image": "user" , "name" : "Ken Adams" , "qual" : ":  Ph.D,BPT" , "expert" : ":  Ankle , Shoulder Sprains" , "experience" : ":  12 Years", "lbll1" : "Qualification" , "lbl2" : "Expertise" , "lbl3" : "Experience"],["image": "user" , "name" : "Ken Adams" , "qual" : ":  Ph.D,BPT" , "expert" : ":  Ankle , Shoulder Sprains" , "experience" : ":  12 Years", "lbll1" : "Qualification" , "lbl2" : "Expertise" , "lbl3" : "Experience"],["image": "user" , "name" : "Ken Adams" , "qual" : ":  Ph.D,BPT" , "expert" : ":  Ankle , Shoulder Sprains" , "experience" : ":  12 Years", "lbll1" : "Qualification" , "lbl2" : "Expertise" , "lbl3" : "Experience"],["image": "user" , "name" : "Ken Adams" , "qual" : ":  Ph.D,BPT" , "expert" : ":  Ankle , Shoulder Sprains" , "experience" : ":  12 Years", "lbll1" : "Qualification" , "lbl2" : "Expertise" , "lbl3" : "Experience"],["image": "user" , "name" : "Ken Adams" , "qual" : ":  Ph.D,BPT" , "expert" : ":  Ankle , Shoulder Sprains" , "experience" : ":  12 Years", "lbll1" : "Qualification" , "lbl2" : "Expertise" , "lbl3" : "Experience"],["image": "user" , "name" : "Ken Adams" , "qual" : ":  Ph.D,BPT" , "expert" : ":  Ankle , Shoulder Sprains" , "experience" : ":  12 Years", "lbll1" : "Qualification" , "lbl2" : "Expertise" , "lbl3" : "Experience"],["image": "user" , "name" : "Ken Adams" , "qual" : ":  Ph.D,BPT" , "expert" : ":  Ankle , Shoulder Sprains" , "experience" : ":  12 Years", "lbll1" : "Qualification" , "lbl2" : "Expertise" , "lbl3" : "Experience"],["image": "user" , "name" : "Ken Adams" , "qual" : ":  Ph.D,BPT" , "expert" : ":  Ankle , Shoulder Sprains" , "experience" : ":  12 Years", "lbll1" : "Qualification" , "lbl2" : "Expertise" , "lbl3" : "Experience"],["image": "user" , "name" : "Ken Adams" , "qual" : ":  Ph.D,BPT" , "expert" : ":  Ankle , Shoulder Sprains" , "experience" : ":  12 Years", "lbll1" : "Qualification" , "lbl2" : "Expertise" , "lbl3" : "Experience"],["image": "user" , "name" : "Ken Adams" , "qual" : ":  Ph.D,BPT" , "expert" : ":  Ankle , Shoulder Sprains" , "experience" : ":  12 Years", "lbll1" : "Qualification" , "lbl2" : "Expertise" , "lbl3" : "Experience"],["image": "user" , "name" : "Ken Adams" , "qual" : ":  Ph.D,BPT" , "expert" : ":  Ankle , Shoulder Sprains" , "experience" : ":  12 Years", "lbll1" : "Qualification" , "lbl2" : "Expertise" , "lbl3" : "Experience"],["image": "user" , "name" : "Ken Adams" , "qual" : ":  Ph.D,BPT" , "expert" : ":  Ankle , Shoulder Sprains" , "experience" : ":  12 Years", "lbll1" : "Qualification" , "lbl2" : "Expertise" , "lbl3" : "Experience"],["image": "user" , "name" : "Ken Adams" , "qual" : ":  Ph.D,BPT" , "expert" : ":  Ankle , Shoulder Sprains" , "experience" : ":  12 Years", "lbll1" : "Qualification" , "lbl2" : "Expertise" , "lbl3" : "Experience"],["image": "user" , "name" : "Ken Adams" , "qual" : ":  Ph.D,BPT" , "expert" : ":  Ankle , Shoulder Sprains" , "experience" : ":  12 Years", "lbll1" : "Qualification" , "lbl2" : "Expertise" , "lbl3" : "Experience"],["image": "user" , "name" : "Ken Adams" , "qual" : ":  Ph.D,BPT" , "expert" : ":  Ankle , Shoulder Sprains" , "experience" : ":  12 Years", "lbll1" : "Qualification" , "lbl2" : "Expertise" , "lbl3" : "Experience"]]
    
    var arrData = [["image": "user" , "name" : "Ken Adams" , "qual" : ":  Ph.D,BPT" , "expert" : ":  Ankle , Shoulder Sprains" , "experience" : ":  12 Years", "lbll1" : "Qualification" , "lbl2" : "Expertise" , "lbl3" : "Experience", "lb1" : "17 Years experience" , "lb2" : "$300 online" , "lb3" : "Available today" , "lb4" : "06:00PM-09:00PM","image1": "experiance","image2": "doller","image3": "avaliable"], ["image": "user" , "name" : "Ken Adams" , "qual" : ":  Ph.D,BPT" , "expert" : ":  Ankle , Shoulder Sprains" , "experience" : ":  12 Years", "lbll1" : "Qualification" , "lbl2" : "Expertise" , "lbl3" : "Experience", "lb1" : "17 Years experience" , "lb2" : "$300 online" , "lb3" : "Available today" , "lb4" : "06:00PM-09:00PM","image1": "experiance","image2": "doller","image3": "avaliable"],["image": "user" , "name" : "Ken Adams" , "qual" : ":  Ph.D,BPT" , "expert" : ":  Ankle , Shoulder Sprains" , "experience" : ":  12 Years", "lbll1" : "Qualification" , "lbl2" : "Expertise" , "lbl3" : "Experience", "lb1" : "17 Years experience" , "lb2" : "$300 online" , "lb3" : "Available today" , "lb4" : "06:00PM-09:00PM","image1": "experiance","image2": "doller","image3": "avaliable"],["image": "user" , "name" : "Ken Adams" , "qual" : ":  Ph.D,BPT" , "expert" : ":  Ankle , Shoulder Sprains" , "experience" : ":  12 Years", "lbll1" : "Qualification" , "lbl2" : "Expertise" , "lbl3" : "Experience", "lb1" : "17 Years experience" , "lb2" : "$300 online" , "lb3" : "Available today" , "lb4" : "06:00PM-09:00PM","image1": "experiance","image2": "doller","image3": "avaliable"],["image": "user" , "name" : "Ken Adams" , "qual" : ":  Ph.D,BPT" , "expert" : ":  Ankle , Shoulder Sprains" , "experience" : ":  12 Years", "lbll1" : "Qualification" , "lbl2" : "Expertise" , "lbl3" : "Experience", "lb1" : "17 Years experience" , "lb2" : "$300 online" , "lb3" : "Available today" , "lb4" : "06:00PM-09:00PM","image1": "experiance","image2": "doller","image3": "avaliable"]]
    
    override func viewDidLoad() {
        super.viewDidLoad()
        self.styleUI()
        self.styleNavigationBar()
        self.getPilateList()
    }
    
    func getPilateList() {
        self.pilateViewModel.doctorList { (pilateListArray) in
            self.pilateViewModel.pilateList = pilateListArray
            self.collectionView.reloadData()
        }
    }
    
    @IBAction func applyBtnAction(_ sender: UIButton) {
        self.applyButton.isSelected = !self.applyButton.isSelected
        applyButton.isSelected = false
        if applyButton.isSelected == true {
            view1.isHidden = false
            view2.isHidden = false
            view3.isHidden = true
            self.collectionView.isHidden = false
            self.collectionView.reloadData()
            self.tblViewFilter.reloadData()
        } else {
            view1.isHidden = false
            view2.isHidden = false
            view3.isHidden = true
            self.filteredCollectionView.reloadData()
        }
    }
    
    func styleUI()
    {
        self.automaticallyAdjustsScrollViewInsets = false
        self.filterButton.setImage(#imageLiteral(resourceName: "filter_icon"), for: .normal)
        self.searchImage.image = #imageLiteral(resourceName: "search_icon")
        self.searchTxt.layer.borderWidth = 1
        self.searchTxt.layer.borderColor = UIColor.init(red: 45/255.0 , green: 46/255.0 , blue: 44/255.0 , alpha: 0.1
            ).cgColor
        
        self.btnSearch.setImage( #imageLiteral(resourceName: "search_icon") , for: .normal)
        let myColor = UIColor.init(red: 46/255.0, green: 45/255.0, blue: 44/255.0, alpha: 0.1)
        self.txtSearch.layer.borderColor = myColor.cgColor
        self.txtSearch.layer.borderWidth = 0.5
        self.txtSearch.borderStyle = UITextBorderStyle.none
        self.btnSearch.layer.borderWidth = 0.5
        self.btnSearch.layer.borderColor = myColor.cgColor
        self.tblViewFilter.tableFooterView = UIView()
        self.view3.isHidden = true
        self.filteredCollectionView.isHidden = true
        
        DecorateControls.putTitle(button: applyButton, text: "Apply", font: UIFont.boldSystemFont(ofSize: FONT_SIZE_20), textColor: whiteColor(), backGroundColor: appColor())
        applyButton.layer.cornerRadius = 5
        DecorateControls.styleLabel(label: sortLabel, text: "Sort By", font: UIFont.boldSystemFont(ofSize: FONT_SIZE_20), textColor: blackColor())
        
        tblViewFilter.estimatedRowHeight = 50
        tblViewFilter.rowHeight = UITableViewAutomaticDimension
        self.searchTxt.setRightPaddingPoints(10)
        self.searchTxt.setLeftPaddingPoints(10)
        self.txtSearch.setRightPaddingPoints(10)
        self.txtSearch.setLeftPaddingPoints(10)
        self.btnSearch.isHidden = true
        self.txtSearch.isHidden = true
    }
    
    func styleNavigationBar()
    {
        if navigationController?.viewControllers.count == 1 {
            CommonUtility.createCustomBackButton(self, navBarItem: self.navigationItem, strImage: "menu_slide", select: #selector(doClickSideMenu))
        }
        else {
            CommonUtility.createCustomBackButton(self, navBarItem: self.navigationItem, strImage: "back_icon _white", select: #selector(openPopView))
        }
        
        CommonUtility.setNavBarTitle(self.navigationItem, title: NSLocalizedString("title.pilates", comment: "The title of the pilates navigation bar"))
        
        CommonUtility.createRightBarHomeButtons(target: self, navigationItem: self.navigationItem, select1: #selector(openProfileView), select2: #selector(openDashBoardView))
    }
    
    //MARK: - Navigation Bar Methods
    @objc func openPopView() {
        self.navigationController?.popViewController(animated: true)
    }
    
    @objc func doClickSideMenu()
    {
        panel?.openLeft(animated: true)
    }
    
    @objc func openProfileView()
    {
     self.navigationController?.pushViewController((self.storyboard?.instantiateViewController(withIdentifier: "ProfileViewController"))!, animated: true)
        
    }
    
    @objc func openDashBoardView()
    {
        CommonUtility.setMenuSelectedOption(menuOptionIndex: 0)
        let centerVC : UIViewController
        let storyboard =  UIStoryboard(name: "Main", bundle: nil)
        centerVC = storyboard.instantiateViewController(withIdentifier: "DashboardViewController")
        let centerNavVC = UINavigationController(rootViewController: centerVC)
        self.panel?.configs.centerPanelTransitionType = .moveLeft
        self.panel?.configs.centerPanelTransitionDuration = 1.0
        _ = panel?.center(centerNavVC)
    }
    
    @objc func openNotificationsView()
    {
        self.navigationController?.pushViewController((self.storyboard?.instantiateViewController(withIdentifier: "NotificationsViewController"))!, animated: true)
    }
    
    @objc func openSettingsView()
    {
        self.navigationController?.pushViewController((self.storyboard?.instantiateViewController(withIdentifier: "SettingsViewController"))!, animated: true)
    }
    
    @IBAction func filterAction(_ sender: Any) {
        
        self.filterButton.isSelected = !self.filterButton.isSelected
        if filterButton.isSelected == true {
            view1.isHidden = false
            view2.isHidden = true
            view3.isHidden = false
            self.filteredCollectionView.isHidden = false
            self.filteredCollectionView.reloadData()
        } else {
            view1.isHidden = false
            view2.isHidden = true
            view3.isHidden = false
            self.collectionView.reloadData()
            self.tblViewFilter.reloadData()
        }
    }
    
    @objc func checkBoxSelection(_ sender:UIButton)
    {
        let selectedIndexPath = IndexPath(row: sender.tag, section: 0)
        
        if self.selectedRows.contains(selectedIndexPath)
        {
            self.selectedRows.remove(at: self.selectedRows.index(of: selectedIndexPath)!)
        }
        else
        {
            self.selectedRows.append(selectedIndexPath)
        }
        self.tblViewFilter.reloadData()
    }
    
    func pilateAddedAlready() -> Bool {
        guard let arrTemp = self.pilateViewModel.pilateList?.result.filter({$0.my_client == 1})  else {
            return false
        }
        return arrTemp.count > 0
    }
}

extension PilatesViewController: UICollectionViewDataSource{
    func collectionView(_ collectionView: UICollectionView, numberOfItemsInSection section: Int) -> Int {
        guard let pilateListModelData = self.pilateViewModel.pilateList else {
            return 0
        }
        return (pilateListModelData.result.count)
    }
    
    func collectionView(_ collectionView: UICollectionView, cellForItemAt indexPath: IndexPath) -> UICollectionViewCell {
        if self.filterButton.isSelected == true {
            let cell = filteredCollectionView.dequeueReusableCell(withReuseIdentifier: "newCell", for: indexPath) as! PilatesCollectionViewCell
            cell.styleTableViewCell(pilateInfoModel: (self.pilateViewModel.pilateList?.result[indexPath.row])!)
            return cell
        } else {
            let cell = self.collectionView.dequeueReusableCell(withReuseIdentifier: "cellfirst", for: indexPath) as! PilatesCollectionViewCell
            cell.styleTableViewCell(pilateInfoModel: (self.pilateViewModel.pilateList?.result[indexPath.row])!)
            return cell
        }
    }
    
    func collectionView(_ collectionView: UICollectionView, layout collectionViewLayout: UICollectionViewLayout, minimumLineSpacingForSectionAt section: Int) -> CGFloat {
        return 20
    }
    
    func collectionView(_ collectionView: UICollectionView, layout collectionViewLayout: UICollectionViewLayout, minimumInteritemSpacingForSectionAt section: Int) -> CGFloat {
        return 0
    }
    
    func collectionView(_ collectionView: UICollectionView, layout collectionViewLayout: UICollectionViewLayout, insetForSectionAt section: Int) -> UIEdgeInsets {
        return UIEdgeInsets.zero
    }
    
    func collectionView(_ collectionView: UICollectionView, layout collectionViewLayout: UICollectionViewLayout, sizeForItemAt indexPath: IndexPath) -> CGSize {
        if collectionView == filteredCollectionView {
            let cellWidth = (collectionView.bounds.width)/2 - 20
            let cellHeight = (collectionView.bounds.height)/5.0
            return CGSize(width : cellWidth , height : cellHeight)
        } else {
            let cellWidth = (collectionView.frame.size.width)/3.0 - 15
            let cellHeight = (collectionView.frame.size.height)/5.0
            return CGSize(width : cellWidth , height : cellHeight)
        }
    }
}

extension PilatesViewController: UICollectionViewDelegate{
    func collectionView(_ collectionView: UICollectionView, didSelectItemAt indexPath: IndexPath) {
        let vc = self.storyboard?.instantiateViewController(withIdentifier: "PilateDetailViewController") as! PilateDetailViewController
        vc.isBackBtnSelected = true
        vc.alreadyAddedaPilate = self.pilateAddedAlready()
        vc.pilateModel = (self.pilateViewModel.pilateList?.result[indexPath.row])!
        self.navigationController?.pushViewController(vc, animated: true)
    }
}

extension PilatesViewController: UITableViewDataSource , UITableViewDelegate{
    func tableView(_ tableView: UITableView, numberOfRowsInSection section: Int) -> Int {
        return data.count
    }
    
    func tableView(_ tableView: UITableView, heightForRowAt indexPath: IndexPath) -> CGFloat {
        return UITableViewAutomaticDimension
    }
    
    
    func tableView(_ tableView: UITableView, cellForRowAt indexPath: IndexPath) -> UITableViewCell {
        let cell = self.tblViewFilter.dequeueReusableCell(withIdentifier: "tableCell") as! PilatesTableViewCell
        cell.lblFilterText.text = data[indexPath.row]
        if selectedRows.contains(indexPath)
        {
            cell.btnCheckBox.setImage(#imageLiteral(resourceName: "check_box_selected"), for: .normal)
        }
        else
        {
            cell.btnCheckBox.setImage(#imageLiteral(resourceName: "check_box_unselected"), for: .normal)
        }
        cell.btnCheckBox.tag = indexPath.row
        cell.btnCheckBox.addTarget(self, action: #selector(checkBoxSelection(_:)), for: .touchUpInside)
        cell.selectionStyle = .none
        return cell
    }
    
    func tableView(_ tableView: UITableView, didSelectRowAt indexPath: IndexPath) {
        
        let selectedIndexPath = IndexPath(row: indexPath.row, section: 0)
        
        if self.selectedRows.contains(selectedIndexPath)
        {
            self.selectedRows.remove(at: self.selectedRows.index(of: selectedIndexPath)!)
        }
        else
        {
            self.selectedRows.append(selectedIndexPath)
        }
        self.tblViewFilter.reloadData()
    }
//        let cell1 = self.tblViewFilter.dequeueReusableCell(withIdentifier: "tableCell") as! PilatesTableViewCell
//        if selectedRows.contains(indexPath)
//        {
//            cell1.btnCheckBox.setImage(#imageLiteral(resourceName: "check_box_selected"), for: .normal)
//        }
//        else
//        {
//            cell1.btnCheckBox.setImage(#imageLiteral(resourceName: "check_box_unselected"), for: .normal)
//        }
//        cell1.btnCheckBox.tag = indexPath.row
//        cell1.btnCheckBox.addTarget(self, action: #selector(checkBoxSelection(_:)), for: .touchUpInside)
    
    
    override func touchesBegan(_ touches: Set<UITouch>, with event: UIEvent?) {
        self.view.endEditing(true)
    }
}
extension UITextField {
    func setLeftPaddingPoints(_ amount:CGFloat){
        let paddingView = UIView(frame: CGRect(x: 0, y: 0, width: amount, height: self.frame.size.height))
        self.leftView = paddingView
        self.leftViewMode = .always
    }
    func setRightPaddingPoints(_ amount:CGFloat) {
        let paddingView = UIView(frame: CGRect(x: 0, y: 0, width: amount, height: self.frame.size.height))
        self.rightView = paddingView
        self.rightViewMode = .always
    }
}

extension PilatesViewController: EmptyDataSetSource, EmptyDataSetDelegate {
    func title(forEmptyDataSet scrollView: UIScrollView) -> NSAttributedString? {
        return CommonUtility.dzEmptySetTitle(title: NSLocalizedString("title.error.nodata", comment: "This string shows when there is no data found."))
    }
    
    func buttonTitle(forEmptyDataSet scrollView: UIScrollView, for state: UIControlState) -> NSAttributedString? {
        return CommonUtility.dzEmptySetButtonTitle(title: NSLocalizedString("title.retry", comment: "This gives the option for retry when there is no data."))
    }
    
    func emptyDataSet(_ scrollView: UIScrollView, didTapButton button: UIButton) {
        self.getPilateList()
    }
}
