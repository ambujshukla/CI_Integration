//
//  CustomTableViewCell.swift
//  Pilates
//
//  Created by PujaDwivedi on 30/04/18.
//  Copyright © 2018 PujaDwivedi. All rights reserved.
//

import UIKit

class PilatesTableViewCell: UITableViewCell {
    @IBOutlet weak var lblFilterText: UILabel!
    @IBOutlet weak var btnCheckBox: UIButton!
    
    override func awakeFromNib() {
        super.awakeFromNib()
        DecorateControls.styleLabel(label: lblFilterText, text: "", font: UIFont.boldSystemFont(ofSize: FONT_SIZE_20), textColor: color(red: 172, green: 172, blue: 172))
    }
    
}
