//
//  CustomCollectionViewCell.swift
//  Pilates2
//
//  Created by PujaDwivedi on 27/04/18.
//  Copyright © 2018 PujaDwivedi. All rights reserved.
//

import UIKit
import SDWebImage

class PilatesCollectionViewCell: UICollectionViewCell {
    
    @IBOutlet weak var imgUserProfile: UIImageView!
    @IBOutlet weak var lblPilateName: UILabel!
    @IBOutlet weak var lblQualification: UILabel!
    @IBOutlet weak var lblQualificationValue: UILabel!
    @IBOutlet weak var lblExpertise: UILabel!
    @IBOutlet weak var lblExpertiseValue: UILabel!
    @IBOutlet weak var lblExperience: UILabel!
    @IBOutlet weak var lblExperienceValue: UILabel!
    @IBOutlet weak var lblTotalExperienceValue: UILabel?
    @IBOutlet weak var imgTotalExperience: UIImageView?
    @IBOutlet weak var lblOnlineValue: UILabel?
    @IBOutlet weak var imgOnline: UIImageView?
    @IBOutlet weak var lblAvailabilityStatus: UILabel?
    @IBOutlet weak var imgAvailabilityStatus: UIImageView?
    @IBOutlet weak var lblTime: UILabel?
    
    override func layoutSubviews() {
        self.imgUserProfile.clipsToBounds = true
        super.layoutSubviews()
        layoutIfNeeded()
        self.imgUserProfile.layer.cornerRadius = imgUserProfile.frame.height/2
        self.imgUserProfile.layer.cornerRadius = self.imgUserProfile.frame.size.width/2
    }
    override func awakeFromNib() {
        super.awakeFromNib()
        DecorateControls.styleLabel(label: lblPilateName, text: "", font: UIFont.boldSystemFont(ofSize: FONT_SIZE_18), textColor: blackColor())
        DecorateControls.styleLabel(label: lblQualification, text: "", font: UIFont.boldSystemFont(ofSize: FONT_SIZE_10), textColor: color(red: 172, green: 172, blue: 172))
        DecorateControls.styleLabel(label: lblQualificationValue, text: "", font: UIFont.boldSystemFont(ofSize: FONT_SIZE_10), textColor: color(red: 84, green: 84, blue: 84))
        DecorateControls.styleLabel(label: lblExpertise, text: "", font: UIFont.boldSystemFont(ofSize: FONT_SIZE_10), textColor: color(red: 172, green: 172, blue: 172))
        DecorateControls.styleLabel(label: lblExpertiseValue, text: "", font: UIFont.boldSystemFont(ofSize: FONT_SIZE_10), textColor: color(red: 84, green: 84, blue: 84))
        DecorateControls.styleLabel(label: lblExperience, text: "", font: UIFont.boldSystemFont(ofSize: FONT_SIZE_10), textColor: color(red: 172, green: 172, blue: 172))
        DecorateControls.styleLabel(label: lblExperienceValue, text: "", font: UIFont.boldSystemFont(ofSize: FONT_SIZE_10), textColor: color(red: 84, green: 84, blue: 84))
        DecorateControls.styleLabel(label: lblTime, text: "", font: UIFont.boldSystemFont(ofSize: FONT_SIZE_11), textColor: color(red: 172, green: 172, blue: 172))
        DecorateControls.styleLabel(label: lblOnlineValue, text: "", font: UIFont.boldSystemFont(ofSize: FONT_SIZE_10), textColor: color(red: 172, green: 172, blue: 172))
        DecorateControls.styleLabel(label: lblTotalExperienceValue, text: "", font: UIFont.boldSystemFont(ofSize: FONT_SIZE_10), textColor: color(red: 172, green: 172, blue: 172))
        DecorateControls.styleLabel(label: lblAvailabilityStatus, text: "", font: UIFont.boldSystemFont(ofSize: FONT_SIZE_10), textColor: color(red: 84, green: 84, blue: 84))
    }
    
    func styleTableViewCell(pilateInfoModel: PilateList) {
        self.lblQualification.text = "Qualification"
        self.lblExpertise.text = "Expertise"
        self.lblExperience.text = "Experience"
       // self.lblPilateName.text = pilateInfoModel.username
        self.lblPilateName.text = "\(pilateInfoModel.firstname!) \(pilateInfoModel.lastname!)"
        self.lblQualificationValue.text = pilateInfoModel.qualification
        self.lblExpertiseValue.text = pilateInfoModel.expertise
        self.lblExperienceValue.text = pilateInfoModel.experience
        self.imgUserProfile.sd_setImage(with: URL(string: pilateInfoModel.profile_image), placeholderImage: #imageLiteral(resourceName: "no-inage"))
    }
}
