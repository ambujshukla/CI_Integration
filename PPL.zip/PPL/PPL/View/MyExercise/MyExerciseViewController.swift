//
//  MyExerciseViewController.swift
//  PPL
//
//  Created by TanjeetAjmani on 09/05/18.
//  Copyright © 2018 cdn. All rights reserved.
//

import UIKit

class MyExerciseViewController: UIViewController,UICollectionViewDelegate,UICollectionViewDataSource,UICollectionViewDelegateFlowLayout {
    @IBOutlet weak var btnVideo: UIButton!
    
    @IBOutlet weak var btnAddVideo: UIButton!
    @IBOutlet weak var viewAddVideo: UIView!
    @IBOutlet weak var textFieldSearch: UITextField!
    @IBOutlet weak var btnSearch: UIButton!
    @IBOutlet weak var viewTextField: UIView!
    @IBOutlet weak var btnNonPurchased: UIButton!
    @IBOutlet weak var btnPurchased: UIButton!
    @IBOutlet weak var btnAll: UIButton!
    @IBOutlet weak var viewThreeBtns: UIView!
    @IBOutlet weak var cvMyExercise: UICollectionView!
    @IBOutlet weak var viewButton: UIView!
    @IBOutlet weak var btnImage: UIButton!
    var arrExercise = [["lbl" : "Sit on the Exercise ball.Walk forward on ball.Recline ojnly on shoulders and head are left protuding to the end","img" : "exer"],["lbl" : "Sit on the Exercise ball.Walk forward on ball.Recline ojnly on shoulders and head are left protuding to the end","img" : "exer"],["lbl" : "Sit on the Exercise ball.Walk forward on ball.Recline ojnly on shoulders and head are left protuding to the end","img" : "exer"],["lbl" : "Sit on the Exercise ball.Walk forward on ball.Recline ojnly on shoulders and head are left protuding to the end","img" : "exer"],["lbl" : "Sit on the Exercise ball.Walk forward on ball.Recline ojnly on shoulders and head are left protuding to the end","img" : "exer"],["lbl" : "Sit on the Exercise ball.Walk forward on ball.Recline ojnly on shoulders and head are left protuding to the end","img" : "exer"],["lbl" : "Sit on the Exercise ball.Walk forward on ball.Recline ojnly on shoulders and head are left protuding to the end","img" : "exer"],["lbl" : "Sit on the Exercise ball.Walk forward on ball.Recline ojnly on shoulders and head are left protuding to the end","img" : "exer"],["lbl" : "Sit on the Exercise ball.Walk forward on ball.Recline ojnly on shoulders and head are left protuding to the end","img" : "exer"],["lbl" : "Sit on the Exercise ball.Walk forward on ball.Recline ojnly on shoulders and head are left protuding to the end","img" : "exer"],["lbl" : "Sit on the Exercise ball.Walk forward on ball.Recline ojnly on shoulders and head are left protuding to the end","img" : "exer"],["lbl" : "Sit on the Exercise ball.Walk forward on ball.Recline ojnly on shoulders and head are left protuding to the end","img" : "exer"]]
    
    let yourAttributes : [NSAttributedStringKey: Any] = [
        NSAttributedStringKey.font : UIFont.systemFont(ofSize: 14),
        NSAttributedStringKey.underlineStyle : NSUnderlineStyle.styleSingle.rawValue]
    //.styleDouble.rawValue, .styleThick.rawValue, .styleNone.rawValue
    
    override func viewDidLoad() {
        super.viewDidLoad()
        btnVideo.setImage(UIImage.init(named: "video"), for: .normal)
        btnVideo.setTitle("  Video", for: .normal)
        btnVideo.setTitleColor(UIColor.black, for: .normal)
        btnImage.setImage(UIImage.init(named: "image"), for: .normal)
        btnImage.setTitle("  Image", for: .normal)

        btnImage.backgroundColor = UIColor.init(red: 226/255.0, green: 193/255.0, blue: 68/255.0, alpha: 1)

        
    
        
        viewButton.layer.cornerRadius = 5
        viewButton.layer.borderWidth = 1
        viewButton.layer.borderColor = UIColor.init(red: 226/255.0, green: 193/255.0, blue: 68/255.0, alpha: 1).cgColor
        viewButton.clipsToBounds = true
        
        viewThreeBtns.layer.cornerRadius = 5
        viewThreeBtns.layer.borderWidth = 1
        viewThreeBtns.layer.borderColor = UIColor.init(red: 226/255.0, green: 193/255.0, blue: 68/255.0, alpha: 1).cgColor
        viewThreeBtns.clipsToBounds = true
     
        let attributeString = NSMutableAttributedString(string: "Add Video",
                                                        attributes: yourAttributes)
        self.btnAddVideo.setAttributedTitle(attributeString, for: .normal)
        
        self.btnAddVideo.setTitleColor(UIColor.black, for: .normal)
        
        btnSearch.setImage(UIImage.init(named: "search"), for: .normal)
        viewTextField.layer.borderWidth = 1
        viewTextField.layer.borderColor = UIColor.lightGray.cgColor
        viewTextField.clipsToBounds = true
        
        
         btnAll.setTitle("All", for: .normal)
        btnAll.backgroundColor = UIColor.init(red: 226/255.0, green: 193/255.0, blue: 68/255.0, alpha: 1)
        btnPurchased.setTitle("Purchased", for: .normal)
        btnPurchased.setTitleColor(UIColor.black, for: .normal)
       btnNonPurchased.setTitle("Non Purchased", for: .normal)
        btnNonPurchased.setTitleColor(UIColor.black, for: .normal)
        
        viewButton.isHidden = true
        viewThreeBtns.isHidden = false
        viewTextField.isHidden = false
        viewAddVideo.isHidden = true
    }

    func collectionView(_ collectionView: UICollectionView, numberOfItemsInSection section: Int) -> Int {
        return arrExercise.count
    }
    
    func collectionView(_ collectionView: UICollectionView, cellForItemAt indexPath: IndexPath) -> UICollectionViewCell {
        let cell = collectionView.dequeueReusableCell(withReuseIdentifier: "cell", for: indexPath) as! MyExerciseCollectionViewCell
        cell.lblExerciseDetail.text = arrExercise[indexPath.item]["lbl"]
        let cellImg = arrExercise[indexPath.item]["img"]
        cell.imgExercise.image = UIImage.init(named: cellImg!)
     
        
        let attributeString = NSMutableAttributedString(string: "View More",
                                                        attributes: yourAttributes)
    cell.btnClickMore.setAttributedTitle(attributeString, for: .normal)
        cell.btnClickMore.setTitleColor(UIColor.black, for: .normal)
        
        cell.btnPurchased.layer.cornerRadius = 5
        cell.btnPurchased.backgroundColor = UIColor.init(red: 226/255.0, green: 193/255.0, blue: 68/255.0, alpha: 1)
       
        cell.btnClickMore.isHidden = true
        cell.btnPurchased.isHidden = false
        cell.lblTime.isHidden = false
        
        cell.btnPurchased.setTitle("Purchased", for: .normal)
        cell.lblTime.text = "2.30"
        
        return cell
    }
    
    func collectionView(_ collectionView: UICollectionView, layout collectionViewLayout: UICollectionViewLayout, sizeForItemAt indexPath: IndexPath) -> CGSize {
        
     
            let cellWidth = (collectionView.bounds.width/3.0) - 15
            let cellHeight = (collectionView.bounds.height/4.0)
            
            return CGSize(width: cellWidth , height: cellHeight)
    
    }
    
    func collectionView(_ collectionView: UICollectionView, layout collectionViewLayout: UICollectionViewLayout, insetForSectionAt section: Int) -> UIEdgeInsets {
        return UIEdgeInsets.zero
    }
    
    func collectionView(_ collectionView: UICollectionView, layout collectionViewLayout: UICollectionViewLayout, minimumInteritemSpacingForSectionAt section: Int) -> CGFloat {
        return 0
        
    }
    
    func collectionView(_ collectionView: UICollectionView, layout collectionViewLayout: UICollectionViewLayout, minimumLineSpacingForSectionAt section: Int) -> CGFloat {
        return 15
    }

    @IBAction func btnSelection(_ sender: UIButton) {
       btnImage.isSelected = false
        btnVideo.isSelected = false
        viewButton.isHidden = false
        viewThreeBtns.isHidden = true
        viewTextField.isHidden = true
        sender.isSelected = true
        colorButton()
        cvMyExercise.reloadData()
    }
    func colorButton() {
        
        self.btnImage.backgroundColor = UIColor.clear
        self.btnVideo.backgroundColor = UIColor.clear
        self.btnImage.setTitleColor(UIColor.black, for: .normal)
        self.btnVideo.setTitleColor(UIColor.black, for: .normal)
        self.btnVideo.setImage(UIImage.init(named: "video"), for: .normal)
        self.btnImage.setImage(UIImage.init(named: "image"), for: .normal)
      
        
        if btnVideo.isSelected == true {
            btnVideo.setTitleColor(UIColor.white, for: .normal)
            btnVideo.backgroundColor = UIColor.init(red: 226/255.0, green: 193/255.0, blue: 68/255.0, alpha: 1)
            btnVideo.setImage(UIImage.init(named: "video_active"), for: .normal)
        }
        else {
            btnImage.setTitleColor(UIColor.white, for: .normal)
            btnImage.backgroundColor = UIColor.init(red: 226/255.0, green: 193/255.0, blue: 68/255.0, alpha: 1)
            btnImage.setImage(UIImage.init(named: "image_active"), for: .normal)
        }
    }
}
