//
//  MyExerciseCollectionViewCell.swift
//  PPL
//
//  Created by TanjeetAjmani on 09/05/18.
//  Copyright © 2018 cdn. All rights reserved.
//

import UIKit

class MyExerciseCollectionViewCell: UICollectionViewCell {
    @IBOutlet weak var imgExercise: UIImageView!
    
    @IBOutlet weak var lblTime: UILabel!
    @IBOutlet weak var btnPurchased: UIButton!
    @IBOutlet weak var btnClickMore: UIButton!
    @IBOutlet weak var imgSepartr: UIImageView!
    @IBOutlet weak var lblExerciseDetail: UILabel!
}
