//
//  CustomCollectionViewCell.swift
//  PilateImageDetail
//
//  Created by TanjeetAjmani on 02/05/18.
//  Copyright © 2018 TanjeetAjmani. All rights reserved.
//

import UIKit

class ExerciseDetailCollectionViewCell: UICollectionViewCell {
    
    @IBOutlet weak var imageRelatedImg: UIImageView!
    
}
