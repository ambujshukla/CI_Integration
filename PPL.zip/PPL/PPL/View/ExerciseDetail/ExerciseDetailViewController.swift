//
//  ViewController.swift
//  PilateImageDetail
//
//  Created by TanjeetAjmani on 02/05/18.
//  Copyright © 2018 TanjeetAjmani. All rights reserved.
//

import UIKit

class ExerciseDetailViewController: UIViewController,UICollectionViewDelegate,UICollectionViewDataSource,UICollectionViewDelegateFlowLayout {
    
    var imagesArr = ["lungsColor","lungsWhite","lungsColor","lungsWhite","lungsColor"]
    
    @IBOutlet weak var collectnImages: UICollectionView!
    @IBOutlet weak var lblRelatedImages: UILabel!
    @IBOutlet weak var textViewExecute: UITextView!
    @IBOutlet weak var textViewPrepartn: UITextView!
    @IBOutlet weak var lblExecute: UILabel!
    @IBOutlet weak var lblPreparatn: UILabel!
    @IBOutlet weak var imageExercise: UIImageView!
    @IBOutlet fileprivate weak var btnBack : UIButton!

    override func viewDidLoad() {
        super.viewDidLoad()
        self.styleUI()
        self.styleNavigationBar()
        self.automaticallyAdjustsScrollViewInsets = false
    }
    
    private func styleUI()
    {
        self.textViewPrepartn.text = "Sit on Exercise Ball. Walk forward on ball and recline until only shoulders and head are left protruding off the end. With knees and hips bent gently extend back to match contour of the ball. Hold Weight plate behind head or on chest."
        self.textViewExecute.text = "Flex waist to raise upper Torso. Return to original position. Repeat."
        
        DecorateControls.styleLabel(label: lblPreparatn, text: "Preparation", font: UIFont.boldSystemFont(ofSize: FONT_SIZE_25), textColor: blackColor())
        DecorateControls.styleLabel(label: lblExecute, text: "Execution", font: UIFont.boldSystemFont(ofSize: FONT_SIZE_25), textColor: blackColor())
        DecorateControls.styleLabel(label: lblRelatedImages, text: "Related Images", font: UIFont.boldSystemFont(ofSize: FONT_SIZE_25), textColor: blackColor())
        DecorateControls.putText(textView: textViewPrepartn, text: "Sit on Exercise Ball. Walk forward on ball and recline until only shoulders and head are left protruding off the end. With knees and hips bent gently extend back to match contour of the ball. Hold Weight plate behind head or on chest.", font: UIFont.boldSystemFont(ofSize: FONT_SIZE_15), textColor: color(red: 116, green: 116, blue: 116))
        DecorateControls.putText(textView: textViewExecute, text: "Flex waist to raise upper Torso. Return to original position. Repeat.", font: UIFont.boldSystemFont(ofSize: FONT_SIZE_15), textColor: color(red: 116, green: 116, blue: 116))
        
        self.imageExercise.image = #imageLiteral(resourceName: "exercise")
       self.textViewExecute.isEditable = false
        self.textViewPrepartn.isEditable = false
    }
    
    func styleNavigationBar()
    {
        CommonUtility.createCustomBackButton(self, navBarItem: self.navigationItem, strImage: "back_icon _white", select: #selector(openPopView))
        
        CommonUtility.setNavBarTitle(self.navigationItem, title: NSLocalizedString("Exercise Detail", comment: "The title of the dashboard navigation bar"))
        
        CommonUtility.createRightBarHomeButtons(target: self, navigationItem: self.navigationItem, select1: #selector(openProfileView), select2: #selector(openDashBoardView))
    }
    //MARK: - Navigation Bar Methods
    @objc func doClickSideMenu()
    {
        panel?.openLeft(animated: true)
    }

    @objc func openProfileView()
    {
    self.navigationController?.pushViewController((self.storyboard?.instantiateViewController(withIdentifier: "ProfileViewController"))!, animated: true)
    }
    
    @objc func openNotificationsView()
    {
        self.navigationController?.pushViewController((self.storyboard?.instantiateViewController(withIdentifier: "NotificationsViewController"))!, animated: true)
    }
    
    @objc func openSettingsView()
    {
        self.navigationController?.pushViewController((self.storyboard?.instantiateViewController(withIdentifier: "SettingsViewController"))!, animated: true)
    }
    
    @objc func openDashBoardView()
    {
        CommonUtility.setMenuSelectedOption(menuOptionIndex: 0)
        let centerVC : UIViewController
        let storyboard =  UIStoryboard(name: "Main", bundle: nil)
        centerVC = storyboard.instantiateViewController(withIdentifier: "DashboardViewController")
        let centerNavVC = UINavigationController(rootViewController: centerVC)
        self.panel?.configs.centerPanelTransitionType = .moveLeft
        self.panel?.configs.centerPanelTransitionDuration = 1.0
        _ = panel?.center(centerNavVC)
    }
    
    @objc func openPopView()
    {
        self.navigationController?.popViewController(animated: true)
    }
    
    
    @IBAction func doClickBack(sender : UIButton) {
        self.navigationController?.popViewController(animated: true)
    }
    
    func collectionView(_ collectionView: UICollectionView, numberOfItemsInSection section: Int) -> Int {
        return 5
    }
    
    func collectionView(_ collectionView: UICollectionView, cellForItemAt indexPath: IndexPath) -> UICollectionViewCell {
        let cell = collectionView.dequeueReusableCell(withReuseIdentifier: "cell", for: indexPath) as! ExerciseDetailCollectionViewCell
        
        let cellImage = imagesArr[indexPath.row]
        cell.imageRelatedImg.image = UIImage.init(named: cellImage)
        return cell
    }
    
    func collectionView(_ collectionView: UICollectionView, didSelectItemAt indexPath: IndexPath) {
        self.navigationController?.pushViewController((self.storyboard?.instantiateViewController(withIdentifier: "ExercisesAssignedViewController"))!, animated: true)
    }
    
    func collectionView(_ collectionView: UICollectionView, layout collectionViewLayout: UICollectionViewLayout, sizeForItemAt indexPath: IndexPath) -> CGSize {
        
        
        let cellWidth = (collectionView.frame.width)/5.0
//        let cellHeight = (collectionView.frame.height)
       
        return CGSize(width: cellWidth  , height: 178)
        
    }
    
    func collectionView(_ collectionView: UICollectionView, layout collectionViewLayout: UICollectionViewLayout, insetForSectionAt section: Int) -> UIEdgeInsets {
        return UIEdgeInsets.zero
    }
    
    func collectionView(_ collectionView: UICollectionView, layout collectionViewLayout: UICollectionViewLayout, minimumInteritemSpacingForSectionAt section: Int) -> CGFloat {
        return 0
    }
    
    func collectionView(_ collectionView: UICollectionView, layout collectionViewLayout: UICollectionViewLayout, minimumLineSpacingForSectionAt section: Int) -> CGFloat {
        return 15
    }
}

