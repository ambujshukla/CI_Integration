//
//  RegistrationTableViewCell.swift
//  PPL
//
//  Created by cdn68 on 30/04/18.
//  Copyright © 2018 cdn. All rights reserved.
//

import UIKit

protocol RegistrationInputCellDelegate: class{
    func passwordViewTapped(_ tag: Int)
    func inputCell(_ cell: RegistrationTableViewCell, didChangeText text: String?)
}

class RegistrationTableViewCell: UITableViewCell
{
    weak var delegate: RegistrationInputCellDelegate?
    var indexPath:IndexPath!
    
    @IBOutlet fileprivate weak var imageSeperatorlLne: UIImageView!
    @IBOutlet fileprivate weak var imgIcon: UIImageView!
    @IBOutlet  weak var tfSignup: UITextField!
    @IBOutlet weak var imageDropArrow: UIImageView!
    @IBOutlet weak var btnPasswordViewIcon: UIButton!
    
    override func awakeFromNib() {
        super.awakeFromNib()
        DecorateControls.putText(textField: tfSignup, text: "", placehoder: "", font: UIFont.boldSystemFont(ofSize: FONT_SIZE_18), textColor: UIColor.darkGray )
        self.btnPasswordViewIcon.setImage(#imageLiteral(resourceName: "view_icon"), for: .selected)
        self.btnPasswordViewIcon.setImage(#imageLiteral(resourceName: "view_cross"), for: .normal)
       
        self.tfSignup.delegate = self
        self.backgroundColor = .clear
        self.selectionStyle = .none
    }
    
    @IBAction func btnPasswrdActn(_ sender: UIButton) {
        delegate?.passwordViewTapped(self.btnPasswordViewIcon.tag)
    }
    
    var imageIcon : String = "" {
        didSet{
            self.imgIcon.image = UIImage(named : imageIcon)
        }
    }
    
    var tfPlaceHolder = "" {
        didSet{
            self.tfSignup.placeholder = tfPlaceHolder
        }
    }
    
    var secureText = false {
        didSet{
            self.tfSignup.isSecureTextEntry = secureText
        }
    }
    
    var shouldHidePasswordViewIcon = false {
        didSet{
            self.btnPasswordViewIcon.isHidden = shouldHidePasswordViewIcon
        }
    }
}

extension RegistrationTableViewCell:  UITextFieldDelegate {
    func textField(_ textField: UITextField, shouldChangeCharactersIn range: NSRange, replacementString string: String) -> Bool {
        if let text = textField.text as NSString? {
            let txtAfterUpdate = text.replacingCharacters(in: range, with: string)
            self.delegate?.inputCell(self, didChangeText: txtAfterUpdate)
        }
        return true
    }
}
