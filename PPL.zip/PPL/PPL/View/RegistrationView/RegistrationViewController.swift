//
//  RegistrationViewController.swift
//  PPL
//
//  Created by cdn68 on 30/04/18.
//  Copyright © 2018 cdn. All rights reserved.
//

import UIKit
import ActionSheetPicker_3_0

enum RegistrationTextFieldTag: Int {
    case firstNameTextFieldTag = 0
    case lastNameTextFieldTag
    case usernameTextFieldTag
    case genderTextFieldtag
    case emailTextFieldTag
    case passwordTextFieldTag
    case confirmpasswordTextFieldTag
    case addressTextFieldTag
}

class RegistrationViewController: UIViewController, UITableViewDelegate, UITableViewDataSource{
    
    @IBOutlet weak var tableViewSignUP: UITableView!
    @IBOutlet weak var buttonBack: UIButton!
    @IBOutlet weak var imageBackground: UIImageView!
    @IBOutlet weak var btnReference: UIButton!
    @IBOutlet weak var btnSignup: UIButton!
    @IBOutlet weak var labelReg: UILabel!
    @IBOutlet weak var imageSignup: UIImageView!
    var gender = ""
    var arrGender = ["Male","Female"]
    var selectionGender = 0
    
    var arrRegistrationData = [["image":"user_icon","userEntry":"First Name","shouldHidePasswordViewIcon" : true,"shouldSecureTextEntry" : false],["image":"user_icon","userEntry":"Last Name","shouldHidePasswordViewIcon" : true,"shouldSecureTextEntry" : false],["image":"user_icon","userEntry":"Username","shouldHidePasswordViewIcon" : true,"shouldSecureTextEntry" : false],["image":"user_icon","userEntry":"Gender","shouldHidePasswordViewIcon" : true,"shouldSecureTextEntry" : false],["image":"email_icon","userEntry":"Email Address","shouldHidePasswordViewIcon" : true ,"shouldSecureTextEntry" : false], ["image":"password_icon","userEntry":"Password","shouldHidePasswordViewIcon" : false ,"shouldSecureTextEntry" : true],["image":"password_icon","userEntry":"Confirm Password","shouldHidePasswordViewIcon" : false ,"shouldSecureTextEntry" : true],["image":"user_icon","userEntry":"Enter Full Address","shouldHidePasswordViewIcon" : true,"shouldSecureTextEntry" : false]]
    
    var registrationViewModel = RegistrationViewModel()
    
    override func viewDidLoad() {
        super.viewDidLoad()
        self.styleUI()
        self.configureInitialParameters()
    }
    
    private func styleUI()
    {
        self.tableViewSignUP.separatorStyle = UITableViewCellSeparatorStyle.none
        self.tableViewSignUP.backgroundColor = .clear
        self.imageSignup.image = #imageLiteral(resourceName: "registration_logo")
        self.btnSignup.layer.cornerRadius = 5
        self.imageBackground.image = UIImage.init(named: "background_img")
        self.buttonBack.setImage(#imageLiteral(resourceName: "back_icon"), for: .normal)
        DecorateControls.styleLabel(label: labelReg, text: "Registration", font: UIFont.boldSystemFont(ofSize: FONT_SIZE_30), textColor: blackColor())
        DecorateControls.putTitle(button: btnSignup, text: "Sign Up", font: UIFont.boldSystemFont(ofSize: FONT_SIZE_22), textColor: whiteColor(), backGroundColor: appColor())
        DecorateControls.putTitle(button: btnReference, text: "Have a Reference Code?", font: UIFont.boldSystemFont(ofSize: 16), textColor: color(red: 116, green: 116, blue: 116) , backGroundColor: clearColor())
        btnReference.isHidden = CommonUtility.isPilate()
        self.tableViewSignUP.isScrollEnabled = true
    }
    
    private func configureInitialParameters()
    {
        self.tableViewSignUP.delegate = self
        self.tableViewSignUP.dataSource = self
    }
    
    override func didReceiveMemoryWarning() {
        super.didReceiveMemoryWarning()
    }
    
    func tableView(_ tableView: UITableView, numberOfRowsInSection section: Int) -> Int {
        return self.arrRegistrationData.count
    }
    
    func tableView(_ tableView: UITableView, cellForRowAt indexPath: IndexPath) -> UITableViewCell {
        let cell = tableView.dequeueReusableCell(withIdentifier: "cell") as! RegistrationTableViewCell
        cell.btnPasswordViewIcon.isSelected = false
        cell.imageIcon = self.arrRegistrationData[indexPath.row]["image"]! as! String
        cell.btnPasswordViewIcon.tag = indexPath.row
        
        cell.tfPlaceHolder = (self.arrRegistrationData[indexPath.row]["userEntry"] as? String)!
        cell.tfSignup.attributedPlaceholder = NSAttributedString(string: self.arrRegistrationData[indexPath.row]["userEntry"] as! String,attributes: [NSAttributedStringKey.foregroundColor: UIColor.darkGray])
        cell.shouldHidePasswordViewIcon = self.arrRegistrationData[indexPath.row]["shouldHidePasswordViewIcon"]! as! Bool
        cell.btnPasswordViewIcon.isSelected = self.arrRegistrationData[indexPath.row]["shouldSecureTextEntry"]! as! Bool
        cell.secureText = self.arrRegistrationData[indexPath.row]["shouldSecureTextEntry"]! as! Bool
        cell.tfSignup.tag = indexPath.row
        cell.delegate = self
        cell.tfSignup.isEnabled = true
        cell.imageDropArrow.isHidden = true
        cell.tfSignup.keyboardType = .default
        if indexPath.row == 4 {
            cell.tfSignup.keyboardType = UIKeyboardType.emailAddress
        }
        if indexPath.row == 3 {
            
            cell.tfSignup.isEnabled = false
            cell.imageDropArrow.isHidden = false
            cell.imageDropArrow.image = #imageLiteral(resourceName: "drop_arrow")
        }
        self.setTextfieldDataInCell(cell: cell)
        return cell
    }
    
    func tableView(_ tableView: UITableView, heightForRowAt indexPath: IndexPath) -> CGFloat {
        return 75
    }
    func tableView(_ tableView: UITableView, didSelectRowAt indexPath: IndexPath) {
        
        if indexPath.row == 3 {
            view.endEditing(true)
            ActionSheetStringPicker.show(withTitle: "Gender", rows: arrGender, initialSelection: selectionGender, doneBlock: {
                picker, value, index in
                let indexx = index
                self.gender = (indexx as? String)!
                self.selectionGender = value
                self.registrationViewModel.gender = self.gender
                // self.setGoalsViewModel.weight = (indexx as? String)!
                self.tableViewSignUP.reloadData()
                return
            }, cancel: { ActionStringCancelBlock in return }, origin: tableViewSignUP)
        }
    }
    
    func setTextfieldDataInCell(cell: RegistrationTableViewCell) {
        if cell.tfSignup.tag == RegistrationTextFieldTag.firstNameTextFieldTag.rawValue {
            cell.tfSignup.text = self.registrationViewModel.firstname
        } else if cell.tfSignup.tag == RegistrationTextFieldTag.lastNameTextFieldTag.rawValue {
            cell.tfSignup.text =  self.registrationViewModel.lastname
        }else if cell.tfSignup.tag == RegistrationTextFieldTag.usernameTextFieldTag.rawValue {
            cell.tfSignup.text = self.registrationViewModel.username
        }else if cell.tfSignup.tag == RegistrationTextFieldTag.genderTextFieldtag.rawValue {
            cell.tfSignup.text = self.gender
        }else if cell.tfSignup.tag == RegistrationTextFieldTag.emailTextFieldTag.rawValue {
            cell.tfSignup.text = self.registrationViewModel.email
        }else if cell.tfSignup.tag == RegistrationTextFieldTag.passwordTextFieldTag.rawValue {
            cell.tfSignup.text = self.registrationViewModel.pasword
        }
        else if cell.tfSignup.tag == RegistrationTextFieldTag.confirmpasswordTextFieldTag.rawValue {
            cell.tfSignup.text =  self.registrationViewModel.confirmPassword
        }
        else {
            cell.tfSignup.text =  self.registrationViewModel.address
        }
    }
    
    func passwordViewTapped(_ tag: Int) {
        var data = arrRegistrationData[tag]
        data["shouldSecureTextEntry"] = !(data["shouldSecureTextEntry"] as! Bool)
        arrRegistrationData[tag] = data
        let indexPath = IndexPath(row: tag, section: 0)
        self.tableViewSignUP.reloadRows(at: [indexPath], with: .none)
    }
    
    @IBAction func signUpClicked(_ sender: UIButton) {
        if self.registrationViewModel.validate() {
            self.registrationViewModel.signup { (usermodel) in
                CommonUtility.showSuccessCRNotifications(title: appTitle(), message: NSLocalizedString("title.success.registered", comment: "This message will show when the user get successfully registered."))
                if CommonUtility.isPilate() {
                    let mainStoryboard: UIStoryboard = UIStoryboard(name: "Pilates", bundle: nil)
                    let pushVc = mainStoryboard.instantiateViewController(withIdentifier: "DoctorProfileUpdationViewController") as! DoctorProfileUpdationViewController
                    pushVc.profileUpdateViewModel.firstName = self.registrationViewModel.firstname
                    pushVc.profileUpdateViewModel.lastName = self.registrationViewModel.lastname
                    pushVc.profileUpdateViewModel.address = self.registrationViewModel.address
                    self.navigationController?.pushViewController(pushVc, animated: true)
                }else {
                   let vc = self.storyboard?.instantiateViewController(withIdentifier: "SetGoalsViewController") as! SetGoalsViewController
                    vc.setGoalsViewModel.firstname = self.registrationViewModel.firstname
                    vc.setGoalsViewModel.lastname = self.registrationViewModel.lastname
                    vc.setGoalsViewModel.address = self.registrationViewModel.address
                    self.navigationController?.pushViewController(vc, animated: true)
                }
            }
        }
    }
    
    @IBAction func doClickBack(sender : UIButton)
    {
        self.navigationController?.popViewController(animated: true)
    }
    
    @IBAction func doClickReferenceCode(sender : UIButton)
    {
        if self.registrationViewModel.validate() {
            let vc = self.storyboard?.instantiateViewController(withIdentifier: "ReferenceViewController") as! ReferenceViewController
            vc.referenceViewModel.email = self.registrationViewModel.email
            vc.referenceViewModel.username = self.registrationViewModel.username
            vc.referenceViewModel.password = self.registrationViewModel.pasword
            vc.referenceViewModel.firstname = self.registrationViewModel.firstname
            vc.referenceViewModel.lastname = self.registrationViewModel.lastname
            vc.referenceViewModel.address = self.registrationViewModel.address
            vc.referenceViewModel.gender = self.registrationViewModel.gender
            self.navigationController?.pushViewController(vc, animated: true)
        }
    }
    
    override func touchesBegan(_ touches: Set<UITouch>, with event: UIEvent?) {
        self.view.endEditing(true)
    }
}

extension RegistrationViewController: RegistrationInputCellDelegate {
    func inputCell(_ cell: RegistrationTableViewCell, didChangeText text: String?) {
        if cell.tfSignup.tag == RegistrationTextFieldTag.firstNameTextFieldTag.rawValue {
            self.registrationViewModel.firstname = text!
        } else if cell.tfSignup.tag == RegistrationTextFieldTag.lastNameTextFieldTag.rawValue {
            self.registrationViewModel.lastname = text!
        }else if cell.tfSignup.tag == RegistrationTextFieldTag.usernameTextFieldTag.rawValue {
            self.registrationViewModel.username = text!
        }else if cell.tfSignup.tag == RegistrationTextFieldTag.emailTextFieldTag.rawValue {
            self.registrationViewModel.email = text!
        }else if cell.tfSignup.tag == RegistrationTextFieldTag.passwordTextFieldTag.rawValue {
            self.registrationViewModel.pasword = text!
        }
        else if cell.tfSignup.tag == RegistrationTextFieldTag.confirmpasswordTextFieldTag.rawValue {
            self.registrationViewModel.confirmPassword = text!
            }
        else {
            self.registrationViewModel.address = text!
        }
    }
}
