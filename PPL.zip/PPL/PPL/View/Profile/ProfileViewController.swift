//
//  NewProfileViewController.swift
//  PilateImageDetail
//
//  Created by TanjeetAjmani on 02/05/18.
//  Copyright © 2018 TanjeetAjmani. All rights reserved.
//

import UIKit
import ActionSheetPicker_3_0
import SDWebImage

enum ProfileTextFieldTag: Int {
    case medicalTextFieldTag = 100
    case firstNameTextFieldTag
    case lastNameTextFieldTag
}

class ProfileViewController: UIViewController,UIImagePickerControllerDelegate,UINavigationControllerDelegate {
    
    @IBOutlet weak var lblGoalPercentage: UILabel!
    @IBOutlet weak var lblGoalKg: UILabel!
    @IBOutlet weak var btnCompose: UIButton!
    @IBOutlet weak var img2: UIImageView!
    @IBOutlet weak var img1: UIImageView!
    @IBOutlet weak var btnChangePasswrd: UIButton!
    @IBOutlet weak var lblName: UILabel!
    @IBOutlet weak var tfMedicalDetail: UITextField!
    @IBOutlet weak var lblGoal2: UILabel!
    @IBOutlet weak var lblGoal1: UILabel!
    @IBOutlet weak var lblAge: UILabel!
    @IBOutlet weak var lblMedicalConditn: UILabel!
    @IBOutlet weak var btnAgeDetail: UIButton!
    @IBOutlet weak var btnGoal2Detail: UIButton!
    @IBOutlet weak var btnGoal1Detail: UIButton!
    @IBOutlet weak var tfAgeDetail: UITextField!
    @IBOutlet weak var btnWeightDetail: UIButton!
    @IBOutlet weak var btnDobDetail: UIButton!
    @IBOutlet weak var btnHeightDetail: UIButton!
    @IBOutlet weak var tfEmailDetail: UITextField!
    @IBOutlet weak var tfUsernameDetail: UITextField!
    @IBOutlet weak var lblEmail: UILabel!
    @IBOutlet weak var lblUsername: UILabel!
    @IBOutlet weak var lblHeight: UILabel!
    @IBOutlet weak var lblWeight: UILabel!
    @IBOutlet weak var lblDOB: UILabel!
    @IBOutlet weak var imageProfile: UIImageView!
    @IBOutlet weak var lblLastName: UILabel!
    @IBOutlet weak var viewUserImg: UIView!
    @IBOutlet weak var viewBox: UIView!
    @IBOutlet weak var lblFirstName: UILabel!
    @IBOutlet weak var tfFirstName: UITextField!
    
    @IBOutlet weak var viewBg: UIView!
    @IBOutlet weak var tfAddress: UITextField!
    @IBOutlet weak var lblAddress: UILabel!
    @IBOutlet weak var tfLastName: UITextField!
    var userModel: UserModel = CommonUtility.userProfile()!
    var profileUpdateViewModel = ProfileUpdateViewModel()
    
    var heightSelectionIndex0 = 0
    var heightSelectionIndex1 = 0
    var weightSelectionIndex = 0
    var goal1SelectionIndex = 0
    var goal2SelectionIndex = 0
    var ageSelectionIndex = 0
    var max = Date()
    var age : Int?
    
    var arrGoals = ["Weight Loss"]
    var arrGoalWeight = ["40 kgs","45 kgs","50 kgs","55 kgs","60 kgs","65 kgs","70 kgs","75 kgs","80 kgs"]
    var arrWeight = ["30 kgs","31 kgs","32 kgs","33 kgs","34 kgs","35 kgs" ,"36 kgs","37 kgs","38 kgs","39 kgs","40 kgs","41 kgs","42 kgs","43 kgs","44 kgs","45 kgs" ,"46 kgs","47 kgs","48 kgs","49 kgs","50 kgs","51 kgs","52 kgs","53 kgs","54 kgs","55 kgs" ,"56 kgs","57 kgs","58 kgs","59 kgs","60 kgs","61 kgs","62 kgs","63 kgs","64 kgs","65 kgs" ,"66 kgs","67 kgs","68 kgs","69 kgs","70 kgs","71 kgs","72 kgs","73 kgs","74 kgs","75 kgs" ,"76 kgs","77 kgs","78 kgs","79 kgs","80 kgs","81 kgs","82 kgs","83 kgs","84 kgs","85 kgs" ,"86 kgs","87 kgs","88 kgs","89 kgs","90 kgs","91 kgs","92 kgs","93 kgs","94 kgs","95 kgs" ,"96 kgs","97 kgs","98 kgs","99 kgs","100 kgs","101 kgs","102 kgs","103 kgs","104 kgs","105 kgs" ,"106 kgs","107 kgs","108 kgs","109 kgs","110 kgs","111 kgs","112 kgs","113 kgs","114 kgs","115 kgs" ,"116 kgs","117 kgs","118 kgs","119 kgs","120 kgs"]
    
    var arrHeight =  [
        ["2 ft", "3 ft", "4 ft", "5 ft" , "6 ft", "7 ft" ,"8 ft" ,"9 ft", "10 ft"],
        ["0 in"," 1 in","2 in", "3 in", "4 in", "5 in" , "6 in", "7 in" ,"8 in" ,"9 in", "10 in" ,"11 in","12 in"]
    ]
    
    var arrAge = ["18", "19", "20","21","22","23","24","25","26", "27", "28","29","30","31","32","33","34", "35", "36","37","38","39","40","41","42", "43", "44","45","46","47","48","49","50", "51", "52","53","54","55","56","57","58", "59", "60","61","62","63","64","65","66", "67", "68","69","70","71","72","73","74", "75", "76","77","78","79","80","81","82", "83", "84","85","86","87","88","89","90", "91", "92","93","94","95","96","97","98", "99"]
    
    let imagePicker = UIImagePickerController()
    
    override func viewDidLoad() {
        super.viewDidLoad()
        self.styleUI()
        self.updateViewModelVariables()
        self.getProfileList()
        self.styleNavigationBar()
    }
    
    override func viewWillAppear(_ animated: Bool) {
        super.viewWillAppear(true)
        self.navigationController?.isNavigationBarHidden = false
    }
    
    func styleUI()
    {
        self.viewBox.layer.borderWidth = 1
        self.viewBox.layer.borderColor = UIColor.init(red: 45/255.0, green: 46/255.0, blue: 44/255.0, alpha: 0.1).cgColor
        viewBg.dropShadow(color: .lightGray, opacity: 1, offSet: CGSize(width: -1, height: 1), radius: 3, scale: true)
        btnDobDetail.contentHorizontalAlignment = .left
        btnHeightDetail.contentHorizontalAlignment = .left
        btnWeightDetail.contentHorizontalAlignment = .left
        btnGoal2Detail.contentHorizontalAlignment = .left
        btnGoal1Detail.contentHorizontalAlignment = .left
        
        DecorateControls.styleLabel(label: lblName, text: " \(userModel.result.firstname!) \(userModel.result.lastname!)", font: UIFont.systemFont(ofSize: FONT_SIZE_28), textColor: blackColor())
        
        DecorateControls.styleLabel(label: lblUsername , text: "Username:", font: UIFont.boldSystemFont(ofSize: FONT_SIZE_17), textColor: color(red: 116, green: 116, blue: 116))
        
        DecorateControls.putText(textField: tfUsernameDetail, text: userModel.result.username, placehoder: "Regina", font: UIFont.boldSystemFont(ofSize: FONT_SIZE_17), textColor: color(red: 116, green: 116, blue: 116))
        
        DecorateControls.styleLabel(label: lblEmail , text: "Email          :", font: UIFont.boldSystemFont(ofSize: FONT_SIZE_17), textColor: color(red: 116, green: 116, blue: 116))
        
        DecorateControls.putText(textField: tfEmailDetail, text: userModel.result.email, placehoder: "regina@gmail.com", font: UIFont.boldSystemFont(ofSize: FONT_SIZE_17), textColor: color(red: 116, green: 116, blue: 116))
        
        DecorateControls.styleLabel(label: lblDOB , text: "D.O.B         :", font: UIFont.boldSystemFont(ofSize: FONT_SIZE_17), textColor: color(red: 116, green: 116, blue: 116))
        
        DecorateControls.putTitle(button: btnDobDetail, text: userModel.result.dob, font: UIFont.boldSystemFont(ofSize: FONT_SIZE_17), textColor: color(red: 116, green: 116, blue: 116), backGroundColor: UIColor.clear)
        
        DecorateControls.styleLabel(label: lblWeight , text: "Weight      :", font: UIFont.boldSystemFont(ofSize: FONT_SIZE_17), textColor: color(red: 116, green: 116, blue: 116))
        
        DecorateControls.putTitle(button: btnWeightDetail, text: userModel.result.weight, font: UIFont.boldSystemFont(ofSize: FONT_SIZE_17), textColor: color(red: 116, green: 116, blue: 116), backGroundColor: UIColor.clear)
        
        DecorateControls.styleLabel(label: lblHeight , text: "Height       :", font: UIFont.boldSystemFont(ofSize: FONT_SIZE_17), textColor: color(red: 116, green: 116, blue: 116))
        
        DecorateControls.putTitle(button: btnHeightDetail, text: userModel.result.height, font: UIFont.boldSystemFont(ofSize: FONT_SIZE_17), textColor: color(red: 116, green: 116, blue: 116), backGroundColor: UIColor.clear)
        
        DecorateControls.styleLabel(label: lblAge , text: "Age            :", font: UIFont.boldSystemFont(ofSize: FONT_SIZE_17), textColor: color(red: 116, green: 116, blue: 116))
        //"\(CommonUtility.getAge(selectedDateValue: userModel.result.dob!))"
        DecorateControls.putTitle(button: btnAgeDetail, text: "20", font: UIFont.boldSystemFont(ofSize: FONT_SIZE_15), textColor: color(red: 116, green: 116, blue: 116), backGroundColor: UIColor.clear)
        
        DecorateControls.styleLabel(label: lblGoal1 , text: "Goal1         :", font: UIFont.boldSystemFont(ofSize: FONT_SIZE_17), textColor: color(red: 116, green: 116, blue: 116))
        
        DecorateControls.putTitle(button: btnGoal1Detail, text: "Weight Loss", font: UIFont.boldSystemFont(ofSize: FONT_SIZE_17), textColor: color(red: 116, green: 116, blue: 116), backGroundColor: UIColor.clear)
        
        DecorateControls.styleLabel(label: lblGoal2 , text: "Goal2        :", font: UIFont.boldSystemFont(ofSize: FONT_SIZE_17), textColor: color(red: 116, green: 116, blue: 116))
        
        DecorateControls.putTitle(button: btnGoal2Detail, text: "Muscle Strength", font: UIFont.boldSystemFont(ofSize: FONT_SIZE_17), textColor: color(red: 116, green: 116, blue: 116), backGroundColor: UIColor.clear)
        
        DecorateControls.styleLabel(label: lblMedicalConditn , text: "Medical Condition(if Any) :", font: UIFont.boldSystemFont(ofSize: FONT_SIZE_17), textColor: color(red: 116, green: 116, blue: 116))
        
        DecorateControls.putText(textField: tfMedicalDetail, text: "", placehoder: "None", font: UIFont.boldSystemFont(ofSize: FONT_SIZE_17), textColor: color(red: 116, green: 116, blue: 116))
        
        DecorateControls.styleLabel(label: lblFirstName , text: "First Name:", font: UIFont.boldSystemFont(ofSize: FONT_SIZE_17), textColor: color(red: 116, green: 116, blue: 116))
        
        DecorateControls.putText(textField: tfFirstName, text: userModel.result.firstname, placehoder: "Enter First Name", font: UIFont.boldSystemFont(ofSize: FONT_SIZE_17), textColor: color(red: 116, green: 116, blue: 116))
        
        DecorateControls.styleLabel(label: lblLastName , text: "Last Name:", font: UIFont.boldSystemFont(ofSize: FONT_SIZE_17), textColor: color(red: 116, green: 116, blue: 116))
        
        DecorateControls.putText(textField: tfLastName, text: userModel.result.lastname, placehoder: "Enter Last Name", font: UIFont.boldSystemFont(ofSize: FONT_SIZE_17), textColor: color(red: 116, green: 116, blue: 116))
        
        DecorateControls.styleLabel(label: lblAddress , text: "Address                                 :", font: UIFont.boldSystemFont(ofSize: FONT_SIZE_17), textColor: color(red: 116, green: 116, blue: 116))
        
        DecorateControls.putText(textField: tfAddress, text: userModel.result.address, placehoder: "Enter Address", font: UIFont.boldSystemFont(ofSize: FONT_SIZE_17), textColor: color(red: 116, green: 116, blue: 116))
        
        DecorateControls.putTitle(button: btnChangePasswrd, text: "Change Password", font: UIFont.boldSystemFont(ofSize: FONT_SIZE_24), textColor: whiteColor(), backGroundColor: appColor())
        
        self.btnCompose.layer.cornerRadius = 10
        self.btnChangePasswrd.layer.cornerRadius = 10
        tfMedicalDetail.attributedPlaceholder = NSAttributedString(string: "None", attributes: [NSAttributedStringKey.foregroundColor : UIColor.init(red: 116/255.0 , green: 116/255.0, blue: 116/255.0, alpha: 1)])
        self.btnCompose.setImage(#imageLiteral(resourceName: "edit"), for: .normal)
        self.btnCompose.setImage(#imageLiteral(resourceName: "icon_update_s5"), for: .selected)
        self.btnCompose.setImage(nil, for: .highlighted)
        
        self.imageProfile.sd_setImage(with: URL(string: userModel.result.profile_image!), placeholderImage: #imageLiteral(resourceName: "no-inage"))
        self.tfEmailDetail.isEnabled = false
        self.tfUsernameDetail.isEnabled = false
        self.tfAddress.isEnabled = false
        self.tfFirstName.isEnabled = false
        self.tfLastName.isEnabled = false
        self.updateControlsState(shouldEnabled: false)
        
         self.tfEmailDetail.attributedPlaceholder = NSAttributedString(string: "Enter Email",attributes: [NSAttributedStringKey.foregroundColor: color(red: 116, green: 116, blue: 116)])
        
          self.tfUsernameDetail.attributedPlaceholder = NSAttributedString(string: "Enter Username",attributes: [NSAttributedStringKey.foregroundColor: color(red: 116, green: 116, blue: 116)])
        
         self.tfAddress.attributedPlaceholder = NSAttributedString(string: "Enter Address",attributes: [NSAttributedStringKey.foregroundColor: color(red: 116, green: 116, blue: 116)])
        
      self.tfFirstName.attributedPlaceholder = NSAttributedString(string: "Enter First Name",attributes: [NSAttributedStringKey.foregroundColor: color(red: 116, green: 116, blue: 116)])
        
     self.tfLastName.attributedPlaceholder = NSAttributedString(string: "Enter Last Name",attributes: [NSAttributedStringKey.foregroundColor: color(red: 116, green: 116, blue: 116)])
        
        self.tfMedicalDetail.tag = ProfileTextFieldTag.medicalTextFieldTag.rawValue
        self.tfFirstName.tag = ProfileTextFieldTag.firstNameTextFieldTag.rawValue
        self.tfLastName.tag = ProfileTextFieldTag.lastNameTextFieldTag.rawValue
        
        
        let tapG = UITapGestureRecognizer.init(target: self, action: #selector(self.profileImageClicked(sender:)))
        tapG.numberOfTapsRequired = 1
        self.imageProfile.addGestureRecognizer(tapG)
        self.imagePicker.delegate = self
        self.tfLastName.delegate = self
        self.tfFirstName.delegate = self
        self.tfMedicalDetail.delegate = self
        self.tfAddress.delegate = self
        self.btnAgeDetail.isEnabled = false
        
        self.profileUpdateViewModel.firstName = self.userModel.result.firstname
        self.profileUpdateViewModel.lastName = self.userModel.result.lastname
        self.profileUpdateViewModel.address = self.userModel.result.address
    }
    
    func updateViewModelVariables() {
        self.profileUpdateViewModel.dob = self.userModel.result.dob
        self.profileUpdateViewModel.weight = self.userModel.result.weight
        if let goals = userModel.result.goals {
            let arrGoals = goals.components(separatedBy: ",")
            if (arrGoals.count) > 0 {
                self.profileUpdateViewModel.goal1 = arrGoals[0]
                btnGoal1Detail.setTitle(self.profileUpdateViewModel.goal1, for: .normal)
            }
            if (arrGoals.count) > 1 {
                self.profileUpdateViewModel.goal2 = arrGoals[1]
                btnGoal2Detail.setTitle(self.profileUpdateViewModel.goal2, for: .normal)
            }
        }
        self.profileUpdateViewModel.height = self.userModel.result.height
        self.profileUpdateViewModel.medicalCondition = self.userModel.result.medical_history
        self.profileUpdateViewModel.profileImage = self.imageProfile.image
    }
    
    func styleNavigationBar()
    {
        if navigationController?.viewControllers.count == 1 {
            CommonUtility.createCustomBackButton(self, navBarItem: self.navigationItem, strImage: "menu_slide", select: #selector(doClickSideMenu))
        }
        else {
            CommonUtility.createCustomBackButton(self, navBarItem: self.navigationItem, strImage: "back_icon _white", select: #selector(openPopView))
        }
        
        CommonUtility.setNavBarTitle(self.navigationItem, title: NSLocalizedString("Profile", comment: "The title of the Profile navigation bar"))
        
        CommonUtility.createRightBarOnlyHomeButtons(target: self, navigationItem: self.navigationItem, select1: #selector(openDashBoardView))
    }
    
    @objc func openPopView() {
    self.navigationController?.popViewController(animated: true)
    }
    
    @objc func openProfileView()
    {
        self.navigationController?.pushViewController((self.storyboard?.instantiateViewController(withIdentifier: "ProfileViewController"))!, animated: true)
    }
    
    @objc func openNotificationsView()
    {
        self.navigationController?.pushViewController((self.storyboard?.instantiateViewController(withIdentifier: "NotificationsViewController"))!, animated: true)
    }
    
    @objc func openSettingsView()
    {
        self.navigationController?.pushViewController((self.storyboard?.instantiateViewController(withIdentifier: "SettingsViewController"))!, animated: true)
    }
    
    @objc func openDashBoardView()
    {
        CommonUtility.setMenuSelectedOption(menuOptionIndex:0)
        let centerVC : UIViewController
        let storyboard =  UIStoryboard(name: "Main", bundle: nil)
        centerVC = storyboard.instantiateViewController(withIdentifier: "DashboardViewController")
        let centerNavVC = UINavigationController(rootViewController: centerVC)
        self.panel?.configs.centerPanelTransitionType = .moveLeft
        self.panel?.configs.centerPanelTransitionDuration = 1.0
        _ = panel?.center(centerNavVC)
    }
    
    //MARK: - Navigation Bar Methods
    @objc func doClickSideMenu()
    {
        panel?.openLeft(animated: true)
    }
    
    override func viewDidLayoutSubviews() {
        super.viewDidLayoutSubviews()
        
        viewUserImg.layer.borderWidth = 1
        viewUserImg.layer.borderColor = UIColor.gray.cgColor
        viewUserImg.layer.masksToBounds = true
        viewUserImg.layer.cornerRadius = viewUserImg.frame.height/2
        viewUserImg.clipsToBounds = true
        
        imageProfile.layer.borderWidth = 1
        imageProfile.layer.masksToBounds = true
        imageProfile.layer.cornerRadius = imageProfile.frame.height/2
        imageProfile.clipsToBounds = true
    }
    
    @objc func profileImageClicked(sender: UITapGestureRecognizer? = nil){
        let alert : UIAlertController = UIAlertController(title: "Choose Image", message: nil, preferredStyle: UIAlertControllerStyle.actionSheet)
        let cameraAction = UIAlertAction(title: "Camera", style: UIAlertActionStyle.default)
        {
            UIAlertAction in
            self.openCamera()
        }
        let gallaryAction = UIAlertAction(title: "Gallery", style: UIAlertActionStyle.default)
        {
            UIAlertAction in
            self.openGallary()
        }
        let cancelAction = UIAlertAction(title: "Cancel", style: UIAlertActionStyle.cancel)
        {
            UIAlertAction in
        }
        self.imagePicker.modalPresentationStyle = .overCurrentContext
        alert.addAction(cameraAction)
        alert.addAction(gallaryAction)
        alert.addAction(cancelAction)
        if let popoverController = alert.popoverPresentationController {
            popoverController.sourceView = self.imageProfile
            popoverController.sourceRect = self.imageProfile.bounds
        }
        self.present(alert, animated: true, completion: nil)
    }
    func openCamera()
    {
        if(UIImagePickerController .isSourceTypeAvailable(UIImagePickerControllerSourceType.camera))
        {
            imagePicker.sourceType = .camera
            self .present(imagePicker, animated: true, completion: nil)
        }
        else
        {
            let alert = UIAlertController(title: "Warning", message: "You don't have camera", preferredStyle: UIAlertControllerStyle.alert)
            alert.addAction(UIAlertAction(title: "Ok", style: UIAlertActionStyle.default, handler: nil))
            self.present(alert, animated: true, completion: nil)
        }
    }
    
    func openGallary()
    {
        imagePicker.sourceType = .savedPhotosAlbum
        self.present(imagePicker, animated: true, completion: nil)
    }
    
    func imagePickerController(_ picker: UIImagePickerController, didFinishPickingMediaWithInfo info: [String : Any]) {
        let chosenImage = info[UIImagePickerControllerOriginalImage] as! UIImage
        let selectedImage : UIImage = chosenImage
        imageProfile.image = selectedImage
        self.profileUpdateViewModel.profileImage = selectedImage
        self.dismiss(animated: true, completion: nil)
    }
    
    func imagePickerControllerDidCancel(_ picker: UIImagePickerController) {
        self.dismiss(animated: true, completion: nil)
    }
    
    @IBAction func btnChangePasswordActn(_ sender: UIButton) {
        self.navigationController?.pushViewController((self.storyboard?.instantiateViewController(withIdentifier: "ChangePasswordViewController"))!, animated: true)
    }
    
    @IBAction func btnComposeActn(_ sender: UIButton) {
        if self.btnCompose.isSelected {
           alertViewController()
        }else {
            self.btnCompose.isSelected = !self.btnCompose.isSelected
        }
        self.updateControlsState(shouldEnabled: btnCompose.isSelected)
    }
    func alertViewController() {
        let alert = UIAlertController(title: "Alert", message: "Do you want to update your Profile?", preferredStyle: UIAlertControllerStyle.alert)
        alert.addAction(UIAlertAction(title: "Yes", style: .default, handler: { action in
            switch action.style{
            case .default:
                if self.profileUpdateViewModel.validated() {
                    self.btnCompose.isSelected = false
                    self.profileUpdateViewModel.updateProfile()
                }
            case .cancel:
                print("cancel")
            case .destructive:
                print("destructive")
            }}))
        alert.addAction(UIAlertAction(title: "No", style: .cancel, handler: { action in
            switch action.style{
            case .default:
                print("default")
                
            case .cancel:
                print("cancel")
                
            case .destructive:
                print("destructive")
            }}))
        self.present(alert, animated: true, completion: nil)
    }
    func updateControlsState(shouldEnabled: Bool) {
        self.tfMedicalDetail.isEnabled = shouldEnabled
        self.btnWeightDetail.isEnabled = shouldEnabled
        self.btnHeightDetail.isEnabled = shouldEnabled
        self.btnGoal1Detail.isEnabled  = shouldEnabled
        self.btnGoal2Detail.isEnabled  = shouldEnabled
        self.btnDobDetail.isEnabled    = shouldEnabled
        self.tfFirstName.isEnabled     = shouldEnabled
        self.tfLastName.isEnabled      = shouldEnabled
        self.tfAddress.isEnabled       = shouldEnabled
        self.imageProfile.isUserInteractionEnabled = shouldEnabled
    }
    
    @IBAction func btnGoal1Actn(_ sender: UIButton) {
        ActionSheetStringPicker.show(withTitle: "Set Goal", rows: arrGoals, initialSelection: goal1SelectionIndex, doneBlock: {
            picker, value, index in
            let indexx = index
            self.btnGoal1Detail.setTitle(indexx as? String, for: .normal)
            self.goal1SelectionIndex = value
            self.profileUpdateViewModel.goal1 = indexx as? String
            return
        }, cancel: { ActionStringCancelBlock in return }, origin: sender)
    }
    
    @IBAction func btnGoal2Actn(_ sender: UIButton) {
        ActionSheetStringPicker.show(withTitle: "Target", rows: arrGoalWeight, initialSelection: goal2SelectionIndex, doneBlock: {
            picker, value, index in
            let indexx = index
            self.btnGoal2Detail.setTitle(indexx as? String, for: .normal)
            self.goal2SelectionIndex = value
            self.profileUpdateViewModel.goal2 = indexx as? String
            return
        }, cancel: { ActionStringCancelBlock in return }, origin: sender)
    }
    
    @IBAction func btnHeightActn(_ sender: UIButton) {
        ActionSheetMultipleStringPicker.show(withTitle: "Height", rows: arrHeight, initialSelection: [heightSelectionIndex0 , heightSelectionIndex1], doneBlock: {
            picker , values , indexes in
            var heightValues = indexes as! [String]
            self.btnHeightDetail.setTitle("\(heightValues[0]) \(heightValues[1])", for: .normal)
            let  selectn0 = values![0]
            let selectn1 = values![1]
            self.heightSelectionIndex0 = (selectn0 as? Int)!
            self.heightSelectionIndex1 = (selectn1 as? Int)!
            self.profileUpdateViewModel.height = "\(heightValues[0]) \(heightValues[1])"
            return
        }, cancel: { ActionMultipleStringCancelBlock in return }, origin: sender)
    }
    
    @IBAction func btnWeightActn(_ sender: UIButton) {
        ActionSheetStringPicker.show(withTitle: "Weight", rows: arrWeight, initialSelection: weightSelectionIndex, doneBlock: {
            picker, value, index in
            let indexx = index
            self.btnWeightDetail.setTitle(indexx as? String, for: .normal)
            self.weightSelectionIndex = value
            self.profileUpdateViewModel.weight = indexx as! String
            return
        }, cancel: { ActionStringCancelBlock in return }, origin: sender)
    }
    
    @IBAction func btnDobActn(_ sender: UIButton) {
        
        let datePicker = ActionSheetDatePicker(title: "Date:", datePickerMode: UIDatePickerMode.date, selectedDate: max, doneBlock: {
            picker, value, index in
            let dateFormatter = DateFormatter()
            dateFormatter.dateFormat = "MM/dd/yyyy"
            let selectedDate = dateFormatter.string(from: value as! Date)
            self.btnAgeDetail.setTitle("\(CommonUtility.getAge(selectedDateValue: selectedDate))", for: .normal)
            self.max = dateFormatter.date(from: selectedDate)!
            self.btnDobDetail.setTitle(selectedDate , for: .normal)
            self.profileUpdateViewModel.dob = selectedDate
            return
        }, cancel: { ActionStringCancelBlock in return }, origin: sender )
        let secondsInWeek: TimeInterval = 1 * 365 * 24 * 60 * 60;
        datePicker?.minimumDate = Date(timeInterval: -18 * secondsInWeek, since: Date())
        datePicker?.maximumDate = Date()
        datePicker?.show()
    }
    
    override func touchesBegan(_ touches: Set<UITouch>, with event: UIEvent?) {
        self.view.endEditing(true)
    }
    
    func getProfileList() {
        if profileUpdateViewModel.firstName == nil {
            CommonUtility.loadNoDataFound(vc: self,message: NSLocalizedString("title.error.nodata", comment: "Showing no data found."))
        }
    }
}

extension ProfileViewController: UITextFieldDelegate {
    func textField(_ textField: UITextField, shouldChangeCharactersIn range: NSRange, replacementString string: String) -> Bool {
        if let text = textField.text as NSString? {
            let txtAfterUpdate = text.replacingCharacters(in: range, with: string)
            if textField.tag == ProfileTextFieldTag.medicalTextFieldTag.rawValue {
                self.profileUpdateViewModel.medicalCondition = txtAfterUpdate
            } else if textField.tag == ProfileTextFieldTag.firstNameTextFieldTag.rawValue {
                self.profileUpdateViewModel.firstName = txtAfterUpdate
            } else if textField.tag == ProfileTextFieldTag.lastNameTextFieldTag.rawValue {
                self.profileUpdateViewModel.lastName = txtAfterUpdate
            }else {
                self.profileUpdateViewModel.address = txtAfterUpdate
            }
        }
        return true
    }
}

