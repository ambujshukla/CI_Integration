//
//  ViewController.swift
//  NewReference
//
//  Created by PujaDwivedi on 26/04/18.
//  Copyright © 2018 PujaDwivedi. All rights reserved.
//

import UIKit
import CRNotifications

enum ReferenceTextFieldTag: Int {
    case referalCodeTextFieldTag = 100
    case mobileTextFieldTag
}

class ReferenceViewController: UIViewController {
    
    @IBOutlet weak var btnBack: UIButton!
    @IBOutlet weak var lblReference: UILabel!
    @IBOutlet weak var tfMobile: UITextField!
    @IBOutlet weak var imgMobileIcon: UIImageView!
    @IBOutlet weak var tfReferal: UITextField!
    @IBOutlet weak var imgReferalIcon: UIImageView!
    @IBOutlet weak var btnContinue: UIButton!
    @IBOutlet weak var lblHeader: UILabel!
    @IBOutlet weak var imgReferenceHeader: UIImageView!
    @IBOutlet weak var bgImage: UIImageView!
    @IBOutlet weak var btnReference : UIButton!
    
    var referenceViewModel = ReferenceViewModel()

    override func viewDidLoad(){
        super.viewDidLoad()
        self.styleUI()
    }
    
    func styleUI() {
        self.bgImage.image = #imageLiteral(resourceName: "background_img")
        self.imgReferenceHeader.image = #imageLiteral(resourceName: "reference_icon")
        self.imgReferalIcon.image = #imageLiteral(resourceName: "referance_code_icon")
        self.imgMobileIcon.image = #imageLiteral(resourceName: "mobi")
        self.lblHeader.textAlignment = NSTextAlignment.center
        DecorateControls.styleLabel(label: lblHeader, text: "Got a Reference Code?", font: UIFont.boldSystemFont(ofSize: FONT_SIZE_35), textColor: blackColor())
        
        DecorateControls.putTitle(button: btnContinue, text: "Continue", font: UIFont.boldSystemFont(ofSize: FONT_SIZE_28), textColor: whiteColor(), backGroundColor: appColor())
        
        DecorateControls.putText(textField: tfReferal, text: "", placehoder: "Referral Code", font: UIFont.boldSystemFont(ofSize: FONT_SIZE_18), textColor: UIColor.darkGray)
        
        DecorateControls.putText(textField: tfMobile, text: "", placehoder: "Mobile Number", font: UIFont.boldSystemFont(ofSize: FONT_SIZE_18), textColor: UIColor.darkGray)
        
        DecorateControls.styleLabel(label: lblReference, text: "Get reference as assigned Pilate?", font: UIFont.boldSystemFont(ofSize: FONT_SIZE_18), textColor: color(red: 116, green: 116, blue: 116))
        
        DecorateControls.putTitle(button: btnReference, text: "Get reference as assigned Pilate?", font: UIFont.boldSystemFont(ofSize: FONT_SIZE_18), textColor: color(red: 116, green: 116, blue: 116), backGroundColor: clearColor())
        
        self.btnBack.setImage(#imageLiteral(resourceName: "back_icon"), for: .normal)
        self.btnReference.setImage(#imageLiteral(resourceName: "uncheck_box"), for: .normal)
        self.btnReference.setImage(#imageLiteral(resourceName: "check_box"), for: .selected)
        
        self.btnContinue.layer.cornerRadius = 5
        self.tfMobile.keyboardType = UIKeyboardType.decimalPad
        
        tfReferal.attributedPlaceholder = NSAttributedString(string: "Referral Code",attributes: [NSAttributedStringKey.foregroundColor: UIColor.darkGray])
        tfMobile.attributedPlaceholder = NSAttributedString(string: "Mobile Number",attributes: [NSAttributedStringKey.foregroundColor: UIColor.darkGray])
        
        self.tfMobile.delegate = self
        self.tfReferal.delegate = self
        
        self.tfReferal.tag = ReferenceTextFieldTag.referalCodeTextFieldTag.rawValue
        self.tfMobile.tag = ReferenceTextFieldTag.mobileTextFieldTag.rawValue
    }
    
    @IBAction func doClickBackButton(sender: UIButton) {
        self.navigationController?.popViewController(animated: true)
    }
    
    @IBAction func doClickContinueBtn(_ sender: UIButton) {
        if self.referenceViewModel.validate() {
            self.referenceViewModel.signup { (userModel) in
                CommonUtility.showSuccessCRNotifications(title: appTitle(), message: NSLocalizedString("title.success.registered", comment: "This message will show when the user get successfully registered."))
                self.navigationController?.pushViewController((self.storyboard?.instantiateViewController(withIdentifier: "SetGoalsViewController"))!, animated: true)
            }
        }
    }
    
    @IBAction func doClickReferenceBtn(sender: UIButton) {
        self.btnReference.isSelected = !self.btnReference.isSelected
    }
    
    override func touchesBegan(_ touches: Set<UITouch>, with event: UIEvent?) {
        self.view.endEditing(true)
    }
}

extension ReferenceViewController: UITextFieldDelegate {
    func textField(_ textField: UITextField, shouldChangeCharactersIn range: NSRange, replacementString string: String) -> Bool {
        if let text = textField.text as NSString? {
            let txtAfterUpdate = text.replacingCharacters(in: range, with: string)
            if textField.tag == ReferenceTextFieldTag.referalCodeTextFieldTag.rawValue {
                self.referenceViewModel.referalCode = txtAfterUpdate
            }else {
                self.referenceViewModel.phoneNumber = txtAfterUpdate
            }
        }
        return true
    }
}
