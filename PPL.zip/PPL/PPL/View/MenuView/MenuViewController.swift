
//
//  MenuViewController.swift
//  PPL
//
//  Created by cdn68 on 27/04/18.
//  Copyright © 2018 cdn. All rights reserved.
//

import UIKit
import FAPanels

enum MenuOptionsSelected : Int {
    case dashboard
    case pilates
    case myAppointments
    case myExercises
    case forum
    case myPilateInstructor
  //  case myProgess
    case profile
    case notifications
    case settings
    case logout
}

enum PilateMenuOptionsSelected : Int {
    case dashboard
    case clients
    case schedule
    case myExercises
    case forum
    case profile
    case notifications
    case settings
    case logout
}

class MenuViewController: UIViewController, UITableViewDelegate, UITableViewDataSource, FAPanelStateDelegate {
    
    //MARK: - Private
    var arrDashboardData = [[String : Any]]()
    var arrDashboardPilateData = [[String : Any]]()
    
    @IBOutlet fileprivate weak var imgHeader : UIImageView!
    @IBOutlet fileprivate weak var imgHeaderLogo : UIImageView!
    @IBOutlet fileprivate weak var lblHeader : UILabel!
    @IBOutlet fileprivate weak var menuTableView : UITableView!
    
    override func viewDidLoad() {
        super.viewDidLoad()
        self.styleUI()
        self.configureInitialParameters()
        self.panel?.delegate = self as FAPanelStateDelegate
    }
    
    private func styleUI()
    {
        self.imgHeader.backgroundColor = appColor()
        self.imgHeaderLogo.image = UIImage(named : "menu_logo")
        self.lblHeader.text = appTitle()
        self.view.backgroundColor = color(red: 48, green: 48, blue: 48)
        self.imgHeaderLogo.contentMode = .scaleAspectFit
        self.menuTableView.backgroundColor = UIColor.clear
        self.menuTableView.preventEmptyCellSeparators()
        self.menuTableView.preventMarginInheritance()
        self.menuTableView.separatorColor = color(red: 46, green: 46, blue: 46)
        
        let attrs11 = [NSAttributedStringKey.font : UIFont.boldSystemFont(ofSize: 28), NSAttributedStringKey.foregroundColor : UIColor.black]
        let attrs22 = [NSAttributedStringKey.font : UIFont.systemFont(ofSize: 28), NSAttributedStringKey.foregroundColor : UIColor.black]
        
        let attributedString11 = NSMutableAttributedString(string:"Patient ", attributes:attrs11)
        let attributedString22 = NSMutableAttributedString(string:"Pilates", attributes:attrs22)
        
        attributedString11.append(attributedString22)
        self.lblHeader.attributedText = attributedString11
    }
    
    private func configureInitialParameters()
    {
        if CommonUtility.isPilate() {
            
            self.arrDashboardPilateData = [["title" : "Dashboard", "selectedimage" : "menu_dashboard_selected", "unselectedImage" : "menu_dashboard_unselected"],["title" : "Clients", "selectedimage" : "menu_pilates_select", "unselectedImage" : "menu_pilates_unselect"],["title" : "Schedule", "selectedimage" : "menu_appinment_select", "unselectedImage" : "menu_appoinment_unselect"],["title" : "My Exercises",  "selectedimage" : "menu_excerise_select", "unselectedImage" : "menu_excerise_unselect"],["title" : "Forum",  "selectedimage" : "menu_forum_select", "unselectedImage" : "menu_forum_unselect"],["title" : "Profile",  "selectedimage" : "menu_profile_select", "unselectedImage" : "menu_profile_unselect"],["title" : "Notifications",  "selectedimage" : "menu_notifications_select", "unselectedImage" : "menu_notifications_unselect"],["title" : "Settings",  "selectedimage" : "menu_setting_select", "unselectedImage" : "menu_setting_unselect"],["title" : "Log Out", "selectedimage" : "ios_logout-white", "unselectedImage" : "ios_logout"]]
            
        }
        else{
            self.arrDashboardData = [["title" : "Dashboard", "selectedimage" : "menu_dashboard_selected", "unselectedImage" : "menu_dashboard_unselected"],["title" : "Pilates", "selectedimage" : "menu_pilates_select", "unselectedImage" : "menu_pilates_unselect"],["title" : "My Appointments", "selectedimage" : "menu_appinment_select", "unselectedImage" : "menu_appoinment_unselect"],["title" : "My Exercises",  "selectedimage" : "menu_excerise_select", "unselectedImage" : "menu_excerise_unselect"],["title" : "Forum",  "selectedimage" : "menu_forum_select", "unselectedImage" : "menu_forum_unselect"],["title" : "My Pilate Instructor",  "selectedimage" : "menu_pilates_select", "unselectedImage" : "menu_pilates_unselect"]/*,["title" : "My Progress",  "selectedimage" : "menu_progress_select", "unselectedImage" : "menu_progress_unselect"]*/,["title" : "Profile",  "selectedimage" : "menu_profile_select", "unselectedImage" : "menu_profile_unselect"],["title" : "Notifications",  "selectedimage" : "menu_notifications_select", "unselectedImage" : "menu_notifications_unselect"],["title" : "Settings",  "selectedimage" : "menu_setting_select", "unselectedImage" : "menu_setting_unselect"],["title" : "Log Out", "selectedimage" : "ios_logout-white", "unselectedImage" : "ios_logout"]]
        }
        
    }
    
    //MARK: - TableView Delegates and DataSources
    func tableView(_ tableView: UITableView, numberOfRowsInSection section: Int) -> Int {
        if CommonUtility.isPilate() {
            return self.arrDashboardPilateData.count
        }
        else {
            return self.arrDashboardData.count
        }
    }
    
    func tableView(_ tableView: UITableView, cellForRowAt indexPath: IndexPath) -> UITableViewCell {
        return configureMenuTableViewCell(atRow: indexPath.row)
    }
    
    func tableView(_ tableView: UITableView, didSelectRowAt indexPath: IndexPath) {
        
        self.menuTableView.reloadData()
        var centerVC: UIViewController
        
        if CommonUtility.isPilate() {
            let selectedRow : PilateMenuOptionsSelected = PilateMenuOptionsSelected(rawValue: indexPath.row)!
            if indexPath.row != 8 {
            CommonUtility.setMenuSelectedOption(menuOptionIndex: selectedRow.rawValue)
            }
            switch selectedRow {
            case .dashboard:
                let storyboard =  UIStoryboard(name: "Pilates", bundle: nil)
                centerVC = storyboard.instantiateViewController(withIdentifier: "PilatesDashboardViewController")
                
            case .clients:
                let storyboard =  UIStoryboard(name: "Pilates", bundle: nil)
                centerVC = storyboard.instantiateViewController(withIdentifier: "PatientListViewController")
                
            case .schedule :
                let storyboard =  UIStoryboard(name: "Pilates", bundle: nil)
                centerVC = storyboard.instantiateViewController(withIdentifier: "PilateAppointmentsViewController")
                
            case .myExercises:
                let storyboard =  UIStoryboard(name: "Pilates", bundle: nil)
                centerVC = storyboard.instantiateViewController(withIdentifier: "PilateExerciseLibraryViewController")
                
            case .forum:
                let storyboard =  UIStoryboard(name: "Pilates", bundle: nil)
                centerVC = storyboard.instantiateViewController(withIdentifier: "PilateForumViewController")
                
            case .profile:
                let storyboard =  UIStoryboard(name: "Pilates", bundle: nil)
                centerVC = storyboard.instantiateViewController(withIdentifier: "DoctorProfileViewController")
                
            case .notifications:
               // let storyboard =  UIStoryboard(name: "Pilates", bundle: nil)
                let storyboard =  UIStoryboard(name: "Main", bundle: nil)
                centerVC = storyboard.instantiateViewController(withIdentifier: "NotificationsViewController")
            case .settings:
               // let storyboard =  UIStoryboard(name: "Pilates", bundle: nil)
                let storyboard = UIStoryboard(name: "Main", bundle: nil)
                centerVC = storyboard.instantiateViewController(withIdentifier: "SettingsViewController")
                
            case .logout:
                panel?.closeLeft()
                DispatchQueue.main.asyncAfter(deadline: .now()) {
                    self.alertViewController()
                }
                return
            }
            
            let centerNavVC = UINavigationController(rootViewController: centerVC)
            _ = panel?.center(centerNavVC)
        }
        else{
            let selectedRow : MenuOptionsSelected = MenuOptionsSelected(rawValue: indexPath.row)!
            if indexPath.row != 10 {
            CommonUtility.setMenuSelectedOption(menuOptionIndex: selectedRow.rawValue)
            }
            switch selectedRow {
            case .dashboard:
                let storyboard = UIStoryboard(name: "Main", bundle: nil)
                centerVC = storyboard.instantiateViewController(withIdentifier: "DashboardViewController")
            case .pilates:
                centerVC = (self.storyboard?.instantiateViewController(withIdentifier: "PilatesViewController"))!
            case .myAppointments:
                let storyboard = UIStoryboard(name: "Main", bundle: nil)
                centerVC = storyboard.instantiateViewController(withIdentifier: "AppointmentsViewController")
            case .myExercises:
                let storyboard = UIStoryboard(name: "Main", bundle: nil)
                centerVC = storyboard.instantiateViewController(withIdentifier: "ExerciseLibraryViewController")
            case .forum:
                let storyboard = UIStoryboard(name: "Main", bundle: nil)
                centerVC = storyboard.instantiateViewController(withIdentifier: "ForumViewController")
            case .myPilateInstructor:
                centerVC = (self.storyboard?.instantiateViewController(withIdentifier: "PilateDetailViewController"))!
//            case .myProgess:
//                centerVC = (self.storyboard?.instantiateViewController(withIdentifier: "MyProgressViewController"))!
            case .profile:
                let storyboard = UIStoryboard(name: "Main", bundle: nil)
                centerVC = storyboard.instantiateViewController(withIdentifier: "ProfileViewController")
            case .notifications:
                centerVC = (self.storyboard?.instantiateViewController(withIdentifier: "NotificationsViewController"))!
            case .settings:
                centerVC = (self.storyboard?.instantiateViewController(withIdentifier: "SettingsViewController"))!
            case .logout:
                panel?.closeLeft()
                DispatchQueue.main.asyncAfter(deadline: .now()) {
                    self.alertViewController()
                }
                return
            }
            
            let centerNavVC = UINavigationController(rootViewController: centerVC)
            _ = panel?.center(centerNavVC)
        }
    }
    
    func tableView(_ tableView: UITableView, willDisplay cell: UITableViewCell, forRowAt indexPath: IndexPath) {
        cell.backgroundColor = UIColor.clear
    }
    
    private func configureMenuTableViewCell(atRow row : Int) -> UITableViewCell
    {
        if CommonUtility.isPilate() {
            let cell = self.menuTableView.dequeueReusableCell(withIdentifier: "cell")
                as! MenuViewTableViewCell
            cell.title = self.arrDashboardPilateData[row]["title"] as! String
            cell.selectionStyle = .none
            if CommonUtility.getMenuSelectedOption() == row {
                cell.imageArrow = "menu_selected_arrow"
                cell.titleLabelColor = UIColor.white
                cell.imageIcon = self.arrDashboardPilateData[row]["selectedimage"] as! String
            }else
            {
                cell.imageArrow = "menu_unselected_arrow"
                cell.titleLabelColor = color(red: 116, green: 116, blue: 116)
                cell.imageIcon = self.arrDashboardPilateData[row]["unselectedImage"] as! String
            }
            return cell
        }
        else {
            let cell = self.menuTableView.dequeueReusableCell(withIdentifier: "cell")
                as! MenuViewTableViewCell
            cell.title = self.arrDashboardData[row]["title"] as! String
            cell.selectionStyle = .none
            if CommonUtility.getMenuSelectedOption() == row {
                cell.imageArrow = "menu_selected_arrow"
                cell.titleLabelColor = UIColor.white
                cell.imageIcon = self.arrDashboardData[row]["selectedimage"] as! String
            }else
            {
                cell.imageArrow = "menu_unselected_arrow"
                cell.titleLabelColor = color(red: 116, green: 116, blue: 116)
                cell.imageIcon = self.arrDashboardData[row]["unselectedImage"] as! String
            }
            return cell
        }
    }
    
    func tableView(_ tableView: UITableView, heightForRowAt indexPath: IndexPath) -> CGFloat {
        return 60
    }
    
    func leftPanelDidBecomeActive()
    {
        self.menuTableView.reloadData()
    }
    
    func alertViewController() {
        let alert = UIAlertController(title: "Alert", message: "Do you want to Logout?", preferredStyle: UIAlertControllerStyle.alert)
        alert.addAction(UIAlertAction(title: "Yes", style: .default, handler: { action in
            switch action.style{
            case .default:
                let apiManager = APIManager()
                let params = [String : Any]()
                apiManager.logout(parameters: params, completion: { (response) in
                    let centerVC: UIViewController = (self.storyboard?.instantiateViewController(withIdentifier: "NewUserTypeViewController"))!
                    let centerNavVC = UINavigationController(rootViewController: centerVC)
                    self.panel?.configs.centerPanelTransitionType = .curlUp
                    self.panel?.configs.centerPanelTransitionDuration = 1.0
                    _ = self.panel?.center(centerNavVC)
                    _ = self.panel?.left(nil)
                    UserDefaults.standard.set(nil, forKey: UserdefaultsKey.userData.rawValue)
                }, failure: { (error) in
                    
                })
            case .cancel:
                print("cancel")
            case .destructive:
                print("destructive")
            }}))
        alert.addAction(UIAlertAction(title: "No", style: .cancel, handler: { action in
            switch action.style{
            case .default:
                print("default")
                
            case .cancel:
                print("cancel")
                
            case .destructive:
                print("destructive")
            }}))
        self.present(alert, animated: true, completion: nil)
    }
}

