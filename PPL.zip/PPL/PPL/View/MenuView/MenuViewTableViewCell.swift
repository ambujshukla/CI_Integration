
//
//  MenuViewTableViewCell.swift
//  PPL
//
//  Created by cdn68 on 30/04/18.
//  Copyright © 2018 cdn. All rights reserved.
//

import UIKit

class MenuViewTableViewCell: UITableViewCell {
    
    @IBOutlet fileprivate weak var imgIcon : UIImageView!
    @IBOutlet fileprivate weak var lblMenuTitle : UILabel!
    @IBOutlet fileprivate weak var imgArrow : UIImageView!
    
    override func awakeFromNib() {
        super.awakeFromNib()
        self.imgArrow.contentMode = .scaleAspectFit
        self.imgIcon.contentMode = .scaleAspectFit
        DecorateControls.styleLabel(label: self.lblMenuTitle, text: "", font: UIFont.systemFont(ofSize: FONT_SIZE_25), textColor: whiteColor())
    }
    
    var title : String = "" {
        didSet{
            self.lblMenuTitle.text = title
        }
    }
    
    var imageIcon : String = "" {
        didSet{
            self.imgIcon.image = UIImage(named : imageIcon)
        }
    }
    
    var imageArrow : String = "" {
        didSet{
            self.imgArrow.image = UIImage(named : imageArrow)
        }
    }
    
    var titleLabelColor : UIColor = UIColor(){
        didSet{
            self.lblMenuTitle.textColor = titleLabelColor
        }
    }
}
