//
//  AddNewSessionTableViewCell.swift
//  PPL
//
//  Created by TanjeetAjmani on 31/05/18.
//  Copyright © 2018 cdn. All rights reserved.
//

import UIKit

class AddNewSessionTableViewCell: UITableViewCell {
    
    @IBOutlet weak var lblColon: UILabel!
    @IBOutlet weak var tfTitleDetails: UITextField!
    @IBOutlet weak var lblTitle: UILabel!
    override func awakeFromNib() {
        super.awakeFromNib()
        DecorateControls.styleLabel(label: lblTitle, text: "", font: UIFont.systemFont(ofSize: FONT_SIZE_17), textColor: color(red: 117, green: 117, blue: 117))
        DecorateControls.styleLabel(label: lblColon, text: "", font: UIFont.systemFont(ofSize: FONT_SIZE_17), textColor: color(red: 117, green: 117, blue: 117))
        DecorateControls.putText(textField: tfTitleDetails, text: "", placehoder: "", font: UIFont.systemFont(ofSize: FONT_SIZE_17), textColor: color(red: 117, green: 117, blue: 117))
    }
    
    override func setSelected(_ selected: Bool, animated: Bool) {
        super.setSelected(selected, animated: animated)
        
        // Configure the view for the selected state
    }
    
}
