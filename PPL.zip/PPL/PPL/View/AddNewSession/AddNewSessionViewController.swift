//
//  AddNewSessionViewController.swift
//  PPL
//
//  Created by TanjeetAjmani on 31/05/18.
//  Copyright © 2018 cdn. All rights reserved.
//

import UIKit
import EmptyDataSet_Swift

class AddNewSessionViewController: UIViewController,UITableViewDelegate,UITableViewDataSource,UITextFieldDelegate {
    var patientId = ""
    @IBOutlet weak var tvNewSession: UITableView!
    
    var arrAddNewSession = [["Q" : "Main Problem/ Diagnosis/ Other Problem Main Problem/ Diagnosis/ Other Problem Main Problem/ Diagnosis/ Other Problem","A":""],["Q":"Goals/Outome Needed Main Problem/ Diagnosis/ Other Problem","A":""],["Q":"Past History/ Implications","A":""],["Q":"General Health/ Medications/ Investigations","A":""],["Q":"General Questions/ Red Flags/ Constraindications ","A":""],["Q":"Physical Assessment","A":""],["Q":"Pelvic Floor Control","A":""],["Q":"Breathing","A":""],["Q":"Core Control","A":""],["Q":"Strength/ Power/ Balance/ Functional Tests","A":""],["Q":"Impression & Management Plans/ Program needed","A":""]]
    var dict1 : [String : String] = [:]
    override func viewDidLoad() {
        super.viewDidLoad()
        self.tvNewSession.delegate = self
        self.tvNewSession.dataSource = self
        self.tvNewSession.estimatedRowHeight = 55
        self.tvNewSession.rowHeight = UITableViewAutomaticDimension
        self.tvNewSession.separatorStyle = .none
        self.automaticallyAdjustsScrollViewInsets = false
        self.navigationBarStyle()
    }

    func textFieldDidEndEditing(_ textField: UITextField) {
        dict1 = arrAddNewSession[textField.tag]
        dict1["A"] = textField.text
       
        arrAddNewSession[textField.tag] = dict1
    }
    
    func navigationBarStyle (){
        CommonUtility.createCustomBackButton(self, navBarItem: self.navigationItem, strImage: "back_icon _white", select: #selector(openPopView))
        CommonUtility.setNavBarTitle(self.navigationItem, title: NSLocalizedString("Add New Session", comment: "The title of the Profile navigation bar"))
        CommonUtility.createRightBarSaveButtons(target: self, navigationItem: self.navigationItem, select1: #selector(openDashBoardView), select2: #selector(openProfileView), select3: #selector(openSaveView))
    }
    
    func json(from object:Any) -> String? {
        guard let data = try? JSONSerialization.data(withJSONObject: object, options: []) else {
            return nil
        }
        return String(data: data, encoding: String.Encoding.utf8)
    }
    
    @objc func openSaveView(){
    
       
        let check = self.arrAddNewSession.filter{($0["A"] as! String).isEmpty}.count
        if check > 7 {
        CommonUtility.showErrorCRNotifications(title: "Error", message: "Minimum 5 fields are required to filled")
            return
         }
            let apiManager = APIManager()
            var parameters = [String : Any]()
            parameters["json"] = json(from:self.arrAddNewSession as Any)
            
            parameters["patient_id"] = self.patientId
            let dFormat = "dd-MM-yyyy"
            let strToday = CommonUtility.ChangeDateToString(dateObj: Date(), newFormate: dFormat)
            parameters["session_date"] = strToday
            
            apiManager.addSession(methodName:(kMethodSession_Pilate), parameters: parameters, completion: { (responseData) in
                if let jsonObject : [String : Any] = responseData.result.value as? [String : Any]{
                    let statusCode = jsonObject["result_code"] as! Bool
                    if statusCode {
                        CommonUtility.showSuccessCRNotifications(title: appTitle(), message: NSLocalizedString("title.success.sessionCreation", comment: "Session created"))
                        self.navigationController?.popViewController(animated: true)
                    }else {
                        CommonUtility.showErrorCRNotifications(title: appTitle(), message: jsonObject["message"] as! String)
                    }
                }
            }) { (error) in
            }
        
        
    }
    
    @objc func openProfileView(){
      
    let pushVc = self.storyboard?.instantiateViewController(withIdentifier: "DoctorProfileViewController") as! DoctorProfileViewController
    self.navigationController?.pushViewController(pushVc, animated: true)
    
    }
    
    @objc func openDashBoardView()
    {
        CommonUtility.setMenuSelectedOption(menuOptionIndex: 0)
        let centerVC : UIViewController
        let storyboard =  UIStoryboard(name: "Pilates", bundle: nil)
        centerVC = storyboard.instantiateViewController(withIdentifier: "PilatesDashboardViewController")
        let centerNavVC = UINavigationController(rootViewController: centerVC)
        self.panel?.configs.centerPanelTransitionType = .moveLeft
        self.panel?.configs.centerPanelTransitionDuration = 1.0
        _ = panel?.center(centerNavVC)
    }
    
    @objc func openPopView(){
        self.navigationController?.popViewController(animated: true)
    }
    
    func tableView(_ tableView: UITableView, numberOfRowsInSection section: Int) -> Int {
        return self.arrAddNewSession.count
    }
    
    func tableView(_ tableView: UITableView, cellForRowAt indexPath: IndexPath) -> UITableViewCell {
        let cell = tableView.dequeueReusableCell(withIdentifier: "cell") as! AddNewSessionTableViewCell
        let dict = self.arrAddNewSession[indexPath.row]
//        if (dict["A"]?.isEmpty)! {
//            CommonUtility.showErrorCRNotifications(title: "Error", message: "Field required")
//            return cell
//            }
        cell.selectionStyle = .none
        cell.lblColon.text = ":"
        cell.lblTitle.text = dict["Q"]
        cell.tfTitleDetails.text = dict["A"]
        cell.tfTitleDetails.tag = indexPath.row
        cell.tfTitleDetails.delegate = self
        return cell
    }
    func tableView(_ tableView: UITableView, heightForRowAt indexPath: IndexPath) -> CGFloat {
        return UITableViewAutomaticDimension
    }
    
}
extension AddNewSessionViewController: EmptyDataSetSource, EmptyDataSetDelegate {
    func title(forEmptyDataSet scrollView: UIScrollView) -> NSAttributedString? {
        return CommonUtility.dzEmptySetTitle(title: NSLocalizedString("title.error.nodata", comment: "This string shows when there is no data found."))
    }
    
    func buttonTitle(forEmptyDataSet scrollView: UIScrollView, for state: UIControlState) -> NSAttributedString? {
        return CommonUtility.dzEmptySetButtonTitle(title: NSLocalizedString("title.retry", comment: "This gives the option for retry when there is no data."))
    }
    
    func emptyDataSet(_ scrollView: UIScrollView, didTapButton button: UIButton) {
      //  self.getClientsList()
    }
}
