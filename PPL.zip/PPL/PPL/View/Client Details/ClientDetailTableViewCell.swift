//
//  ClientDetailTableViewCell.swift
//  PPL
//
//  Created by TanjeetAjmani on 09/05/18.
//  Copyright © 2018 cdn. All rights reserved.
//

import UIKit

class ClientDetailTableViewCell: UITableViewCell {

    @IBOutlet weak var imgSepratr: UIImageView!
    @IBOutlet weak var lblDetails: UILabel!
    @IBOutlet weak var lblType: UILabel!
    override func awakeFromNib() {
        super.awakeFromNib()
        DecorateControls.styleLabel(label: lblType, text: "", font: UIFont.systemFont(ofSize: FONT_SIZE_18), textColor: blackColor())
        DecorateControls.styleLabel(label: lblDetails, text: "", font: UIFont.systemFont(ofSize: FONT_SIZE_18), textColor: blackColor())
    }

    override func setSelected(_ selected: Bool, animated: Bool) {
        super.setSelected(selected, animated: animated)

        // Configure the view for the selected state
    }

}
