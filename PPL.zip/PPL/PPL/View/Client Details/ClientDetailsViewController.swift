//
//  ClientDetailsViewController.swift
//  PPL
//
//  Created by TanjeetAjmani on 09/05/18.
//  Copyright © 2018 cdn. All rights reserved.
//

import UIKit

class ClientDetailsViewController: UIViewController,UITableViewDelegate,UITableViewDataSource {
    
    @IBOutlet weak var btnSessionHistory: UIButton!
    @IBOutlet weak var btnAddNewSession: UIButton!
    @IBOutlet weak var btnSendProgram: UIButton!
    @IBOutlet weak var lblName: UILabel!
    @IBOutlet weak var viewbackground: UIView!
    @IBOutlet weak var tvClientDetail: UITableView!
    
    @IBOutlet weak var imgClient: UIImageView!
    @IBOutlet weak var viewClientImg: UIView!
    
    var patientDetailModel = PatientList()
    
    var arrClientDetail = [[String: Any]]()
    
    override func viewDidLoad() {
        super.viewDidLoad()
        self.styleUI()
        self.navigationBarStyle()
    }
    
    func styleUI()
    {


        self.arrClientDetail = [["lblType": "Patient :","lblDetail" : "\(self.patientDetailModel.firstname!) \(self.patientDetailModel.lastname!)"],["lblType": "Email :","lblDetail" : self.patientDetailModel.email],["lblType": "Phone Number :","lblDetail" : "5565656565656"],["lblType": "Gender :","lblDetail" : self.patientDetailModel.gender!],["lblType": "Address :","lblDetail" : self.patientDetailModel.address!]]

        
        tvClientDetail.separatorStyle = .none
        DecorateControls.putTitle(button: btnSendProgram, text: "Send Program", font: UIFont.boldSystemFont(ofSize: FONT_SIZE_20), textColor: whiteColor(), backGroundColor: appColor())
        DecorateControls.putTitle(button: btnSessionHistory, text: "Session History", font: UIFont.boldSystemFont(ofSize: FONT_SIZE_20), textColor: whiteColor(), backGroundColor: appColor())
        DecorateControls.putTitle(button: btnAddNewSession, text: "Add New Session", font: UIFont.boldSystemFont(ofSize: FONT_SIZE_20), textColor: whiteColor(), backGroundColor: appColor())
        DecorateControls.styleLabel(label: lblName, text: self.patientDetailModel.username, font: UIFont.boldSystemFont(ofSize: FONT_SIZE_28), textColor: blackColor())
        btnSendProgram.layer.cornerRadius = 5
        btnSessionHistory.layer.cornerRadius = 5
        btnAddNewSession.layer.cornerRadius = 5
        self.imgClient.sd_setImage(with: URL(string: self.patientDetailModel.profile_image!), placeholderImage: #imageLiteral(resourceName: "no-inage"))
        tvClientDetail.isScrollEnabled = false
        viewbackground.dropShadow(color: .lightGray, opacity: 1, offSet: CGSize(width: -1, height: 1), radius: 3, scale: true)
    }
    
    func navigationBarStyle (){
        
        CommonUtility.setNavBarTitle(self.navigationItem, title: NSLocalizedString("Client Details", comment: "The title of the Profile navigation bar"))
        CommonUtility.createRightBarHomeButtons(target: self, navigationItem: self.navigationItem, select1: #selector(openProfileView), select2: #selector(openDashBoardView))
        CommonUtility.createCustomBackButton(self, navBarItem: self.navigationItem, strImage: "back_icon _white", select: #selector(openPopView))
    }
    
    @objc func openProfileView()
    {
       let pushVc = self.storyboard?.instantiateViewController(withIdentifier: "DoctorProfileViewController") as! DoctorProfileViewController
        self.navigationController?.pushViewController(pushVc, animated: true)
        
    }
    
    @objc func openDashBoardView()
    {
        CommonUtility.setMenuSelectedOption(menuOptionIndex: 0)
        let centerVC : UIViewController
        let storyboard =  UIStoryboard(name: "Pilates", bundle: nil)
        centerVC = storyboard.instantiateViewController(withIdentifier: "PilatesDashboardViewController")
        let centerNavVC = UINavigationController(rootViewController: centerVC)
        self.panel?.configs.centerPanelTransitionType = .moveLeft
        self.panel?.configs.centerPanelTransitionDuration = 1.0
        _ = panel?.center(centerNavVC)
      
    }
    @objc func openPopView()
    {
        self.navigationController?.popViewController(animated: true)
    }
    
    func tableView(_ tableView: UITableView, numberOfRowsInSection section: Int) -> Int {
        return arrClientDetail.count
    }
    
    func tableView(_ tableView: UITableView, cellForRowAt indexPath: IndexPath) -> UITableViewCell {
        let cell = tableView.dequeueReusableCell(withIdentifier: "cell") as! ClientDetailTableViewCell
        cell.selectionStyle = .none
        cell.lblType.text = arrClientDetail[indexPath.row]["lblType"] as! String
        cell.lblDetails.text = arrClientDetail[indexPath.row]["lblDetail"] as! String
        cell.imgSepratr.isHidden = true
       return cell
    }
    func tableView(_ tableView: UITableView, heightForRowAt indexPath: IndexPath) -> CGFloat {
        return 40
    }
    override func viewWillLayoutSubviews() {
        super.viewWillLayoutSubviews()
      
        viewClientImg.layer.borderWidth = 1
        viewClientImg.layer.borderColor = UIColor.gray.cgColor
        viewClientImg.layer.cornerRadius = viewClientImg.frame.height/2
        viewClientImg.clipsToBounds = true
        imgClient.layer.borderWidth = 1
        imgClient.layer.cornerRadius = imgClient.frame.height/2
        imgClient.clipsToBounds = true
    }
    
    @IBAction func btnSessionHistoryActn(_ sender: UIButton) {
        let controller = self.storyboard?.instantiateViewController(withIdentifier: "SessionsViewController") as! SessionsViewController
        controller.patientDetailModel = self.patientDetailModel
        self.navigationController?.pushViewController(controller, animated: true)
    }
    
    @IBAction func btnSendProgranActn(_ sender: UIButton) {
        let controller = self.storyboard?.instantiateViewController(withIdentifier: "PilateExerciseLibraryViewController") as! PilateExerciseLibraryViewController
        controller.strFrom = "SendProgram"
        controller.strPatientId = self.patientDetailModel.user_id!
        controller.strPatientName = "\(self.patientDetailModel.firstname!) \(self.patientDetailModel.lastname!)"
        self.navigationController?.pushViewController(controller, animated: true)
    }
    @IBAction func btnAddNewSessionActn(_ sender: UIButton) {
        let controller = self.storyboard?.instantiateViewController(withIdentifier: "AddNewSessionViewController") as! AddNewSessionViewController
        controller.patientId = self.patientDetailModel.user_id!
        self.navigationController?.pushViewController(controller, animated: true)
    }
}

