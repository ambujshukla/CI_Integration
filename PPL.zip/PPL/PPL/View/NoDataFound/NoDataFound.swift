//
//  NoDataFound.swift
//  PPL
//
//  Created by cdn68 on 15/06/18.
//  Copyright © 2018 cdn. All rights reserved.
//

import UIKit

class NoDataFound: UIView {
    @IBOutlet private var lblMessage: UILabel!
    
    var strMessage: String = "" {
        didSet {
            self.lblMessage.text = strMessage
        }
    }
}
