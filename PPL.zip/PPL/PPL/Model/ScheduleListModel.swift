//
//  ScheduleListModel.swift
//  PPL
//
//  Created by cdn68 on 11/06/18.
//  Copyright © 2018 cdn. All rights reserved.
//

import Foundation

struct ScheduleListModel: Codable {
    
    var result: [ScheduleList]
    
    enum CodingKeys: String, CodingKey {
        case result = "result"
    }
}

struct ScheduleList: Codable {
    var date: String?
    var time_details: [TimeDetails_Schedule]?
    
    enum CodingKeys: String, CodingKey {
        case date = "date"
        case time_details = "time_details"
    }
}

struct TimeDetails_Schedule: Codable {
    var id: String?
    var title: String?
    var doctor_id: String?
    var date: String?
    var start_time: String?
    var end_time: String?
    var no_of_patients: String?
    var userList: [UserList]?
    
    enum CodingKeys: String, CodingKey {
        case userList = "userlist"
        case id = "id"
        case title = "title"
        case doctor_id = "doctor_id"
        case date = "date"
        case start_time = "start_time"
        case end_time = "end_time"
        case no_of_patients = "no_of_patients"
    }
}

struct UserList: Codable {
    var address: String?
    var firstname: String?
    var lastname: String?
    var patient_id: String?
    var schedules_id: String?
    var username: String?
    var profile_image: String?
}
