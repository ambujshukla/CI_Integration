//
//  PilateListModel.swift
//  PPL
//
//  Created by cdn68 on 06/06/18.
//  Copyright © 2018 cdn. All rights reserved.
//

import Foundation

struct PilateListModel: Codable {
    let result: [PilateList]
    
    enum CodingKeys: String, CodingKey {
        case result = "result"
    }
}

struct PilateList: Codable {
    let user_id: String?
    let user_type: String?
    let username: String
    let expertise: String?
    let experience: String?
    let qualification: String?
    let profile_image: String
    let request_send: Int?
    let my_client: Int?
    let firstname : String?
    let lastname : String?
}
