//
//  SessionsListModel.swift
//  PPL
//
//  Created by cdn68 on 11/06/18.
//  Copyright © 2018 cdn. All rights reserved.
//

import Foundation

struct SessionsListModel: Codable {
     var result: [SessionList]
    
    enum CodingKeys: String, CodingKey {
        case result = "result"
    }
}

struct SessionList:Codable {
    var created_at: String?
    var dob: String?
    var email: String?
    var profile_image: String?
    var session_date: String?
    var session_id: String?
    var user_id: String?
    var user_type: String?
    var username: String?
    var json:[QuestionAnswers]
}

struct QuestionAnswers: Codable {
    var A: String
    var Q: String
}
