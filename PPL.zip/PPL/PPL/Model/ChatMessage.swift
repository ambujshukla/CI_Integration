
//
//  ChatMessage.swift
//  amsel
//
//  Created by cdn68 on 26/03/18.
//  Copyright © 2018 Vitaliy Tolkach. All rights reserved.
//

import UIKit
import RealmSwift
import Realm

class ChatMessage: Object
{
    @objc dynamic var created_at = ""
    @objc dynamic var local_id   = ""
    @objc dynamic var message    = ""
    @objc dynamic var name    = ""
    @objc dynamic var sent_by    = ""
    @objc dynamic var sent_to_group_id  = ""
    @objc dynamic var timestamp  = 0
    @objc dynamic var user_type  = ""
}

