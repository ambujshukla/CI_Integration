//
//  PatientListModel.swift
//  PPL
//
//  Created by cdn68 on 07/06/18.
//  Copyright © 2018 cdn. All rights reserved.
//

import Foundation

struct MyClassModel: Codable {
    let result: [MyClassList]
    
    enum CodingKeys: String, CodingKey {
        case result = "result"
    }
}

struct MyClassList: Codable {
    let id: String?
    let doctor_id: String?
    let title: String?
    let date: String?
    let start_time: String?
    let end_time: String?
    let no_of_patients: String?
    let patient_id: String?
    let firstname: String?
    let lastname: String?
    let address: String?
    let profile_image: String?
    var video: [Videos]
    var images: [Images]
}

struct Videos: Codable {
    let id: String?
    let doctor_id: String?
    let title: String?
    let video_file : String?
}

struct Images: Codable {
    let id: String?
    let doctor_id: String?
    let title: String?
    let image_file : String?
}
