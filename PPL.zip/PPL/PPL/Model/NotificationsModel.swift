//
//  NotificationsModel.swift
//  PPL
//
//  Created by cdn68 on 27/06/18.
//  Copyright © 2018 cdn. All rights reserved.
//

import Foundation

struct NotificationsModel: Codable {
    let result: [NotificationsList]
    
    enum CodingKeys: String, CodingKey {
        case result = "result"
    }
}

struct NotificationsList: Codable {
    let id: String?
    let user_id: String?
    let user_type: String
    let title: String?
    let msg: String?
    let push_type: String?
    let push_data: String?
    let is_read: String?
    let is_archive: String?
    let created_at: String?
}
