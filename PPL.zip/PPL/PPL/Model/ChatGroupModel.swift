//
//  ChatGroupModel.swift
//  PPL
//
//  Created by cdn68 on 22/06/18.
//  Copyright © 2018 cdn. All rights reserved.
//

import Foundation

struct ChatGroupModel: Codable {
    let result: [GroupList]
    
    enum CodingKeys: String, CodingKey {
        case result = "result"
    }
}

struct GroupList: Codable {
    let id: String?
    let name: String?
    let group_type: String?
}


/*"id": "2",
 "name": "cdn1"
 },
*/
