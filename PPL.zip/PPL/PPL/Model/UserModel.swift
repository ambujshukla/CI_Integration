//
//  UserModel.swift
//  PPL
//
//  Created by cdn68 on 01/06/18.
//  Copyright © 2018 cdn. All rights reserved.
//

import Foundation

struct UserModel: Codable {
    var result: UserData
    
    enum CodingKeys: String, CodingKey {
        case result = "result"
    }
}

struct UserData: Codable {
    let access_token: String?
    let dob: String?
    let email: String
    let goals: String?
    let height: String?
    let medical_history: String?
    let mobile: String?
    let profile_image: String?
    let profile_status: String?
    let reference_code: String?
    let user_id: String
    let user_type: String
    let username: String
    let weight: String?
    let achievement: String?
    let experience: String?
    let expertise: String?
    let qualification: String?
    let firstname: String?
    let lastname: String?
    let address: String?
    var push_notification: String?
}
