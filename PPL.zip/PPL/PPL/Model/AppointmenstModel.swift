//
//  AppointmenstModel.swift
//  PPL
//
//  Created by cdn68 on 14/06/18.
//  Copyright © 2018 cdn. All rights reserved.
//

import Foundation


struct AppointmenstModel: Codable {
    var result: ResultAppointments
    
    enum CodingKeys: String, CodingKey {
        case result = "result"
    }
}

struct ResultAppointments: Codable {
    var doctorList: [Doctor]
    var schedules: [Schedules]
    var appointments: [Schedules]
    
    enum CodingKeys: String, CodingKey {
        case doctorList = "doctor"
        case schedules = "schedules"
        case appointments = "appointments"
    }
}

struct Doctor: Codable {
    var id: String?
    var user_type: String?
    var username: String?
    var profile_status: String?
    var push_notification: String?
    var email: String?
    var firstname: String?
    var lastname: String?
    var address: String?
}

struct Schedules: Codable {
    var date: String?
    var time_details: [TimeDetails]
    
    enum CodingKeys: String, CodingKey {
        case time_details = "time_details"
        case date = "date"
    }
}

struct TimeDetails: Codable {
    var id: String?
    var title: String?
    var doctor_id: String?
    var date: String?
    var start_time: String?
    var end_time: String?
    var no_of_patients: String?
}
