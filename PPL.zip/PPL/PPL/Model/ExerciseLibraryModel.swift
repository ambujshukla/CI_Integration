//
//  ExerciseLibraryModel.swift
//  PPL
//
//  Created by cdn68 on 15/06/18.
//  Copyright © 2018 cdn. All rights reserved.
//

import Foundation

struct ExerciseLibraryModel: Codable {
    var result: [ExerciseImages]
    enum CodingKeys: String, CodingKey {
        case result = "result"
    }
}

struct ExerciseImages: Codable {
    let id: String?
    let doctor_id: String?
    let title: String?
    let image_file: String?
}


struct ExerciseVideoModel: Codable {
    var result: [ExerciseVideo]
    enum CodingKeys: String, CodingKey {
        case result = "result"
    }
}

struct ExerciseVideo: Codable {
    let id: String?
    let doctor_id: String?
    let title: String?
    let video_file: String?
}
