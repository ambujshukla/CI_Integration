//
//  PatientExerciseModel.swift
//  PPL
//
//  Created by cdn68 on 28/06/18.
//  Copyright © 2018 cdn. All rights reserved.
//

import Foundation

struct PatientExerciseModel: Codable {
    var result: ExerciseData
    enum CodingKeys: String, CodingKey {
        case result = "result"
    }
}

struct ExerciseData: Codable {
    var image: [ExerciseImages]
    var video: [ExerciseVideo]
    
    enum CodingKeys: String, CodingKey {
        case image = "image"
        case video = "video"
    }
}

