//
//  ChatHistoryModel.swift
//  PPL
//
//  Created by cdn68 on 23/06/18.
//  Copyright © 2018 cdn. All rights reserved.
//

import Foundation

struct ChatHistoryModel: Codable {
    let result: [ChatHistory]
    
    enum CodingKeys: String, CodingKey {
        case result = "result"
    }
}

struct ChatHistory: Codable {
    let message_id: String?
    let message: String?
    let name: String?
    let profile_image: String?
    let user_type: String?
    let created_at: String?
}
