//
//  PatientListModel.swift
//  PPL
//
//  Created by cdn68 on 07/06/18.
//  Copyright © 2018 cdn. All rights reserved.
//

import Foundation

struct PatientListModel: Codable {
    var result: Result
    
    enum CodingKeys: String, CodingKey {
        case result = "result"
    }
}

struct Result: Codable {
    var my_client: [PatientList]
    var pendding_request: [PatientList]
    
    enum CodingKeys: String, CodingKey {
        case pendding_request = "pendding_request"
        case my_client = "my_client"
    }
}

struct PatientList: Codable {
    var user_id: String?
    var user_type: String?
    var email: String = ""
    var username: String?
    var dob: String?
    var weight: String?
    var height: String?
    var goals: String?
    var gender : String?
    var medical_history: String?
    var profile_image: String?
    var date: String?
    var firstname : String?
    var lastname : String?
    var address : String?
    
}

