//
//  AppDelegate.swift
//  PPL
//
//  Created by cdn68 on 25/04/18.
//  Copyright © 2018 cdn. All rights reserved.
//

import UIKit
import Fabric
import Crashlytics
import FAPanels
import SocketIO

@UIApplicationMain
class AppDelegate: UIResponder, UIApplicationDelegate {
    
    var window: UIWindow?
    var selectedMenuOption: Int?
    var pilateSelectedMenuOption : Int = 0
    
    func application(_ application: UIApplication, didFinishLaunchingWithOptions launchOptions: [UIApplicationLaunchOptionsKey: Any]?) -> Bool {
        Fabric.with([Crashlytics.self])
        // Override point for customization after application launch.
        UINavigationBar.appearance().barTintColor = appColor()
        UINavigationBar.appearance().tintColor = UIColor.white
        UINavigationBar.appearance().tintColor = UIColor.white
        UINavigationBar.appearance().titleTextAttributes = [NSAttributedStringKey.foregroundColor : UIColor.white , NSAttributedStringKey.font: UIFont.systemFont(ofSize: 25)]
        
        let userModel = CommonUtility.userProfile()
        if userModel != nil && (userModel?.result.profile_status == "1")
        {
            self.navigateToDashboard()
        }
        
        NotificationCenter.default.addObserver(self, selector: #selector(showUserTypeOnInvalidAccessToken), name: NSNotification.Name(rawValue: kPresentUserTypeScreen), object: nil)
        
        let manager = SocketIOManager()
        manager.addHandlers()
        manager.establishConnection()
        
        return true
    }
    
    func navigateToDashboard()
    {
        let mainStoryboard: UIStoryboard = UIStoryboard(name: "Main", bundle: nil)
        let leftMenuVC: MenuViewController = mainStoryboard.instantiateViewController(withIdentifier: "MenuViewController") as! MenuViewController
        let centerVC : UIViewController
        if CommonUtility.isPilate() {
            let storyboard =  UIStoryboard(name: "Pilates", bundle: nil)
            centerVC = storyboard.instantiateViewController(withIdentifier: "PilatesDashboardViewController")
        }else{
            centerVC = mainStoryboard.instantiateViewController(withIdentifier: "DashboardViewController")
        }
        let centerNavVC = UINavigationController(rootViewController: centerVC)
        //  Set the Panel controllers with just two lines of code
        let panelVC = FAPanelController()
        panelVC.configs.leftPanelWidth = kLeftPanelWidth
        panelVC.leftPanelPosition = .front
        
        _ = panelVC.center(centerNavVC).left(leftMenuVC)
        
        UIView.transition(from: self.window!, to: centerVC.view, duration: 0.0, options: UIViewAnimationOptions.transitionCrossDissolve) { (finished) in
            _ = panelVC.center(centerNavVC).left(leftMenuVC); UIApplication.shared.keyWindow?.rootViewController = panelVC
        }
    }
    
    func applicationWillResignActive(_ application: UIApplication) {
        // Sent when the application is about to move from active to inactive state. This can occur for certain types of temporary interruptions (such as an incoming phone call or SMS message) or when the user quits the application and it begins the transition to the background state.
        // Use this method to pause ongoing tasks, disable timers, and invalidate graphics rendering callbacks. Games should use this method to pause the game.
    }
    
    func applicationDidEnterBackground(_ application: UIApplication) {
        // Use this method to release shared resources, save user data, invalidate timers, and store enough application state information to restore your application to its current state in case it is terminated later.
        // If your application supports background execution, this method is called instead of applicationWillTerminate: when the user quits.
    }
    
    func applicationWillEnterForeground(_ application: UIApplication) {
        // Called as part of the transition from the background to the active state; here you can undo many of the changes made on entering the background.
    }
    
    func applicationDidBecomeActive(_ application: UIApplication) {
        // Restart any tasks that were paused (or not yet started) while the application was inactive. If the application was previously in the background, optionally refresh the user interface.
    }
    
    func applicationWillTerminate(_ application: UIApplication) {
        // Called when the application is about to terminate. Save data if appropriate. See also applicationDidEnterBackground:.
    }
    
    @objc func showUserTypeOnInvalidAccessToken(notification: Notification) {
        let mainStoryBoard = UIStoryboard(name: "Main", bundle: nil)
        let vc = mainStoryBoard.instantiateViewController(withIdentifier: "NewUserTypeViewController") as! NewUserTypeViewController
        let nav = UINavigationController.init(rootViewController: vc)
        let appDelegate = UIApplication.shared.delegate as! AppDelegate
        appDelegate.window?.rootViewController = nav
        CommonUtility.showErrorCRNotifications(title:appTitle() , message: NSLocalizedString("title.login.session.expire", comment: "This error shown when the access token gets invalidated"))
        UserDefaults.standard.set(nil, forKey: UserdefaultsKey.userData.rawValue)
    }
}

extension Notification.Name {
    static let notificationForUserTypeView = Notification.Name(kPresentUserTypeScreen)
}

