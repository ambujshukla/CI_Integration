//
//  socketConnection.swift
//  chatSwiftmodule
//
//  Created by bhaveshjain on 27/02/18.
//  Copyright © 2018 bhaveshjain. All rights reserved.
//

import UIKit
import SocketIO

class SocketIOManager {
    
//    static let manager = SocketManager(socketURL: URL(string: "https://amsel-development.amerdis-services.de")!, config: [.log(false), .compress, .forcePolling(true)])
    
    //"http://cdnsolutionsgroup.com:9003"
    static let manager = SocketManager(socketURL: URL(string: "http://cdnsolutionsgroup.com:9003")!, config: [.log(true), .compress, .forcePolling(true)])

    func addHandlers(){
        
        SocketIOManager.manager.defaultSocket.on(clientEvent: .connect) {data, ack in
            print("\nSocket connected\n")
        }
        
        SocketIOManager.manager.defaultSocket.on(clientEvent: .disconnect) {data, ack in
            print("\nSocket disconnected\n")
        }
        
        SocketIOManager.manager.defaultSocket.on(clientEvent: .error) {data, ack in
            print("\nSocket error\n")
        }
        
        SocketIOManager.manager.defaultSocket.on(clientEvent: .statusChange) {data, ack in
            print("\nStatus change: \(data)\n")
            //            var dict = [AnyHashable: Any]()
            //            dict["userId"] = "1"
            //            dict["username "] = "ambuj"
            ////            SocketIOManager.manager.emitAll("createNodeRoom", withItems: [dict])
            //            SocketIOManager.manager.emitAll("add user", withItems: [dict])
            //            socket.emit('add user', userId , username);
            
        }
        
        SocketIOManager.manager.defaultSocket.onAny { (SocketAnyEvent) in
            let dict = [
                "name" : SocketAnyEvent.event,
                "args" : SocketAnyEvent.items!
                ] as [String : Any]
            print("response of node \(dict)")
            
            if let arrTemp : Array<Any> = dict["args"] as? Array<Any>
            {
                if arrTemp.count > 0
                {
                    if let status : SocketIOStatus = arrTemp[0] as? SocketIOStatus
                    {
                        if status == SocketIOStatus.connected
                        {
                        
                        }
                    }else if dict["name"] as! String == "user groups"
                    {
                        NotificationCenter.default.post(name: Notification.Name("receiveUserGroups"), object: nil, userInfo: dict)
                    }
                    else if dict["name"] as! String == "groupusers"
                    {
                        NotificationCenter.default.post(name: Notification.Name("receiveUsersInRoom"), object: nil, userInfo: dict)
                    }else if dict["name"] as! String == "messageResponse" || dict["name"] as! String == "receiveMessage"
                    {
                        NotificationCenter.default.post(name: Notification.Name("receiveLastMessagesInRoom"), object: nil, userInfo: dict)
                    }
                    else{
                        if let dictTemp : [String : Any] = arrTemp[0] as? [String: Any]
                        {
                            if let roomInfo = dictTemp["room"]
                            {
                                if let roomId : [String : String] = roomInfo as? [String : String]
                                {
                                    print("room created successfully - \(roomId["roomId"]!)")
                                }
                            }
                        }
                    }
                    
                }
            }
            
        //    if (dict["name"]!) as! String == "receiveMessage"
//            {
//                if dict["args"] != nil
//                {
//                    NotificationCenter.default.post(name: Notification.Name("receiveChatMessage"), object: nil, userInfo: dict)
//                }
//            }
        }
    }
    
    func establishConnection() {
        SocketIOManager.manager.defaultSocket.connect()
    }
    
    func closeConnection() {
        SocketIOManager.manager.defaultSocket.disconnect()
    }

    class func doSendMessage(dictMessage : Any)
    {
        SocketIOManager.manager.emitAll("sendMessage", withItems: [dictMessage])
//        SocketIOManager.manager.emitAll("message", withItems: [dictMessage])
    }

    class func doConnectToRoom(dictMessage : Any)
    {
         SocketIOManager.manager.emitAll("createNodeRoom", withItems: [dictMessage])
       // SocketIOManager.manager.emitAll("add user", withItems: [dictMessage])
    }

    class func doGetMsgList(dictData : Any)
    {
        SocketIOManager.manager.emitAll("create", withItems : [dictData])
    }
//
//    class func doGetMsgList(dictData : Any)
//    {
//        SocketIOManager.manager.emitAll("create", withItems : [dictData])
//    }
    //    func postmessage(_ dict: [AnyHashable: Any]) {
    //
    //        let localNotification = UILocalNotification()
    //        localNotification.fireDate = Date()
    //        var dictInfo = [AnyHashable: Any]()
    //        localNotification.soundName = "sound.m4r"
    //        localNotification.userInfo = dict
    //        localNotification.alertBody = "\(dict["message"]), \(dict["created_at"])"
    //        localNotification.timeZone = NSTimeZone.default
    //        UIApplication.shared.scheduleLocalNotification(localNotification)
    //    }
    
}
