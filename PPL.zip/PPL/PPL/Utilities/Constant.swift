//
//  Constant.swift
//  PPL
//
//  Created by cdn68 on 25/04/18.
//  Copyright © 2018 cdn. All rights reserved.
//

import Foundation
import UIKit

// Server constant
let kBaseUrl  = "https://www.cdnsolutionsgroup.com/ppl/ws/"
let kMethodLogin_Patient = "patient/login"
let kMethodRegistration_Patient = "patient/registration"
let kMethodForgotPassword_Patient = "patient/forgot_password"
let kMethodProfile_Patient = "patient/profile_update"
let kMethodDoctor_List = "patient/doctor_list"
let kMethodPatient_ChangePassword = "patient/change_password"
let kMethodPatient_SendRequest = "patient/send_request"
let kMethodGet_Patient_Schedules = "patient/get_schedules_appointments"
let kMethod_Push_Notifications = "patient/pushnotification_enable"
let kMethodPatient_AddAppointments = "patient/add_appointments"
let kMethodAdd_Review = "patient/add_review"
let kMethod_Logout = "patient/logout"

let kMethodPatient_MyClients = "doctor/my_client_request"
let kMethodRegistration_Doctor = "doctor/registration"
let kMethodLogin_Doctor = "doctor/login"
let kMethodForgotPassword_Doctor = "doctor/forgot_password"
let kMethodPatient_RequestStatus = "doctor/request_change_status"
let kMethodProfileUpdate_Pilate = "doctor/profile_update"
let kMethodSession_Pilate = "doctor/create_session"
let kMethodGetSession_Pilate = "doctor/get_session"
let kMethodCreate_Schedule = "doctor/create_schedules"
let kMethodGet_Schedule = "doctor/get_schedules"
let kMethodGet_Sessions = "doctor/get_session"
let kMethodVideo_Upload = "doctor/add_video"
let kMethodGet_Video = "doctor/get_video"
let kMethodImages_Upload = "doctor/add_images"
let kMethodGet_Images = "doctor/get_images"
let kMethodAssignVideoImage = "doctor/assign"
let kMethodGet_Group = "patient/get_group"
let kMethodGet_ChatHistory = "patient/get_chat_history"
let kMethodMyClass = "doctor/myclass"
let kMethodNotifications = "patient/notification"
let kMethodGet_PatientLibrary = "patient/get_library"

//Notification
let kPresentUserTypeScreen = "ShowUserTypeScreen"

let UNIVERSAL_WIDTH = UIScreen.main.bounds.size.width
let UNIVERSAL_HEIGHT = UIScreen.main.bounds.size.height

let WIDTH_FACTOR: CGFloat = UNIVERSAL_WIDTH/1024.0
let HEIGHT_FACTOR : CGFloat = UNIVERSAL_HEIGHT/768.0

let kLeftPanelWidth: CGFloat = 380

enum UserdefaultsKey: String {
    case userData
    case accessToken
    case isUserPilate
    case isPushEnabled
}

//*********************************************** FONT NAME ****************************** //

let Font_Helvetica_Bold       = "Helvetica-Bold"
let Font_Helvetica            = "Helvetica"
let Font_Helvetica_Neue       = "Helvetica Neue"
let FONT_ROBOTO_REGULAR       = "Roboto-Regular"
let FONT_ROBOTO_SEMIBOLD      = "Roboto-Bold"
let FONT_ROBOTO_LIGHT         = "Roboto-Light"
let FONT_ROBOTO_ITALIC        = "Roboto-Italic"
let FONT_ROBOTO_BLACK_ITALIC  = "Roboto-BlackItalic"
let FONT_ROBOTO_BOLD_ITALIC   = "Roboto-BoldItalic"

let FONT_SIZE_8  : CGFloat      = 8
let FONT_SIZE_9  : CGFloat      = 9
let FONT_SIZE_10 : CGFloat      = 10
let FONT_SIZE_11 : CGFloat      = 11
let FONT_SIZE_12 : CGFloat      = 12
let FONT_SIZE_13 : CGFloat      = 13
let FONT_SIZE_14 : CGFloat      = 14
let FONT_SIZE_15 : CGFloat      = 15
let FONT_SIZE_16 : CGFloat      = 16
let FONT_SIZE_17 : CGFloat      = 17
let FONT_SIZE_18 : CGFloat      = 18
let FONT_SIZE_19 : CGFloat      = 19
let FONT_SIZE_20 : CGFloat      = 20
let FONT_SIZE_21 : CGFloat      = 21
let FONT_SIZE_22 : CGFloat      = 22
let FONT_SIZE_23 : CGFloat      = 23
let FONT_SIZE_24 : CGFloat      = 24
let FONT_SIZE_25 : CGFloat      = 25
let FONT_SIZE_26 : CGFloat      = 26
let FONT_SIZE_27 : CGFloat      = 27
let FONT_SIZE_28 : CGFloat      = 28
let FONT_SIZE_29 : CGFloat      = 29
let FONT_SIZE_30 : CGFloat      = 30
let FONT_SIZE_31 : CGFloat      = 31
let FONT_SIZE_32 : CGFloat      = 32
let FONT_SIZE_33 : CGFloat      = 33
let FONT_SIZE_34 : CGFloat      = 34
let FONT_SIZE_35 : CGFloat      = 35


func color(red : Float , green : Float , blue : Float) -> UIColor{
    return UIColor(red:CGFloat(red/255.0) , green: CGFloat(green/255.0), blue: CGFloat(blue/255.0), alpha: 1.0)
}
func colorWithAlpha(red : Float , green : Float , blue : Float, alpha : CGFloat) -> UIColor{
    return UIColor(red:CGFloat(red/255.0) , green: CGFloat(green/255.0), blue: CGFloat(blue/255.0), alpha: alpha)
}

func appColor() -> UIColor{
     return color(red: 232, green: 191, blue: 63)
}

func whiteColor() -> UIColor{
    return UIColor.white
}

func blackColor() -> UIColor{
    return UIColor.black
}

func appTitle() -> String{
    return "Patient Pilates"
}

func lightColor(red: Float , green : Float , blue : Float) -> UIColor{
    return UIColor(red:CGFloat(red/255.0) , green: CGFloat(green/255.0), blue: CGFloat(blue/255.0), alpha: 0.5)
}

func lightGray() -> UIColor {
    return lightColor(red: 45, green: 46, blue: 44)
}

func clearColor() -> UIColor{
    return UIColor.clear
}


