//
//  DecorateControls.swift
//  PPL
//
//  Created by cdn68 on 15/05/18.
//  Copyright © 2018 cdn. All rights reserved.
//

import UIKit

class DecorateControls {
    
    class func styleLabel(label: UILabel?, text: String?, font: UIFont, textColor: UIColor?) {
        label?.text = text
        label?.textColor = textColor
        label?.font = font
    }
    
    class func putTitle(button: UIButton?, text: String?, font: UIFont, textColor: UIColor, backGroundColor: UIColor) {
        button?.setTitle(text, for: .normal)
        button?.titleLabel?.font = font
        button?.setTitleColor(textColor, for: .normal)
        button?.backgroundColor = backGroundColor
    }
    
    class func putText(textField: UITextField?, text: String?, placehoder: String?, font: UIFont, textColor: UIColor?) {
        textField?.text = text
        textField?.placeholder = (placehoder?.count ?? 0) > 0 ? placehoder : ""
        textField?.textColor = textColor
        textField?.font = font
    }
    
    class func putText(textView: UITextView?, text: String?, font: UIFont, textColor: UIColor?) {
        textView?.text = text ?? ""
        textView?.textColor = textColor
        textView?.font = font
    }
}
