//
//  CommonUtility.swift
//  Nero
//
//  Created by gopalsara on 06/03/18.
//  Copyright © 2018 gopalsara. All rights reserved.
//

import UIKit
import Toast_Swift
import CRNotifications
import NVActivityIndicatorView

private let kActivityIndicatorWidth: CGFloat = 100.0
private let kActivityIndicatorHeight: CGFloat = 100.0

class CommonUtility: NSObject, NVActivityIndicatorViewable {
    
    //MARK:Navigation Bar Decoration
    class func decorateNavBar(_ target:AnyObject,leftImage:String,rightImage:String,title:String,leftSelector:Selector?,rightSelector:Selector?){
        if !(leftImage.isEmpty){
            self.createCustomBackButton(target, navBarItem: target.navigationItem, strImage: leftImage as NSString, select: leftSelector!)
        }
        if !(rightImage.isEmpty){
            self.createCustomRightButton(target, navBarItem: target.navigationItem, strImage: rightImage as NSString, select: rightSelector!)
        }
        if !(title.isEmpty){
            self.setNavBarTitle(target.navigationItem, title: title as String)
        }
        target.navigationController?!.navigationBar.titleTextAttributes = [NSAttributedStringKey.foregroundColor: UIColor.white]
        target.navigationController??.interactivePopGestureRecognizer?.isEnabled = false
    }
    
    class func decorateNavBarWithLeftTitle(_ target:AnyObject,leftTitle:String,rightTitle:String,title:String,leftSelector:Selector?,rightSelector:Selector?){
        
        
        if !(leftTitle.isEmpty){
            self.createCustomBackButtonWithTitle(target, navBarItem: target.navigationItem, strTitle: leftTitle as NSString, select: leftSelector!)
        }
        if !(rightTitle.isEmpty){
            self.createCustomRightButtonWithTitle(target, navBarItem: target.navigationItem, strTitle: rightTitle as NSString, select: rightSelector!)
        }
        if !(title.isEmpty){
            self.setNavBarTitle(target.navigationItem, title: title as String)
        }
        target.navigationController?!.navigationBar.titleTextAttributes = [NSAttributedStringKey.foregroundColor: UIColor.white]
        target.navigationController??.interactivePopGestureRecognizer?.isEnabled = false
    }
    
    class func setNavBarTitle(_ navBarItem:UINavigationItem,title: String){
        navBarItem.title =  title
        // CommonUtil.getLocalizeString(title as String) as String
    }
    
    class func createCustomRightButtonWithTitle(_ target:AnyObject,navBarItem:UINavigationItem,strTitle:NSString,select:Selector){
        let buttonEdit: UIButton = UIButton(type: .custom)
        buttonEdit.contentHorizontalAlignment = .right
        buttonEdit.frame = CGRect(x: 0, y: 0, width: 60, height: 40)
        buttonEdit.setTitle(strTitle as String, for: .normal)
        buttonEdit.setTitleColor(UIColor.white, for: .normal)
        //  buttonEdit.setImage(UIImage(named:strImage as String), for: UIControlState())
        buttonEdit.addTarget(target, action: select, for: UIControlEvents.touchUpInside)
        let rightBarButtonItemEdit: UIBarButtonItem = UIBarButtonItem(customView: buttonEdit)
        navBarItem.setRightBarButton(rightBarButtonItemEdit, animated: false)
    }
    
    
    class func createCustomBackButtonWithTitle(_ target:AnyObject,navBarItem:UINavigationItem,strTitle:NSString,select:Selector){
        let buttonEdit: UIButton = UIButton(type: .custom)
        buttonEdit.frame = CGRect(x: 0, y: 0, width: 60, height: 40)
        buttonEdit.setTitle(strTitle as String, for: .normal)
        buttonEdit.setTitleColor(UIColor.white, for: .normal)
        //buttonEdit.setImage(UIImage(named:strImage as String), for: UIControlState())
        buttonEdit.addTarget(target, action: select, for: UIControlEvents.touchUpInside)
        let rightBarButtonItemEdit: UIBarButtonItem = UIBarButtonItem(customView: buttonEdit)
        navBarItem.setLeftBarButton(rightBarButtonItemEdit, animated: false)
    }
    
    class func createCustomBackButton(_ target:AnyObject,navBarItem:UINavigationItem,strImage:NSString,select:Selector){
        let buttonEdit: UIButton = UIButton(type: .custom)
        buttonEdit.contentHorizontalAlignment = .left
        buttonEdit.frame = CGRect(x: 0, y: 0, width: 40, height: 40)
        buttonEdit.setImage(UIImage(named:strImage as String), for: UIControlState())
        buttonEdit.addTarget(target, action: select, for: UIControlEvents.touchUpInside)
        let rightBarButtonItemEdit: UIBarButtonItem = UIBarButtonItem(customView: buttonEdit)
        navBarItem.setLeftBarButton(rightBarButtonItemEdit, animated: false)
    }
    
    
    
    class func createCustomRightButton(_ target:AnyObject,navBarItem:UINavigationItem,strImage:NSString,select:Selector){
        let buttonEdit: UIButton = UIButton(type: .custom)
        buttonEdit.contentHorizontalAlignment = .right
        buttonEdit.frame = CGRect(x: 0, y: 0, width: 40, height: 40)
        buttonEdit.setImage(UIImage(named:strImage as String), for: UIControlState())
        buttonEdit.addTarget(target, action: select, for: UIControlEvents.touchUpInside)
        let rightBarButtonItemEdit: UIBarButtonItem = UIBarButtonItem(customView: buttonEdit)
        navBarItem.setRightBarButton(rightBarButtonItemEdit, animated: false)
    }
    
    
    
    class func createRightBarButtons(target:AnyObject, navigationItem: UINavigationItem, select1: Selector, select2: Selector, select3: Selector){
        let barbutton2 = CommonUtility.getCustomRightButton(target, navBarItem: navigationItem, strImage: "dashboard_user_button", select: select1)
        
        // Fixed Space
        let fixedSpace1: UIBarButtonItem = UIBarButtonItem(barButtonSystemItem: UIBarButtonSystemItem.fixedSpace, target: nil, action: nil)
        fixedSpace1.width = 20.0
        
        let fixedSpace2: UIBarButtonItem = UIBarButtonItem(barButtonSystemItem: UIBarButtonSystemItem.fixedSpace, target: nil, action: nil)
        fixedSpace2.width = 20.0
        
        let barbutton3 = CommonUtility.getCustomRightButton(target, navBarItem: navigationItem, strImage: "notification_icon", select: select2)
        
        let barbutton1 = CommonUtility.getCustomRightButton(target, navBarItem: navigationItem, strImage: "setting_icon", select: select3)
        
        navigationItem.rightBarButtonItems = [barbutton1, fixedSpace1, barbutton2, fixedSpace2, barbutton3]
    }
    
    class func createRightBarHomeButtons(target:AnyObject, navigationItem: UINavigationItem, select1: Selector, select2: Selector){
        let barbutton2 = CommonUtility.getCustomRightButton(target, navBarItem: navigationItem, strImage: "dashboard_user_button", select: select1)
        
        // Fixed Space
        let fixedSpace1: UIBarButtonItem = UIBarButtonItem(barButtonSystemItem: UIBarButtonSystemItem.fixedSpace, target: nil, action: nil)
        fixedSpace1.width = 20.0
        
        let barbutton1 = CommonUtility.getCustomRightButton(target, navBarItem: navigationItem, strImage: "home", select: select2)
        
        navigationItem.rightBarButtonItems = [barbutton1, fixedSpace1, barbutton2]
    }
    
    class func createRightBarOnlyHomeButtons(target:AnyObject, navigationItem: UINavigationItem, select1: Selector){
        
        let barbutton1 = CommonUtility.getCustomRightButton(target, navBarItem: navigationItem, strImage: "home", select: select1)
        
        navigationItem.rightBarButtonItems = [barbutton1]
    }
    
    class func getCustomRightButton(_ target:AnyObject,navBarItem:UINavigationItem,strImage:NSString,select:Selector) -> UIBarButtonItem {
        let buttonEdit: UIButton = UIButton(type: .custom)
        buttonEdit.contentHorizontalAlignment = .right
        buttonEdit.frame = CGRect(x: 0, y: 0, width: 40, height: 40)
        buttonEdit.setImage(UIImage(named:strImage as String), for: UIControlState())
        buttonEdit.addTarget(target, action: select, for: UIControlEvents.touchUpInside)
        let rightBarButtonItem: UIBarButtonItem = UIBarButtonItem(customView: buttonEdit)
        return rightBarButtonItem
        //  navBarItem.setRightBarButton(rightBarButtonItemEdit, animated: false)
    }
    
    class func createRightBarSaveButtons(target:AnyObject, navigationItem: UINavigationItem, select1: Selector, select2: Selector, select3: Selector){
        // let barbutton2 = CommonUtility.getCustomRightButton(target, navBarItem: navigationItem, strImage: "dashboard_user_button", select: select1)
        let barbutton3 = CommonUtility.createCustomRightSaveButtonWithTitle(target, navBarItem: navigationItem, strTitle: "Save", select: select3)
        // Fixed Space
        let fixedSpace1: UIBarButtonItem = UIBarButtonItem(barButtonSystemItem: UIBarButtonSystemItem.fixedSpace, target: nil, action: nil)
        fixedSpace1.width = 20.0
        
        let fixedSpace2: UIBarButtonItem = UIBarButtonItem(barButtonSystemItem: UIBarButtonSystemItem.fixedSpace, target: nil, action: nil)
        fixedSpace2.width = 20.0
        
        let barbutton2 = CommonUtility.getCustomRightButton(target, navBarItem: navigationItem, strImage: "dashboard_user_button", select: select2)
        
        let barbutton1 = CommonUtility.getCustomRightButton(target, navBarItem: navigationItem, strImage: "home", select: select1)
        
        navigationItem.rightBarButtonItems = [barbutton3, fixedSpace1, barbutton1, fixedSpace2, barbutton2]
    }
    
    class func createCustomRightSaveButtonWithTitle(_ target:AnyObject,navBarItem:UINavigationItem,strTitle:NSString,select:Selector) -> UIBarButtonItem
    {
        let buttonEdit: UIButton = UIButton(type: .custom)
        buttonEdit.contentHorizontalAlignment = .right
        buttonEdit.frame = CGRect(x: 0, y: 0, width: 65, height: 50)
        buttonEdit.setTitle(strTitle as String, for: .normal)
        buttonEdit.setTitleColor(UIColor.white, for: .normal)
        buttonEdit.titleLabel?.font = UIFont.boldSystemFont(ofSize: FONT_SIZE_22)
        buttonEdit.addTarget(target, action: select, for: UIControlEvents.touchUpInside)
        let rightBarButtonItemEdit: UIBarButtonItem = UIBarButtonItem(customView: buttonEdit)
        return rightBarButtonItemEdit
    }
    
    class func showTotstOnWindow(strMessgae: String, toastPosition : ToastPosition) {
        let window :UIWindow = UIApplication.shared.keyWindow!
        window.makeToast(strMessgae, duration: 2.0, position: toastPosition)
    }
    
    class func showErrorCRNotifications(title : String , message : String) {
        CRNotifications.showNotification(type: CRNotifications.error, title: title, message: message, dismissDelay: 5)
    }
    
    class func showSuccessCRNotifications(title : String , message : String) {
        CRNotifications.showNotification(type: CRNotifications.success, title: title, message: message, dismissDelay: 5)
    }
    
    class func showInfoCRNotifications(title : String , message : String) {
        CRNotifications.showNotification(type: CRNotifications.info, title: title, message: message, dismissDelay: 5)
    }
    
    //MARK: Check valid email
    class func checkValidEmail(_ testStr:String) -> Bool {
        let emailRegEx = "[A-Z0-9a-z._%+-]+@[A-Za-z0-9.-]+\\.[A-Za-z]{2,4}"
        
        let emailTest = NSPredicate(format:"SELF MATCHES %@", emailRegEx)
        let result = emailTest.evaluate(with: testStr)
        return result
    }
    
    //MARK : Check valid password
    class func checkValidPasswordField(_ testStr:String) -> Bool {
        let pwdRegEx = "^(?=.*[a-z])(?=.*[A-Z])(?=.*\\d)(?=.*[d$@$!%*?&#])[A-Za-z\\dd$@$!%*?&#]{8,}"
        
        let pwdTest = NSPredicate(format:"SELF MATCHES %@", pwdRegEx)
        let result = pwdTest.evaluate(with: testStr)
        return result
    }
    ////////////////////////VALIDATION///////////////////////////
    
    class func doValidateForgotPassword(_ controller:ForgotPasswordViewController)->(Bool,String)
    {
        
        controller.tfEmail.text = controller.tfEmail.text?.trimmingCharacters(in: .whitespacesAndNewlines)
        
        if(controller.tfEmail.text!.isEmpty)
        {
            return (false,NSString(format: "%@", "Please enter email") as String)
        }
        else if(!checkValidEmail(controller.tfEmail.text!))
        {
            return (false,"Please enter valid email")
        }
        return (true,"Your New Password link is successfully sent to your regitered email id")
    }
    
    class func doValidateAppointment(_ controller:AddAppointmentViewController)->(Bool,String)
    {
        
        //        controller.tfReferal.text = controller.tfReferal.text?.trimmingCharacters(in: .whitespacesAndNewlines)
        
        if(controller.btnDate.currentTitle == "00/00/0000")
        {
            return (false,NSString(format: "%@", "Please Select Date") as String)
        }
            
        else if(controller.btnTimeSlot.currentTitle == "00:00 pm")
        {
            return (false,NSString(format: "%@", "Please Select TimeSlot") as String)
        }
        
        return (true,"Appointment Successfully Done")
    }
    
    class func doValidatePersonalDetails(_ controller:PersonalDetailsViewController)->(Bool,String)
    {
        if controller.dictPersonalDetails[PersonalDetails.weight] == ""
        {
            return (false,NSString(format: "%@", "Please Enter Weight") as String)
        }
        else if controller.dictPersonalDetails[PersonalDetails.hoursExperience] == ""
        {
            return (false,NSString(format: "%@", "Please Select Hours of Exercise") as String)
        }
        else if controller.dictPersonalDetails[PersonalDetails.caloriesBurnt] == ""
        {
            return (false,NSString(format: "%@", "Please Select Calories Burnt") as String)
        }
        return (true,"Personal Details entry Successfully Done")
    }
    
    //////////////////////////////////////////////////////////  Alert related methods /////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////
    //Method is used to show alert view on window.
    
    class func showAlertWithMessageOnController(_ message:String , title :String ,btnCancel:String,btnOk:String , controller : UIViewController,  successBlock : @escaping (_ obj : Int) -> Void , failure : @escaping (_ error : Int) -> Void){
        DispatchQueue.main.async(execute: {
            let alert = UIAlertController(title: title, message: message, preferredStyle: UIAlertControllerStyle.alert)
            if !(btnCancel.isEmpty ){
                alert.addAction(UIAlertAction(title: btnCancel, style: UIAlertActionStyle.default, handler: { action in
                    failure(0)
                }))
            }
            if !(btnOk.isEmpty ){
                alert.addAction(UIAlertAction(title: btnOk, style: UIAlertActionStyle.default, handler: { action in
                    alert.dismiss(animated: true, completion: nil)
                    successBlock(1)
                }))
            }
            controller.present(alert, animated: true, completion: nil)
        })
    }
    
    
    class func showAlertWithMessage(_ message:String , title :String ,btnCancel:String,btnOk:String , successBlock : @escaping (_ obj : Int) -> Void , failure : @escaping (_ error : Int) -> Void){
        DispatchQueue.main.async(execute: {
            let alert = UIAlertController(title: title, message: message, preferredStyle: UIAlertControllerStyle.alert)
            if !(btnCancel.isEmpty ){
                alert.addAction(UIAlertAction(title: btnCancel, style: UIAlertActionStyle.default, handler: { action in
                    failure(0)
                }))
            }
            if !(btnOk.isEmpty ){
                alert.addAction(UIAlertAction(title: btnOk, style: UIAlertActionStyle.default, handler: { action in
                    alert.dismiss(animated: true, completion: nil)
                    successBlock(1)
                }))
            }
            UIApplication.shared.delegate?.window!?.rootViewController?.present(alert, animated: true, completion: nil)
        })
    }
    
    // Get time in string formate from this method
    class func doGetTimeFromTheDate(obj : Date  , formate : String) -> String{
        let formatter = DateFormatter()
        formatter.dateFormat = formate
        // let locale = NSTimeZone.init(abbreviation: "BST")
        formatter.locale = NSLocale.current
        let hourString = formatter.string(from: obj) // "12 AM"
        return hourString
    }
    
    class func changeDateFormateOfDate(obj : String , oldFormate : String! , newFormate : String!) -> String{
        if obj.isEmpty {
            return ""
        }
        let oldFormatter = DateFormatter()
        oldFormatter.dateFormat = oldFormate//"hh:mm:ss"
        oldFormatter.locale = Locale(identifier: "en_US_POSIX")
        oldFormatter.timeZone = NSTimeZone.local
        let date = oldFormatter.date(from: obj)
        let newFormatter = DateFormatter()
        newFormatter.dateFormat = newFormate
        newFormatter.locale! = NSLocale.current
        let strObject = newFormatter.string(from: date!)
     
        return strObject
    }
    
    class func ChangeDateToString(dateObj : Date ,  newFormate : String! ) -> String{
        let newFormatter = DateFormatter()
        newFormatter.dateFormat = newFormate
        newFormatter.locale = NSLocale.current
        let strObject = newFormatter.string(from: dateObj)
        return strObject
    }
    
    class func setBooleanValue(_ key : NSString , value : Bool){
        let userDefault : UserDefaults = UserDefaults.standard
        userDefault.set(value, forKey: key as String)
        userDefault.synchronize()
    }
    
    class func getBooleanDataForKey(_ key : String) -> Bool?
    {
        let userDefault:UserDefaults = UserDefaults.standard
        if (userDefault.value(forKey: key)   != nil)
        {
            return userDefault.value(forKey: key) as? Bool
        }
        return false
    }
    
    class func setMenuSelectedOption(menuOptionIndex: Int) {
        let appDelegate = UIApplication.shared.delegate as! AppDelegate
        appDelegate.selectedMenuOption = menuOptionIndex
    }
    
    class func getMenuSelectedOption() -> Int {
        let appDelegate = UIApplication.shared.delegate as! AppDelegate
        return appDelegate.selectedMenuOption!
    }
    
    class func appVersion() -> String {
        let appVersion: AnyObject? = Bundle.main.infoDictionary!["CFBundleShortVersionString"] as AnyObject
        return appVersion as! String
    }
    
    class func userProfile() -> UserModel? {
        if let data = UserDefaults.standard.value(forKey:UserdefaultsKey.userData.rawValue) as? Data {
            let userModel = try? PropertyListDecoder().decode(UserModel.self, from: data)
            return userModel
        }
        return nil
    }
    
    /**
     *  It will show loading mask.
     */
    
    class func startLoader() {
        let activityData = ActivityData(size: CGSize(width: kActivityIndicatorWidth, height: kActivityIndicatorHeight), message: "", messageFont: UIFont.systemFont(ofSize: FONT_SIZE_16), messageSpacing: 0, type: .ballRotateChase, color: appColor(), padding: 0, displayTimeThreshold: 3, minimumDisplayTime: 1, backgroundColor:  UIColor(red: 0, green: 0, blue: 0, alpha: 0.5), textColor: UIColor.gray)
        NVActivityIndicatorPresenter.sharedInstance.startAnimating(activityData)
    }
    
    /**
     *  It will hide loading mask.
     */
    class func stopLoader() {
        NVActivityIndicatorPresenter.sharedInstance.stopAnimating()
    }
    
    class func userType() -> String {
        if CommonUtility.isPilate() {
            return "1"
        }
        return "2"
    }
    
    class func isPilate() -> Bool {
        return UserDefaults.standard.value(forKey: UserdefaultsKey.isUserPilate.rawValue) as! Bool
    }
    
    class func getAge(selectedDateValue: String) -> Int {
        let dateFormatter = DateFormatter()
        dateFormatter.dateFormat = "MM/dd/yyyy"
        let birthdayDate = dateFormatter.date(from: selectedDateValue)
        let now = Date()
        let calendar: NSCalendar! = NSCalendar(calendarIdentifier: .gregorian)
        let calcAge = calendar.components(.year, from: birthdayDate!, to: now, options: [])
        return calcAge.year!
    }
    
    class func doGetDifferenceInDays(dateToCompare : Date) -> Int
    {
        // Replace the hour (time) of both dates with 00:00
        let date1 = CommonUtility.doGetCurrentDateTime(withFormat: "YYYY-MM-dd")//calendar.startOfDayForDate(firstDate)
        
        let components = Set<Calendar.Component>([ .day])
        
        let differenceOfDate = Calendar.current.dateComponents(components, from: dateToCompare, to: CommonUtility.doGetDateFromString(strDate: date1, format: "YYYY-MM-dd"))
        
        print("date 11 -- \(date1) and date 22 - \(dateToCompare)")
        print("date to compare -- \(dateToCompare) and difference in date -- \(String(describing: differenceOfDate.day))")
        return differenceOfDate.day!
    }
    
    //This function converts datetime in string to datetime in Date type
    class func doGetDateFromString(strDate : String, format : String) -> Date  {
        let dateFormatter = DateFormatter()
        // this is imporant - we set our input date format to match our input string
        // if format doesn't match you'll get nil from your string, so be careful
        dateFormatter.dateFormat = format
        dateFormatter.timeZone = NSTimeZone(forSecondsFromGMT: 0) as TimeZone
        print(dateFormatter.date(from: strDate)!)
        return dateFormatter.date(from: strDate)!
    }
    
    class func doGetCurrentDateTime(withFormat : String) -> String
    {
        let date = Date()
        let formatter = DateFormatter()
        formatter.dateFormat = withFormat
        return formatter.string(from: date)
    }
    
    class func dzEmptySetTitle(title: String) -> NSAttributedString {
        let string = title
        let myAttribute = [NSAttributedStringKey.foregroundColor: UIColor.black]
        return NSAttributedString(string: string, attributes: myAttribute)
    }
    
    class func dzEmptySetButtonTitle(title: String) -> NSAttributedString {
        let string = title
        let myAttribute = [NSAttributedStringKey.foregroundColor: UIColor.black]
        return NSAttributedString(string: string, attributes: myAttribute)
    }
    
    class func timeDifferenceInMinutes(time1: String, time2: String) -> Int {
        let dateFormatter = DateFormatter()
        dateFormatter.dateFormat = "HH:mm"
        let timeDate1 = dateFormatter.date(from: time1)!
        let calendar = Calendar.current
        let timeComponents1 = calendar.dateComponents([.hour, .minute], from: timeDate1)
        
        let timeDate2 = dateFormatter.date(from: time2)!
        let timeComponents2 = calendar.dateComponents([.hour, .minute], from: timeDate2)
        
        let difference = calendar.dateComponents([.minute], from: timeComponents1, to: timeComponents2).minute!
        return difference
    }
    
    class  func doGetKeyForHeader(strDate : String) -> String{
        var strKey = strDate
        
        if CommonUtility.doGetDifferenceInDays(dateToCompare: CommonUtility.doGetDateFromString(strDate: strDate, format: "dd-MM-yyyy")) == 0
        {
            strKey = "Today"
        }else if CommonUtility.doGetDifferenceInDays(dateToCompare: CommonUtility.doGetDateFromString(strDate: strDate, format: "dd-MM-yyyy")) == -1
        {
            strKey = "Tomorrow"
        }
        return strKey
    }
    
    class func loadNoDataFound(vc: UIViewController, message: String) {
        let noDataView = Bundle.loadView(fromNib: "NoDataFound", withType: NoDataFound.self)
        noDataView.frame = vc.view.frame
        noDataView.strMessage = message
        vc.view.addSubview(noDataView)
    }
}

extension Bundle {
    static func loadView<T>(fromNib name: String, withType type: T.Type) -> T {
        if let view = Bundle.main.loadNibNamed(name, owner: nil, options: nil)?.first as? T {
            return view
        }
        fatalError("Could not load view with type ")
    }
}
