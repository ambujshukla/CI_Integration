//
//  Protocols.swift
//  PPL
//
//  Created by cdn68 on 25/06/18.
//  Copyright © 2018 cdn. All rights reserved.
//

import Foundation

protocol AppData {
    var uuid: String {get}
    var timeStamp: Int {get}
}

extension AppData {
    var uuid: String {
        return UUID().uuidString
    }
    
    var timeStamp: Int {
        return Int(NSDate().timeIntervalSince1970)
    }
}
