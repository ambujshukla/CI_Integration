//
//  UITableView+GCExtensions.swift
//  PPL
//
//  Created by cdn68 on 27/04/18.
//  Copyright © 2018 cdn. All rights reserved.
//

import Foundation
import UIKit

extension UITableView {
    
    /**
    Remove cell separators for empty cells.
    
    Current Implementation is setting the tableFooterView.
    */
    func preventEmptyCellSeparators () {
        self.tableFooterView = UIView(frame: CGRect.zero)
    }
    
    /**
    Prevents the table from inheriting layout margins. This can cause problems with trying to set specific cell separator insets.
    */
    func preventMarginInheritance () {
        if ProcessInfo().isOperatingSystemAtLeast(OperatingSystemVersion(majorVersion: 8, minorVersion: 0, patchVersion: 0)) {
            self.layoutMargins = UIEdgeInsets.zero
        }
    }
    
}
